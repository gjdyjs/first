import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 60,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Detail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            list:[]
        }; 
        this.getData1(this.props.id)
    }
    getData1(id){
             axios.get(`/detail/${id}`)
                .then((res)=>{
                    this.setState({
                        list:res.data
                    })
                })
                .catch((error)=>{
                    console.log(error)
                })
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    getRealStorage=(count,id)=>{
        axios.get(`/getStorage/${id}`)
        .then((res)=>{
            let stortage= (res.data.find(item=>item.id==id).storage)
            if((stortage-count)>=0){
                axios.post("/addCart",{
                        'id':id,
                        'count':count
                }).then(res=>{
                    
                })  
                .catch((error)=>{
                    console.log(error)
                })
                this.props.history.push("/cartList");
            }else{
                console.log(count,res.data.find(item=>item.id==id).storage)
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doInsert=()=>{
        let id = this.props.match.params.id
        const result1 = /^\d+$/.test(this.state.count)
        const result2 = /^([1-9]\d*|0)$/.test(this.state.count)
        if(!(this.state.count.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            if(result1){
                if(this.state.count>0){
                    if(result2){
                        this.getRealStorage(this.state.count,id)
                    }else{
                        alert("頭数字を0以外で入力してください")
                    }
                }else{
                    alert("最小値は1です")
                }
            }else{
                alert("数字または整数を入力してください")
            }
        }else{
            alert("注文数はからです")
        } 
    }
    render(){
        const { classes } = this.props;
        return(
        <div>
            {
                this.state.list.map((value,key)=>{
                return <div key={key}>
                        <div>
                            <Link to="/">ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;{value.itemName}
                        </div>
                        <div>
                            <img src={value.pic} style={{height:"250px",width:"300px",position:"absolute",left:"350px",top:"200px"}}/>
                            <div style={{position:"absolute",left:"750px",top:"250px",fontSize:"20px"}}>
                            {value.itemName}<br/>
                            <u>価額：￥{value.price}</u><br/>
                            <u>在庫数：{value.storage}</u><br/>
                            <u>担当部署：{value.szk}</u><br/>
                            </div>
                        </div>
                        <div style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"300px",position:"absolute",left:"1200px",top:"200px"}}>
                            <br/>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{textAlign:"center"}}> 
                            <br/>
                            <div style={{position:"absolute",left:"80px",top:"100px",fontSize:"20px"}}>
                                注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" value = {this.state.count} onChange = {this.handleCount}/>
                            </div>
                            <br/>
                            <br/>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doInsert}>
                                カートに入れる
                            </Button>
                            </div>
                        </div>
                        <div style={{position:"absolute",left:"350px",top:"700px",fontSize:"20px"}}>
                            詳細{value.detail}
                        </div>
                    </div>
                })
            }
        </div>
        )
    }
}
export default withStyles(styles)(withRouter(Detail));