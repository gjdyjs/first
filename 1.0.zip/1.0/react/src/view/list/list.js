import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import FormControl from '@material-ui/core/FormControl';
import Typography from '@material-ui/core/Typography';
import InputLabel from '@material-ui/core/InputLabel';
import ListItem from '@material-ui/core/ListItem';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from "material-ui-flat-pagination";
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box';
const styles = theme => ({
    root: {
        flexGrow: 1,
        display: 'flex',
        backgroundColor:"white",
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 100,
      },
});
class IndexList extends Component{
    constructor(arg){
        super(arg);   
        this.state = {
            list:[],
            offset: 0,
            parPage: 10,
            sort:''     
        }; 
        this.getData(this.props.id) 
    }
    shouldComponentUpdate(nextProps){
        if(this.props.id !== nextProps.id){
            this.state.page = 1;
            this.getData(nextProps.id);
            return false;
        }
        return true;
    }
    getData(id){
        axios.get(`/list/${id}`)
        .then((res)=>{
            this.setState({
                list:res.data,
                sort:[]
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    handleClickPagination = offset => {
        this.setState({ offset })
    }
    handleSort=(e)=>{
        this.setState({
            sort:e.target.value
        })
        axios.get("/sort",{
            params:{
                id:this.props.id,
                sortKey:e.target.value
            }
        })
        .then((res)=>{
            this.setState({
                list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <Grid container spacing={5}>
                    <Grid item lg={6}>
                        <Typography variant="h6" color="inherit" noWrap className={classes.toolbarTitle}>
                        <Link to="/">ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;{this.props.id}検索結果
                        </Typography>
                    </Grid>
                    <Grid item lg={6}>
                    <FormControl variant="outlined" size = "small" className={classes.formControl}>
                        <InputLabel>並び順</InputLabel>
                        <Select style={{textAlign:"left"}} onChange={this.handleSort} value={this.state.sort}>
                            <MenuItem value={10}>商品名</MenuItem>
                            <MenuItem value={20}>登録日降順</MenuItem>
                            <MenuItem value={30}>登録日昇順</MenuItem>
                            <MenuItem value={40}>価額降順</MenuItem>
                            <MenuItem value={50}>価額昇順</MenuItem>
                        </Select>
                    </FormControl>
                    </Grid>
                    <Grid item lg={12}>
                    <div>
                        <List dense compoent="span">
                            {this.state.list
                            .slice(this.state.offset,this.state.offset+this.state.parPage)
                            .map(value => {
                                return (
                                    <div>
                                    <ListItem key={value.id}>
                                        <Link to={`/detail/${value.id}`}><img src={value.pic}/></Link>
                                        <ListItemText>
                                        <Link to={`/detail/${value.id}`}>{value.itemName}</Link>
                                            <div>価額：{value.price}</div>
                                            <div>在庫数：{value.storage}</div>
                                            <div>担当部署：{value.szk}</div>
                                        </ListItemText>
                                    </ListItem>
                                    <Divider />
                                    </div>
                                );
                            })}
                        </List>
                        <Box component="span">
                            <Pagination
                            currentPageColor='default'
                            size='large'
                            style={{position:"absolute",left:"900px"}}
                            limit={this.state.parPage}
                            offset={this.state.offset}
                            total={this.state.list.length}
                            onClick={(e, offset) => this.handleClickPagination(offset)}
                            />
                        </Box>
                    </div>
                    </Grid> 
                </Grid>
            </div>
        )
    }
}
export default withStyles(styles)(IndexList);