import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

const drawerWidth = 240;
const styles = theme => ({
      drawer: {
        width: drawerWidth,
        flexShrink: 0,
      },
      drawerPaper: {
        width: drawerWidth,
      },
      drawerContainer: {
        overflow: 'auto',
      },
});
class Sub extends Component{
    render(){
        const {classes} = this.props;
        return(
            
            <Drawer
              className={classes.drawer}
              variant="permanent"
              classes={{
                paper: classes.drawerPaper,
              }}
            >
              <Toolbar />
              <Toolbar />
              <div className={classes.drawerContainer}>
                <List>
                  {['ジャンル１１', 'ジャンル１２', 'ジャンル１3', 'ジャンル１4'].map((text, index) => (
                    <ListItem button key={text}>
                      <ListItemIcon></ListItemIcon>
                      <ListItemText primary={text} />
                    </ListItem>
                  ))}
                </List>
                <Divider />
                <List>
                  {['ジャンル１', 'ジャンル2', 'ジャンル3'].map((text, index) => (
                    <ListItem button key={text}>
                      <ListItemIcon></ListItemIcon>
                      <ListItemText primary={text} />
                    </ListItem>
                  ))}
                </List>
              </div>
            </Drawer>
          
        )
    }
}
export default withStyles(styles)(Sub);