import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Pagination from "material-ui-flat-pagination";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
  dialog: {
    height:800,
    },
  textField: {
      margin: theme.spacing(0),
      minWidth: 500,
    },
  button: {
      margin: theme.spacing(0),
      minWidth: 50,
    },
  table: {
      minWidth: 300,
    },
  tableCell: {
      minWidth: 170,
    },
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
    },
});
class Dialog1 extends Component{
    constructor(props){
        super(props)
        this.state = {
            open:false,
            txt:'',
            radioValue:'',
            offset: 0,
            parPage: 5,
            list:[],
            arr:[]
        };
    }
    handleClickOpen=()=>{
        this.setState({
            open:true
        }) 
    }
    handleInput=(e)=>{
      this.setState({
        txt:e.target.value
      })
    }
    handleSearch=()=>{
      let id = this.state.txt
      if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
        axios.get(`/getUserInfo/${id}`)
        .then((res)=>{
            this.setState({
               list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })        
      }
    }
    handleClickPagination = offset => {
      this.setState({ offset })
    }
    handleClose=()=>{
      this.setState({
        list:[],
        open:false
      })
    }
    handleRadio=(e)=>{
      this.setState({
          radioValue:e.target.value
      })
    }
    handleCheck=(id)=>{
      if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
        this.handleCommit(id)
      }else{
        alert("注文者を選んでください")
      }
    }
    handleCommit=(id)=>{
      this.state.arr=this.state.list.find(item=>item.id==id)
      this.props.getInfo1(this.state.arr.user_id,this.state.arr.user_name)
      this.setState({
        open:false,
        list:[],
        radioValue:''
      })
    }
    render(){
      const { classes } = this.props;
        return(
            <div>
            <Button variant="outlined" color="primary" onClick={this.handleClickOpen}>
              検索
            </Button>
            <Dialog open={this.state.open} onClose={this.handleClose} className={classes.dialog}>
              <DialogContent>
                <TextField id="outlined-basic" label="検索条件（注文者＃または注文者名）" variant="outlined" className={classes.textField} onChange = {this.handleInput}/>
              </DialogContent>
              <DialogActions>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                    検索
                </Button>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {()=>this.handleCheck(this.state.radioValue)}>
                    注文者選択
                </Button>
              </DialogActions>
              <TableContainer>
                <Table  aria-label="caption table">
                  <TableHead>
                    <TableRow>
                      <TableCell>Table</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                  {this.state.list
                  .slice(this.state.offset,this.state.offset+this.state.parPage)
                  .map(value => {
                      return (
                          <div>
                            <TableRow key={value.id} style={{border:"solid 1px"}}>
                              <TableCell align="right" >
                                <input type="radio" value={value.id} checked={this.state.radioValue==value.id} onChange={this.handleRadio}/>
                              </TableCell>
                              <TableCell align="right" >{value.user_id}</TableCell>
                              <TableCell align="right" >{value.user_name}</TableCell>
                            </TableRow>
                          </div>
                              );
                          })}                    
                              <Pagination
                              currentPageColor='default'
                              size='large'
                              style={{position:"absolute",left:"200px"}}
                              limit={this.state.parPage}
                              offset={this.state.offset}
                              total={this.state.list.length}
                              onClick={(e, offset) => this.handleClickPagination(offset)}
                              />
                  </TableBody>
                </Table>
              </TableContainer>
            </Dialog>
          </div>
        )
    }
}
export default withStyles(styles)(Dialog1);
