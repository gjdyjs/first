import React, { Component } from 'react';
import {Button,TextField} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import {Link} from "react-router-dom";
import axios from 'axios';
import Dialog1 from './dialog1';
import Dialog2 from './dialog2';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        minWidth: 100,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Address extends Component{
    constructor(props){
        super(props);
        this.state = {
            total:'',
            szk:'',
            szk_name:'',
            user_id:'',
            user_name:'',
            address_id:'',
            address_name:'',
            address_szk:'',
            post:'',
            address:'',
            phone_num:'',
            addInfo:[],
            userList:[],
            arr:[]
        };
    }
    getInfo1(user_id,user_name){
        this.setState({
            user_id:user_id,
            user_name:user_name
        })
    }
    getInfo2(address_id,address_name,address_szk,address,post,phone_num){
        this.setState({
            address_szk:address_szk,
            address_id:address_id,
            address_name:address_name,
            address:address,
            post:post,
            phone_num:phone_num
        })
    }
    handleClear=(e)=>{
        this.setState({
            address_id:'',
            address_name:'',
            address_szk:'',
            post:'',
            address:'',
            phone_num:'',
          })
    }
    doConfirm=(e)=>{
        e.preventDefault();
        // axios({
        //     method: 'post',
        //     url: '',
        //     data: {}
        //   });
        this.props.history.push("/cartConfirm");
    }
    doJump=()=>{
        this.props.history.push("/cartList");
    }
    handleInput=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
        if(e.target.name=="user_id"){
            if(e.target.value.length==6){
                this.autoSetUser(e.target.value)
            }
        }
        if(e.target.name=="address_id"){
            if(e.target.value.length==6){
                this.autoSetAddress(e.target.value)
            }
        }
    }
    autoSetUser=(user_id)=>{
            axios.get(`/getUserInfoAuto/${user_id}`)
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setUserOnly(user_id)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    autoSetAddress=(address_id)=>{
            axios.get(`/getAddressInfoAuto/${address_id}`)
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setAdressOnly(address_id)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    setUserOnly=(user_id)=>{
        this.state.arr=this.state.userList.find(item=>item.user_id==user_id)
        this.setState({
            user_name:this.state.arr.user_name,
            userList:[],
            arr:[]
        })
    }
    setAdressOnly=(address_id)=>{
        this.state.arr=this.state.userList.find(item=>item.address_id==address_id)
        this.setState({
            address_name:this.state.arr.address_name,
            address:this.state.arr.address,
            address_szk:this.state.arr.address_szk,
            post:this.state.arr.post,
            phone_num:this.state.arr.phone_num,
            userList:[],
            arr:[]
        })
    }
    handleCopy=(e)=>{
        if(!(this.state.user_name.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
          axios.get(`/getUserInfo/${this.state.user_name}`)
          .then((res)=>{
              this.setState({
                addInfo:res.data
              })
              this.setInfo(this.state.user_name)
          })
          .catch((error)=>{
              console.log(error)
          })        
        }
    }
    setInfo(user_name){
        this.state.arr = this.state.addInfo.find(item=>item.user_name==user_name)
        this.setState({
            address_name:this.state.arr.address_name,
            address_id:this.state.arr.address_id,
            address_szk:this.state.arr.address_szk,
            post:this.state.arr.post,
            address:this.state.arr.address,
            phone_num:this.state.arr.phone_num,
            arr:[]
        })
    }
    render(){
        const { classes } = this.props;
        return(
                <div>
                    <div>
                    <Link to = '/'>ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;発送先入力
                    </div>
                    <div style = {{width:"800px",height:"250px"}}>
                        <h1>入力者</h1>
                        <h3>11111  サンプル注文者</h3>
                        <div>
                            担当部署&nbsp;<span name="szk" style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>担当者&nbsp;<span name="szk_name" style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>注文者&nbsp;&nbsp;&nbsp;
                            <Dialog1 getInfo1={(user_id,user_name)=>this.getInfo1(user_id,user_name)}/> 
                        </h1>
                        <div>
                            注文者#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <TextField id="outlined-basic" variant="outlined" name="user_id" value={this.state.user_id} className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" variant="outlined" name="user_name" value={this.state.user_name} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>
                            発送先&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Dialog2 getInfo2={(address_id,address_name,address_szk,address,post,phone_num)=>this.getInfo2(address_id,address_name,address_szk,address,post,phone_num)}/>
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleCopy}>
                            注文者コピー
                            </Button>&nbsp;
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleClear}>
                            クリア
                            </Button>
                        </h1>
                        <div>
                            発送先#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="address_id" value={this.state.address_id} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" name="address_name" value={this.state.address_name} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>
                            発送先部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="address_szk" value={this.state.address_szk} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            郵便番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="post" value={this.state.post} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            住所&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="address" value={this.state.address} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>             
                        </div>
                        <br/>                                          
                        <div>
                            電話番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="phone_num" value={this.state.phone_num} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>                                         
                    </div>                                
                    <div style = {{float:"right",position:"absolute",left:"1500px",top:"200px"}}>
                    <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"300px"}}>
                        <br/>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                        <br/>
                        <h3>小計:{this.state.total} 円</h3>
                        <Button color="primary" variant="outlined" className={classes.button} onClick = {this.doConfirm}>
                            注文内容確認
                        </Button>
                        <br/><br/>
                        <Button color="primary" variant="outlined" className={classes.button} onClick = {this.doJump}>
                            カートに戻る
                        </Button>
                        </div>
                    </form>
                    </div>
                </div>
        )
    }
}
export default withStyles(styles)(withRouter(Address));