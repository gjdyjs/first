package com.example.service;



import com.example.entity.WorkTable;
import com.example.mapper.WorkTableMapper;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WorkTableService {

    @Autowired
    WorkTableMapper workTableMapper;
    public List<WorkTable> SelectForList(){
        return workTableMapper.SelectForList();
    }
    public void DeleteItem(int id){
         workTableMapper.DeleteItem(id);
    }
    public void UpdateItem(int id,int count){
        workTableMapper.UpdateItem(id,count);
   }
    public void InseretItem(){
        workTableMapper.InseretItem();
   }
    public int SelectForCount(){
        return workTableMapper.SelectForCount();
    }
}