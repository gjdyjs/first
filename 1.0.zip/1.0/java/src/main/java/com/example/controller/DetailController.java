package com.example.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Detail;
import com.example.entity.WorkTable;
import com.example.entity.AddCart;
import com.example.service.DetailService;


@RestController

public class DetailController {
    @Autowired
    private DetailService detailService;
    @RequestMapping(value = "/detail/{id}",method= RequestMethod.GET)
    public String GetDetail(@PathVariable("id") String id){
    	return detailService.SelectForDetail(id).toString();
    }
    @RequestMapping(value = "/getStorage/{id}",method= RequestMethod.GET)
    public String GetStorage(@PathVariable("id") int id){
    	return detailService.SelectForStorage(id).toString();
    }
    @RequestMapping(value = "/addCart",method= RequestMethod.POST)
    public void AddCart(@RequestBody Map<String,String> map){
    	List goods = detailService.SelectForDetail(map.get("id"));
    	String id = map.get("id");
    	String count = map.get("count");
    	String itemName = null;
    	String detail = null;
    	int storage = 0;
    	String szk = null;
    	String jungle = null;
    	int price = 0;
    	String pic = null;
        if(goods.size()!=0){
	        for (int i = 0; i < goods.size(); i++) {
	          Detail details = (Detail) goods.get(i);
	          storage = details.getStorage();
	          itemName = details.getItemName();
	          detail = details.getDetail();
	          szk = details.getSzk();
	          jungle = details.getJungle();
	          price = details.getPrice();
	          pic = details.getPic();
	        }
        }
        detailService.InsertCart(id,itemName,storage,detail,szk,jungle,price,pic,count);
    }
}





