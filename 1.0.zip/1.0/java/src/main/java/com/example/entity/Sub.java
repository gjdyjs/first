package com.example.entity;

public class Sub {
	private String maincata;
	private String subcata;
	private int id;
	private int subid;
	public String getMaincata() {
		return maincata;
	}


	public void setMaincata(String maincata) {
		this.maincata = maincata;
	}


	public String getSubcata() {
		return subcata;
	}


	public void setSubcata(String subcata) {
		this.subcata = subcata;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getSubid() {
		return subid;
	}


	public void setSubid(int subid) {
		this.subid = subid;
	}
	 
    @Override
    public String toString() {
        return  "{" +
        	"\"maincata\":\""+maincata+"\","+
        	"\"sub\":["+
        		"{"+"\"subcata\":\""+subcata+"\""+"}"+"]"+
       "}";
    }
}
