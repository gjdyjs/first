package com.example.mapper; 

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.example.entity.AddCart;
import com.example.entity.Detail;
import com.example.entity.Storage;

@Repository
@Mapper
public interface DetailMapper {
    List<Detail> SelectForDetail(String id);
    List<Storage> SelectForStorage(int id);
    void InsertCart(String id,String itemName,int storage,String detail,String szk,String jungle,int price,String pic,String count);
}
