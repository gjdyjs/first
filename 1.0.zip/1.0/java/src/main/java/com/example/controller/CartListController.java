package com.example.controller;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.WorkTable;
import com.example.service.WorkTableService;

@RestController

public class CartListController {
    @Autowired
    private WorkTableService workTableService;
    @RequestMapping("/workTable")
    public String GetWorkTable(){
    	System.out.println(workTableService.SelectForList().toString());
    	return workTableService.SelectForList().toString();
    }
    @RequestMapping(value = "/change",method= RequestMethod.PUT)
    public void Change(@RequestParam int id,@RequestParam int count){
    	workTableService.UpdateItem(id,count);
    	System.out.println(id+"-----------"+count);
    }
    @RequestMapping(value = "/delete",method= RequestMethod.DELETE)
    public void Delete(@RequestParam int id){
    	workTableService.DeleteItem(id);
    	System.out.println(id);
    }    
    @PostMapping("/post")
    public void Insert(@RequestParam("total") int total,@RequestParam("data") List data){
    	System.out.println(total);
    	//workTableService.InseretItem();
    }
    @RequestMapping("/workTableCount")
    public int GetWorkTableCount(){
    	return workTableService.SelectForCount();
    }
}
