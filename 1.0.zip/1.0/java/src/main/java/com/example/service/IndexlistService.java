package com.example.service;


import com.example.entity.IndexLists;
import com.example.mapper.IndexListMapper;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IndexlistService {
	
    @Autowired
    IndexListMapper indexlistMapper;
    public List<IndexLists> SelectForList(String key){
        return indexlistMapper.SelectForList(key);
    }
    public List<IndexLists> SelectForSortDesc(String key){
        return indexlistMapper.SelectForSortDesc(key);
    }
    public List<IndexLists> SelectForSortAsc(String key){
        return indexlistMapper.SelectForSortAsc(key);
    }
}