package com.example.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.service.IndexlistService;

@RestController

public class IndexListController {
    @Autowired
    private IndexlistService indexlistService;
    @RequestMapping(value = "/list/{key}",method= RequestMethod.GET)
    public String GetList(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(indexlistService.SelectForList(key).toString());
    	return indexlistService.SelectForList(key).toString();
    }
    @RequestMapping(value = "/sort",method= RequestMethod.GET)
    public String Sort(@RequestParam String id,@RequestParam int sortKey){
    	System.out.println(id);
    	System.out.println(sortKey);
    	String result = null;
    	switch(sortKey){
        case 10 :
        	
           break;
        case 20 :
        	
           break;
        case 30 :

            break;
        case 40 :
        	result = indexlistService.SelectForSortDesc(id).toString();
        	break;
        case 50 :
        	result = indexlistService.SelectForSortAsc(id).toString();
            break;
        default :
    	}
    	System.out.println(result);
		return result;
    }
}
