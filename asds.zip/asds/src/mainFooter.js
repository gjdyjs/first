import React, { Component } from 'react';
import { Footer } from 'antd';

export default class MainFooter extends Component{
    render(){
        return(
            <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
        )
    }
}