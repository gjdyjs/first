import React, { Component } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
export default class List extends Component{
    constructor(props){
        super(props)
        this.state = {
            list:[]
        }
    }
    componentWillMount(){
        axios.get('./list.json')
            .then((response)=>{
                // console.log(response.data);
                this.setState({
                    list:response.data.data
                })
                
            })
            .catch(function(error){
                console.error();
            })
    }
    render(){
        return(
            <div>
                {
                    this.state.list.map((value,key)=>{
                        return <div key = {key} style = {{marginBottom:"10px"}}>
                                    <Link to = '/detail/{value.id}'><img src = {value.pic}/></Link>
                                    <div>
                                        {value.itemName}<br/>
                                        価額：{value.price}<br/>
                                        在庫：{value.storage}<br/>
                                        所属：{value.szk}
                                    </div>
                               </div>         
                    })
                }           
            </div>
        )
    }
}

