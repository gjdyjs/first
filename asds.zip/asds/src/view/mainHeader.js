import React, { Component } from 'react';
import { Layout, Menu, Row,Col } from 'antd';
import {Link} from 'react-router-dom';
import '../css/mainHeader.css';
const { Header } = Layout;
export default class MainHeader extends Component{
    render(){
        return(
            <Layout>
                <Header className="header">
                    <Row>
                        <Col style = {{color:"white"}} md = {18}>
                        斡旋品発注システム
                        </Col>
                        <Col style = {{textAlign:"right"}} md = {6}>
                            <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']} >
                                <Menu.Item key="1">マニュアル</Menu.Item>
                                <Menu.Item key="2">注文履歴</Menu.Item>
                                <Menu.Item key="3"><Link to="/">ログアウト</Link></Menu.Item>
                            </Menu>
                        </Col>
                    </Row>
                </Header>
                <Row style={{ margin: '10px 0'}}>
                        <Col md = {8}>
                            <select style = {{width:"80%",height:"25px",marginLeft:"10px"}}>
                                <option>sdfsdfsdf</option>
                                <option>sdfsdfsdf</option>
                                <option>sdfsdfsdf</option>
                            </select>
                        </Col>
                        <Col md = {12} >
                            <input type = "text"  style = {{width:"80%"}} placeholder = "商品"/>
                            <input type = "button" value = "検索"/>
                        </Col>
                        <Col md = {4}>
                            <input type = "checkbox" />予約斡旋品のみ
                        </Col>
                </Row>
            </Layout>
        )
    }

}