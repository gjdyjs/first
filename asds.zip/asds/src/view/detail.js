import React, { Component } from 'react';
import axios from 'axios';
export default class Detail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            list:[]
        }
        let id = this.props.match.params.id;
        this.getData(id);
    }
    getData(id){

        // this.props.dispatch((dispatch)=>{
        //     dispatch({
        //         type:"DETAILS_UPDATA"
        //     });
        //     axios.get(`https://cnodejs.org/api/v1/topic/${id}`)
        //         .then((res)=>{
        //             dispatch({
        //                 type:"DETAILS_UPDATA_SUCC",
        //                 data:res.data
        //             });
        //         })
        //         .catch(()=>{
        //             dispatch({
        //                 type:"DETAILS_UPDATA_ERROR",
        //             });
        //         })
        // })
        axios.get(`./list.json/${id}`)
        .then((response)=>{
            console.log(response.data);
            this.setState({
                list:response.data.data
            })
            
        })
        .catch(function(error){
            console.error();
        })
    }
    render(){
        return(
            <div>
                sdgsdgdf
            </div>
        )
    }
}