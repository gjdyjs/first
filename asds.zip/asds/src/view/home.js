import React, { Component } from 'react';
import MainHeader from './mainHeader';
import Sub from './sub';
export default class Home extends Component{
    render(){
        return(
            <div>
                <MainHeader/>
                <Sub/>
            </div>
        )
    }
}