import React, { Component } from 'react';
import RouterIndex from "./router/index";
export default class App extends Component{
    render(){
      return (
        <div>
          <RouterIndex/>
        </div>
      )
    }
}

