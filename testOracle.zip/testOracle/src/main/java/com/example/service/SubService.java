package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Sub;
import com.example.mapper.SubMapper;

@Service
public class SubService {

    @Autowired
    SubMapper subMapper;
    public List<Sub> SelectForSub(){
        return subMapper.SelectForSub();
    }

}