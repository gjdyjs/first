import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
const styles = theme => ({
      root: {
        display: 'flex',
      },
});
class AddressInfo extends Component{
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <TableContainer component={Paper}>
                <div style={{width:"100%"}}>
                <Table aria-label="caption table">
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            入力者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>担当部署</TableCell>
                        <TableCell align="left">サンプル担当部署</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>担当者</TableCell>
                        <TableCell align="left">サンプル担当者</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            注文者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>注文者＃</TableCell>
                        <TableCell align="left">11111111:サンプル担当部署</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            発送先
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>発送先＃</TableCell>
                        <TableCell align="left">11111111:サンプル発送先</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>発送先部署</TableCell>
                        <TableCell align="left">サンプル発送先部署</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>郵便番号</TableCell>
                        <TableCell align="left">111-1111</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>住所</TableCell>
                        <TableCell align="left">サンプル県サンプル市サンプル1111</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>電話番号</TableCell>
                        <TableCell align="left">111-1111-1111</TableCell>
                    </TableRow>
                </Table>
                </div>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(AddressInfo);