import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import AddressInfo from './addressInfo';
import GoodsList from './goodsList';
const styles = theme => ({
    root: {
        display: 'flex',
      },
});
class PrintIndex extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <Container maxWidth="lg" >
                    <Toolbar/>
                    <br/>
                    <GoodsList id = {id}/>
                    <br/>
                    <AddressInfo/>
                    <br/>
                </Container>
            </div>
        )
    }
}
export default withStyles(styles)(PrintIndex);