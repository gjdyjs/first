import React, { Component } from 'react';
import {Link} from "react-router-dom";
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import axios from 'axios';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 80,
      },
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class CartList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            total:'',
            list:[]
        };  
    }
    componentDidMount(){
        this.getData(this.props.match.params.id)
    }
    getData(id){
        axios.get(`/workTable/${id}`)
           .then((res)=>{
               this.setState({
                   list:res.data
               })
               console.log(this.state.list)
               this.allPrice()
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.price)*Number(item.count)
        }
        this.setState({
            total:allPrice
        })
    }
    handleCount=(e)=>{
        this.state.list.find(item=>item.id==e.target.name).count=e.target.value
    }
    getRealStorage=(count,id)=>{
        axios.get(`/getStorage/${id}`)
        .then((res)=>{
            if(((res.data.find(item=>item.id==id).storage)-count)>=0){
                    axios.put("/change",`id=${id}&count=${count}`)
                    .then((res)=>{
                        this.getData(this.props.match.params.id)
                        window.location.reload()
                    })
                    .catch((error)=>{
                        console.log(error)
                    })  
            }else{
                console.log(count,res.data.find(item=>item.id==id).storage)
                this.forceUpdate()
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doChange=(id,count)=>{
    const result1 = /^\d+$/.test(count)
    const result2 = /^([1-9]\d*|0)$/.test(count)
            if(count.length!=0){
                if(result1){
                    if(count>0){
                        if(result2){
                            this.getRealStorage(count,id)
                        }else{
                            alert("頭数字を0以外で入力してください")
                        }
                    }else{
                        alert("最小値は1です")
                    }
                }else{
                    alert("数字または整数を入力してください")
                }
            }else{
                alert("新たな注文数を入力してください")
            }
    }
    doDelete=(id)=>{
        console.log(id)
        axios.delete("/delete",{
            params:{
                id:id
            }
        }).then(res=>{
            this.getData(this.props.match.params.id)
            window.location.reload()
        })  
    }
    doSubmit=(e)=>{
        e.preventDefault();
        axios({
            method: 'post',
            url: "/post",
            data: {
                total:this.state.total,
                data:this.state.list
            }
          }).then(res=>{

          });
        this.props.history.push(`/address/${this.props.match.params.id}`);
    }
    doJump=()=>{
        this.props.history.push("/");
    }
    render(){
        const { classes } = this.props;
        return(
            <div className = "cartList" style = {{textAlign:"left"}}>
                <br/>
                <Link to = '/'>ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;カート内容
                <hr/>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                    <div>
                                        <img width={280} src={value.pic} style = {{float:"left"}}/>
                                        <div style = {{textAlign:"left"}}>  
                                            <h1>{value.itemName}</h1> 
                                            担当部署：{value.szk}<br/>
                                            在庫数：{value.storage-value.count}<br/>
                                            価額：￥{Number(value.price).toLocaleString('en-US')}<br/>
                                            <br/>
                                            <div>
                                            注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" name={value.id} defaultValue = {value.count} onChange = {this.handleCount}/>
                                                <Button color="primary" variant="outlined" className={classes.button} onClick = {()=>this.doChange(value.id,this.state.list.find(item=>item.id==value.id).count)}>
                                                    変更
                                                </Button>
                                                <Button color="primary" variant="outlined" className={classes.button} onClick = {()=>this.doDelete(value.id)}>
                                                    削除
                                                </Button>
                                            </div> 
                                        </div>
                                    </div>
                                    <hr/>
                                </div>
                        })
                    }
                </div>
                <div style = {{position:"absolute",left:"1600px",top:"200px"}}>
                    <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"300px"}}>
                        <br/>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                            <br/>
                            <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doSubmit}>
                                購入手続き　
                            </Button>
                            <br/><br/>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doJump}>
                                ホーム画面に戻る
                            </Button>
                            </div>
                    </form>
                </div>
            </div>  
        )
    }
}
export default withStyles(styles)(withRouter(CartList));