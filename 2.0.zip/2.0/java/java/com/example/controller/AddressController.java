package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.service.AddressService;

@RestController

public class AddressController {
    @Autowired
    private AddressService addressService;
    @RequestMapping(value = "/getUserInfoAuto/{key}",method= RequestMethod.GET)
    public String AutoGetUser(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(addressService.SelectAuto(key).toString());
    	return addressService.SelectAuto(key).toString();
    }
    @RequestMapping(value = "/getAddressInfoAuto/{key}",method= RequestMethod.GET)
    public String AutoGetAddress(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(addressService.SelectAuto(key).toString());
    	return addressService.SelectAuto(key).toString();
    }
    @RequestMapping(value = "/getUserInfo/{key}",method= RequestMethod.GET)
    public String GetList(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(addressService.SelectForUser(key).toString());
    	return addressService.SelectForUser(key).toString();
    }
    @RequestMapping(value = "/getAddInfo/{key}",method= RequestMethod.GET)
    public String GetAddInfo(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(addressService.SelectForAdd(key).toString());
    	return addressService.SelectForAdd(key).toString();
    }
}
