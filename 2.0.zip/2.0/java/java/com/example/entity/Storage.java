package com.example.entity;

public class Storage {
	private int id;
	private int storage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStorage() {
		return storage;
	}
	public void setStorage(int storage) {
		this.storage = storage;
	}
    @Override
    public String toString() {
        return "{" +
        	"\"id\":\""+id+"\""+
        	",\"storage\":\""+storage+"\""+
       '}';
    }
}
