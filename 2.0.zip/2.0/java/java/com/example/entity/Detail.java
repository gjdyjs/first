package com.example.entity;

public class Detail {
	private String itemName;
	private String detail;
	private int id;
	private int storage;
	private String szk;
	private String jungle;
	private int price;
	private String pic;
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStorage() {
		return storage;
	}
	public void setStorage(int storage) {
		this.storage = storage;
	}
	public String getSzk() {
		return szk;
	}
	public void setSzk(String szk) {
		this.szk = szk;
	}
	public String getJungle() {
		return jungle;
	}
	public void setJungle(String jungle) {
		this.jungle = jungle;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}

    @Override
    public String toString() {
        return "{" +
        	"\"id\":\""+id+"\""+
        	",\"itemName\":\""+itemName+"\""+
        	",\"detail\":\""+detail+"\""+
        	",\"pic\":\""+pic+"\""+
        	",\"price\":\""+price+"\""+
        	",\"storage\":\""+storage+"\""+
        	",\"jungle\":\""+jungle+"\""+
        	",\"szk\":\""+szk+"\""+
       '}';
    }
}
