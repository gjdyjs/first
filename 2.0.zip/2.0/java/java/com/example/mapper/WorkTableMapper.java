package com.example.mapper; 

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import com.example.entity.WorkTable;

@Repository
@Mapper
public interface WorkTableMapper {
    List<WorkTable> SelectForList(String id);
    void DeleteItem(int id);
    void UpdateItem(int id,int count);
    void InseretItem();
    int SelectForCount(String id);
}