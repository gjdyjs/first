let tab = [
    {
        tab:"all",
        txt: "全部",
        isIndex: true
    },
    {
        tab: "top",
        color: "magenta",
        txt: "置顶",
        isIndex: false
    },
    {
        tab:"good",
        txt: "精华",
        isIndex: true,
        color: "geekblue"
    },
    {
        tab:"ask",
        txt: "问题",
        isIndex: true
    },
    {
        tab:"share",
        txt: "分享",
        isIndex: true,
        color: "purple"
    },
    {
        tab:"job",
        txt: "招聘",
        isIndex: true,
        color: "cyan"
    },
    {
        tab:"dev",
        txt: "测试",
        isIndex: true,
        color: "lime"
    }
];
export default tab;