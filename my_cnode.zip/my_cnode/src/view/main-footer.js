import React,{Component} from "react";
import {Layout,Row,Col,Divider} from "antd";

export default class MainFooter extends Component{
    render(){
        return (
            <Layout.Footer style = {{textAlign:"center"}}>
                <h4>维多利亚的秘密</h4>
            </Layout.Footer>
        );
    }
}