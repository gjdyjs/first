package com.example.controller;
 
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.service.IndexlistService;
import com.google.gson.Gson;

@RestController

public class IndexListController {
    @Autowired
    private IndexlistService indexlistService;
    @RequestMapping(value = "/list/{data}",method= RequestMethod.GET)
    public String GetList(@PathVariable("data") String params){
    	System.out.println(params);
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	String goodsid=(String) map.get("id");
    	String goodsJungle=(String) map.get("jungle");
    	String goodsJungleName=(String) map.get("jungleName");
    	Double goodsFlag=(Double) map.get("flag");
    	System.out.println(indexlistService.SelectForList(goodsid,goodsJungleName).toString());
    	return indexlistService.SelectForList(goodsid,goodsJungleName).toString();
    }
    @RequestMapping(value = "/sort",method= RequestMethod.GET)
    public String Sort(@RequestParam String id,@RequestParam int sortKey,@RequestParam String jungleCd,@RequestParam String jungleName,@RequestParam Double flag){
    	System.out.println(id);
    	System.out.println(sortKey);
    	System.out.println(jungleCd);
    	System.out.println(jungleName);
    	System.out.println(flag);
    	String result = null;
    	switch(sortKey){
        case 10 :
        	
           break;
        case 20 :
        	
           break;
        case 30 :

            break;
        case 40 :
        	result = indexlistService.SelectForSortDesc(id,jungleName).toString();
        	break;
        case 50 :
        	result = indexlistService.SelectForSortAsc(id,jungleName).toString();
            break;
        default :
    	}
    	System.out.println(result);
		return result;
    }
}
