package com.example.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class FileDownloadController {
//    @RequestMapping(value = "/download",method= RequestMethod.GET)
//    public ResponseEntity download() throws IOException {
//        File file = new File("HelloWorld.pdf");
//        InputStream in = new FileInputStream(file);
//        final HttpHeaders headers = new HttpHeaders();
//        headers.add("Content-Type", "application/pdf");
//        headers.add("Content-Disposition", "attachment; filename=" + file.getName() );
//        return new ResponseEntity<>(IOUtils.toByteArray(in), headers, HttpStatus.OK);
//    }
}
