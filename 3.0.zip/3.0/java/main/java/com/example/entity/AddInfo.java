package com.example.entity;

public class AddInfo {
	private String user_name;
	private int id;
	private int user_id;
	private String address_szk;
	private String address_name;
	private int address_id;
	private String address;
	private int post;
	private Long phone_num;
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getAddress_szk() {
		return address_szk;
	}
	public void setAddress_szk(String address_szk) {
		this.address_szk = address_szk;
	}
	public String getAddress_name() {
		return address_name;
	}
	public void setAddress_name(String address_name) {
		this.address_name = address_name;
	}
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPost() {
		return post;
	}
	public void setPost(int post) {
		this.post = post;
	}
	public Long getPhone_num() {
		return phone_num;
	}
	public void setPhone_num(Long phone_num) {
		this.phone_num = phone_num;
	}
	
    @Override
    public String toString() {
        return "{" +
        	"\"id\":\""+id+"\""+
        	",\"user_id\":\""+user_id+"\""+
        	",\"user_name\":\""+user_name+"\""+
        	",\"address_szk\":\""+address_szk+"\""+
        	",\"address_name\":\""+address_name+"\""+
        	",\"address_id\":\""+address_id+"\""+
        	",\"address\":\""+address+"\""+
        	",\"post\":\""+post+"\""+
        	",\"phone_num\":\""+phone_num+"\""+
       '}';
    }
	
}
