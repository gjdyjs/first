package com.example.entity;

public class Sub {
	private int category_cd;
	private String category_name;
	 
    public int getCategory_cd() {
		return category_cd;
	}

	public void setCategory_cd(int category_cd) {
		this.category_cd = category_cd;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	@Override
    public String toString() {
        return "{" +
        	"\"category_cd\":\""+category_cd+"\""+
        	",\"category_name\":\""+category_name+"\""+
       '}';
    }
}
