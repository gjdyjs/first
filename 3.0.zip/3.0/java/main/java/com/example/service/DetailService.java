package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.AddCart;
import com.example.entity.Detail;
import com.example.entity.Storage;
import com.example.mapper.DetailMapper;

@Service
public class DetailService {

    @Autowired
    DetailMapper detailMapper;
    public List<Detail> SelectForDetail(String id){
        return detailMapper.SelectForDetail(id);
    }
    public List<Storage> SelectForStorage(int id){
        return detailMapper.SelectForStorage(id);
    }
    public void InsertCart(String id,String itemName,int storage,String detail,String szk,String jungle,int price,String pic,String count,String user_id){
        detailMapper.InsertCart(id,itemName,storage,detail,szk,jungle,price,pic,count,user_id);
    }
}