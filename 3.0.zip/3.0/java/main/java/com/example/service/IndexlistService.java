package com.example.service;


import com.example.entity.IndexLists;
import com.example.mapper.IndexListMapper;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IndexlistService {
	
    @Autowired
    IndexListMapper indexlistMapper;
    public List<IndexLists> SelectForList(String key1,String key2){
        return indexlistMapper.SelectForList(key1,key2);
    }
    public List<IndexLists> SelectForSortDesc(String key1,String key2){
        return indexlistMapper.SelectForSortDesc(key1,key2);
    }
    public List<IndexLists> SelectForSortAsc(String key1,String key2){
        return indexlistMapper.SelectForSortAsc(key1,key2);
    }
}