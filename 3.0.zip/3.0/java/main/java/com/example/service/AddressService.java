package com.example.service;

import com.example.entity.AddInfo;
import com.example.mapper.BuyUserListsMapper;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddressService {

    @Autowired
    BuyUserListsMapper buyUserListsMapper;
    public List<AddInfo> SelectAuto(String key){
        return buyUserListsMapper.SelectAuto(key);
    }
    public List<AddInfo> SelectForUser(String key){
        return buyUserListsMapper.SelectForUser(key);
    }
    public List<AddInfo> SelectForAdd(String key){
        return buyUserListsMapper.SelectForAdd(key);
    }

}