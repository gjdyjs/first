--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-10��-09-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ADDRESSINFO
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."ADDRESSINFO" 
   (	"ID" NUMBER(10,0), 
	"USER_ID" NUMBER(10,0), 
	"USER_NAME" VARCHAR2(50 BYTE), 
	"ADDRESS_ID" NUMBER(10,0), 
	"ADDRESS_NAME" VARCHAR2(50 BYTE), 
	"ADDRESS_SZK" VARCHAR2(50 BYTE), 
	"ADDRESS" VARCHAR2(50 BYTE), 
	"POST" NUMBER(7,0), 
	"PHONE_NUM" NUMBER(11,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table A_MST_CATEGORY
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."A_MST_CATEGORY" 
   (	"CATEGORY_CD" NUMBER, 
	"CATEGORY_NAME" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table BUYERLIST
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."BUYERLIST" 
   (	"ID" NUMBER, 
	"USER_ID" NUMBER, 
	"NAME" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table CARTLIST
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."CARTLIST" 
   (	"LISTNO" NUMBER(10,0), 
	"ID" NUMBER(10,0), 
	"ITEMNAME" VARCHAR2(50 BYTE), 
	"STORAGE" NUMBER(10,0), 
	"DETAIL" VARCHAR2(500 BYTE), 
	"SZK" VARCHAR2(10 BYTE), 
	"JUNGLE" VARCHAR2(10 BYTE), 
	"PRICE" NUMBER(10,0), 
	"PIC" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table CART_HISTORY
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."CART_HISTORY" 
   (	"BUY_NO" NUMBER(10,0), 
	"ID" NUMBER(10,0), 
	"ITEMNAME" VARCHAR2(50 BYTE), 
	"SZK" VARCHAR2(10 BYTE), 
	"COUNT" NUMBER(10,0), 
	"PRICE" NUMBER(10,0), 
	"PIC" VARCHAR2(100 BYTE), 
	"USER_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table CART_HISTORY_ADD
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."CART_HISTORY_ADD" 
   (	"BUY_NO" NUMBER, 
	"BUYDATE" DATE, 
	"USER_ID" NUMBER, 
	"USER_NAME" VARCHAR2(50 BYTE), 
	"ADDRESS_ID" NUMBER, 
	"ADDRESS_NAME" VARCHAR2(50 BYTE), 
	"ADDRESS_SZK" VARCHAR2(50 BYTE), 
	"ADDRESS" VARCHAR2(50 BYTE), 
	"POST" NUMBER, 
	"PHONE_NUM" NUMBER, 
	"TOTAL" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table GOODS
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."GOODS" 
   (	"ID" NUMBER(10,0), 
	"ITEMNAME" VARCHAR2(50 BYTE), 
	"STORAGE" NUMBER(10,0), 
	"DETAIL" VARCHAR2(500 BYTE), 
	"SZK" VARCHAR2(20 BYTE), 
	"JUNGLE" VARCHAR2(10 BYTE), 
	"PRICE" NUMBER(10,0), 
	"PIC" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Table WORKTABLE
--------------------------------------------------------

  CREATE TABLE "C##ADMIN"."WORKTABLE" 
   (	"ID" NUMBER(10,0), 
	"ITEMNAME" VARCHAR2(50 BYTE), 
	"STORAGE" NUMBER(10,0), 
	"DETAIL" VARCHAR2(500 BYTE), 
	"SZK" VARCHAR2(20 BYTE), 
	"JUNGLE" VARCHAR2(10 BYTE), 
	"PRICE" NUMBER(10,0), 
	"PIC" VARCHAR2(100 BYTE), 
	"COUNT" NUMBER(20,0), 
	"USER_ID" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
REM INSERTING into C##ADMIN.ADDRESSINFO
SET DEFINE OFF;
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (1,100001,'�T���v���_��1�����g��',100001,'�T���v��������1','�T���v�������敔��1','�����s��c���Z��2-35-1',1440045,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (2,100002,'�T���v���_��2�����g��',100002,'�T���v��������2','�T���v�������敔��2','�����s��c��슗�c2-35-1',1440046,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (3,100003,'�T���v���_��3�����g��',100003,'�T���v��������3','�T���v�������敔��3','�����s��c�搼�Z��2-35-1',1440047,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (4,100004,'�T���v���_��4�����g��',100004,'�T���v��������4','�T���v�������敔��4','�����s������V����3-5-1',1440048,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (5,100005,'�T���v���_��5�����g��',100005,'�T���v��������5','�T���v�������敔��5','�����s��c���Z��2-35-1',1450045,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (6,100006,'�T���v���_��6�����g��',100006,'�T���v��������6','�T���v�������敔��6','�����s��c���Z��2-35-1',1480025,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (7,100007,'�T���v���_��7�����g��',100007,'�T���v��������7','�T���v�������敔��7','�����s��c���Z��2-35-1',1490041,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (8,100008,'�T���v���_��8�����g��',100008,'�T���v��������8','�T���v�������敔��8','�����s��c���Z��2-35-1',1500029,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (9,100009,'�T���v���_��9�����g��',100009,'�T���v��������9','�T���v�������敔��9','�����s��c���Z��2-35-1',1080035,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (10,100010,'�T���v���_��10�����g��',100010,'�T���v��������10','�T���v�������敔��10','�����s��c���Z��2-35-1',1240075,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (11,100011,'�T���v���_��11�����g��',100011,'�T���v��������11','�T���v�������敔��11','�����s��c���Z��2-35-1',1340095,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (12,100012,'�T���v���_��12�����g��',100012,'�T���v��������12','�T���v�������敔��12','�����s��c���Z��2-35-1',2010077,8012345678);
Insert into C##ADMIN.ADDRESSINFO (ID,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM) values (13,100013,'�T���v���_��13�����g��',100013,'�T���v��������13','�T���v�������敔��13','�����s��c���Z��2-35-1',9110005,8012345678);
REM INSERTING into C##ADMIN.A_MST_CATEGORY
SET DEFINE OFF;
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (1,'����');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (2,'�c�_');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (3,'�n��U��');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (4,'��������');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (5,'�o�c');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (6,'�č��@�\');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (7,'���ăO�b�Y');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (8,'�L��');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (9,'�N�����G��');
Insert into C##ADMIN.A_MST_CATEGORY (CATEGORY_CD,CATEGORY_NAME) values (10,'����JA');
REM INSERTING into C##ADMIN.BUYERLIST
SET DEFINE OFF;
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (1,100001,'�T���v��1�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (2,100002,'�T���v��2�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (3,100003,'�T���v��3�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (4,100004,'�T���v��4�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (5,100005,'�T���v��5�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (6,100006,'�T���v��6�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (7,100007,'�T���v��7�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (8,100008,'�T���v��8�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (9,100009,'�T���v��9�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (10,100010,'�T���v��10�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (11,100011,'�T���v��11�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (12,100012,'�T���v��12�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (13,100013,'�T���v��13�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (14,100014,'�T���v��14�_�Ƌ����g��');
Insert into C##ADMIN.BUYERLIST (ID,USER_ID,NAME) values (15,100015,'�T���v��15�_�Ƌ����g��');
REM INSERTING into C##ADMIN.CARTLIST
SET DEFINE OFF;
REM INSERTING into C##ADMIN.CART_HISTORY
SET DEFINE OFF;
Insert into C##ADMIN.CART_HISTORY (BUY_NO,ID,ITEMNAME,SZK,COUNT,PRICE,PIC,USER_ID) values (1,1,'�����S','����',10,600,'http://localhost:8080/img/pinguo.jpg',100001);
Insert into C##ADMIN.CART_HISTORY (BUY_NO,ID,ITEMNAME,SZK,COUNT,PRICE,PIC,USER_ID) values (1,2,'�o�i�i','�c�_',10,700,'http://localhost:8080/img/xiangjiao.jpg',100001);
REM INSERTING into C##ADMIN.CART_HISTORY_ADD
SET DEFINE OFF;
Insert into C##ADMIN.CART_HISTORY_ADD (BUY_NO,BUYDATE,USER_ID,USER_NAME,ADDRESS_ID,ADDRESS_NAME,ADDRESS_SZK,ADDRESS,POST,PHONE_NUM,TOTAL) values (1,to_date('20-10-08','RR-MM-DD'),100001,'�T���v���_�Ƌ����g��',100001,'�T���v���_�Ƌ����g��','100001','�����s�����V����',1450045,8042603035,13000);
REM INSERTING into C##ADMIN.GOODS
SET DEFINE OFF;
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (1,'�����S',150,'icrosoftr more informas 10','����','fruit5',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (2,'�o�i�i',250,'icrosoftr more informas 10','�c�_','fruit',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (3,'�X�C�J',150,'icrosoftr more informas 10','�n��U��','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (4,'�~�J��',25130,'icrosoftr more informas 10','��������','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (5,'�C�`�S',13450,'icrosoftr more informas 10','�o�c','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (6,'�g�}�g',25230,'icrosoftr more informas 10','�č��@�\','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (7,'�L���E��',15430,'icrosoftr more informas 10','���ăO�b�Y','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (8,'����',23250,'icrosoftr more informas 10','�L��','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (9,'�i�X',6250,'icrosoftr more informas 10','�N�����G��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (10,'�����S',1540,'icrosoftr more informas 10','����JA','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (11,'�o�i�i',2550,'icrosoftr more informas 10','����','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (12,'�X�C�J',150,'icrosoftr more informas 10','�c�_','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (13,'�~�J��',25130,'icrosoftr more informas 10','�n��U��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (14,'�C�`�S',13450,'icrosoftr more informas 10','��������','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (15,'�g�}�g',25230,'icrosoftr more informas 10','�o�c','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (16,'�L���E��',15430,'icrosoftr more informas 10','�č��@�\','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (17,'����',23250,'icrosoftr more informas 10','���ăO�b�Y','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (18,'�i�X',6250,'icrosoftr more informas 10','�L��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (19,'���',6250,'icrosoftr more informas 10','�N�����G��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (20,'�����S',1540,'icrosoftr more informas 10','����JA','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (21,'�o�i�i',2550,'icrosoftr more informas 10','����','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (22,'�X�C�J',150,'icrosoftr more informas 10','�c�_','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (23,'�~�J��',25130,'icrosoftr more informas 10','�n��U��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (24,'�C�`�S',13450,'icrosoftr more informas 10','��������','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (25,'�g�}�g',25230,'icrosoftr more informas 10','�o�c','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (26,'�L���E��',15430,'icrosoftr more informas 10','�č��@�\','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (27,'����',23250,'icrosoftr more informas 10','���ăO�b�Y','fruit5',123456789,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (28,'�i�X',6250,'icrosoftr more informas 10','�L��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (29,'�����S',1540,'icrosoftr more informas 10','�N�����G��','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (30,'�o�i�i',2550,'icrosoftr more informas 10','����JA','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (31,'�X�C�J',150,'icrosoftr more informas 10','����','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (32,'�~�J��',25130,'icrosoftr more informas 10','�c�_','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (33,'�C�`�S',13450,'icrosoftr more informas 10','�n��U��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (34,'�g�}�g',25230,'icrosoftr more informas 10','��������','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (35,'�L���E��',15430,'icrosoftr more informas 10','�o�c','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (36,'����',23250,'icrosoftr more informas 10','�č��@�\','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (37,'�i�X',6250,'icrosoftr more informas 10','���ăO�b�Y','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (38,'�C�`�S',6250,'icrosoftr more informas 10','�L��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (39,'�����S',1540,'icrosoftr more informas 10','�N�����G��','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (40,'�o�i�i',2550,'icrosoftr more informas 10','����JA','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (41,'�X�C�J',150,'icrosoftr more informas 10','����','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (42,'�~�J��',25130,'icrosoftr more informas 10','�c�_','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (43,'�C�`�S',13450,'icrosoftr more informas 10','�n��U��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (44,'�g�}�g',25230,'icrosoftr more informas 10','��������','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (45,'�L���E��',15430,'icrosoftr more informas 10','�o�c','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (46,'����',23250,'icrosoftr more informas 10','�č��@�\','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (47,'�i�X',6250,'icrosoftr more informas 10','���ăO�b�Y','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (48,'�����S',1540,'icrosoftr more informas 10','�L��','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (49,'�o�i�i',2550,'icrosoftr more informas 10','�N�����G��','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (50,'�X�C�J',150,'icrosoftr more informas 10','����JA','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (51,'�~�J��',25130,'icrosoftr more informas 10','����','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (52,'�C�`�S',13450,'icrosoftr more informas 10','�c�_','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (53,'�g�}�g',25230,'icrosoftr more informas 10','�n��U��','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (54,'�L���E��',15430,'icrosoftr more informas 10','��������','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (55,'����',23250,'icrosoftr more informas 10','�o�c','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (56,'�i�X',6250,'icrosoftr more informas 10','�č��@�\','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (57,'�C�`�S',6250,'icrosoftr more informas 10','���ăO�b�Y','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (58,'�����S',1540,'icrosoftr more informas 10','�L��','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (59,'�o�i�i',2550,'icrosoftr more informas 10','�N�����G��','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (60,'�X�C�J',150,'icrosoftr more informas 10','����JA','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (61,'�~�J��',25130,'icrosoftr more informas 10','����','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (62,'�C�`�S',13450,'icrosoftr more informas 10','�c�_','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (63,'�g�}�g',25230,'icrosoftr more informas 10','�n��U��','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (64,'�L���E��',15430,'icrosoftr more informas 10','��������','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (65,'����',23250,'icrosoftr more informas 10','�o�c','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (66,'�i�X',6250,'icrosoftr more informas 10','�č��@�\','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (67,'�����S',1540,'icrosoftr more informas 10','���ăO�b�Y','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (69,'�X�C�J',150,'icrosoftr more informas 10','�N�����G��','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (70,'�~�J��',25130,'icrosoftr more informas 10','����JA','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (71,'�C�`�S',13450,'icrosoftr more informas 10','����','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (72,'�g�}�g',25230,'icrosoftr more informas 10','�c�_','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (73,'�L���E��',15430,'icrosoft','�n��U��','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (74,'����',23250,'icrosoftr more informas 10','��������','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (75,'�i�X',6250,'icrosoftr more informas 10','�o�c','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (76,'�C�`�S',6250,'icrosoftr more informas 10','�č��@�\','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (77,'�����S',1540,'icrosoftr more informas 10','���ăO�b�Y','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (68,'�o�i�i',2550,'icrosoftr more informas 10','�L��','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (78,'�o�i�i',2550,'icrosoftr more informas 10','�L��','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (79,'�X�C�J',150,'icrosoftr more informas 10','�N�����G��','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (80,'�~�J��',25130,'icrosoftr more informas 10','����JA','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (81,'�C�`�S',13450,'icrosoftr more informas 10','����','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (82,'�g�}�g',25230,'icrosoftr more informas 10','�c�_','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (83,'�L���E��',15430,'icrosoftr more informas 10','�n��U��','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (84,'����',23250,'icrosoftr more informas 10','��������','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (85,'�i�X',6250,'icrosoftr more informas 10','�o�c','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (86,'�����S',1540,'icrosoftr more informas 10','�č��@�\','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (87,'�o�i�i',2550,'icrosoftr more informas 10','���ăO�b�Y','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (88,'�X�C�J',150,'icrosoftr more informas 10','�L��','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (89,'�~�J��',25130,'icrosoftr more informas 10','�N�����G��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (90,'�C�`�S',13450,'icrosoftr more informas 10','����JA','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (91,'�g�}�g',25230,'icrosoftr more informas 10','����','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (92,'�L���E��',15430,'icrosoftr more informas 10','�c�_','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (93,'����',23250,'icrosoftr more informas 10','�n��U��','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (94,'�i�X',6250,'icrosoftr more informas 10','��������','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (95,'���',6250,'icrosoftr more informas 10','�o�c','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (96,'�����S',1540,'icrosoftr more informas 10','�č��@�\','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (97,'�o�i�i',2550,'icrosoftr more informas 10','���ăO�b�Y','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (98,'�X�C�J',150,'icrosoftr more informas 10','�L��','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (99,'�~�J��',25130,'icrosoftr more informas 10','�N�����G��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (100,'�C�`�S',13450,'icrosoftr more informas 10','����JA','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (101,'�g�}�g',25230,'icrosoftr more informas 10','����','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (102,'�L���E��',15430,'icrosoftr more informas 10','�c�_','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (103,'����',23250,'icrosoftr more informas 10','�n��U��','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (104,'�i�X',6250,'icrosoftr more informas 10','��������','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (105,'�����S',1540,'icrosoftr more informas 10','�o�c','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (106,'�o�i�i',2550,'icrosoftr more informas 10','�č��@�\','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (107,'�X�C�J',150,'icrosoftr more informas 10','���ăO�b�Y','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (108,'�~�J��',25130,'icrosoftr more informas 10','�L��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (109,'�C�`�S',13450,'icrosoftr more informas 10','�N�����G��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (110,'�g�}�g',25230,'icrosoftr more informas 10','����JA','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (111,'�L���E��',15430,'icrosoftr more informas 10','����','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (112,'����',23250,'icrosoftr more informas 10','�c�_','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (113,'�i�X',6250,'icrosoftr more informas 10','�n��U��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (114,'�C�`�S',6250,'icrosoftr more informas 10','��������','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (115,'�����S',1540,'icrosoftr more informas 10','�o�c','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (116,'�o�i�i',2550,'icrosoftr more informas 10','�č��@�\','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (117,'�X�C�J',150,'icrosoftr more informas 10','���ăO�b�Y','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (118,'�~�J��',25130,'icrosoftr more informas 10','�L��','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (119,'�C�`�S',13450,'icrosoftr more informas 10','�N�����G��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (120,'�g�}�g',25230,'icrosoftr more informas 10','����JA','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (121,'�L���E��',15430,'icrosoftr more informas 10','����','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (122,'����',23250,'icrosoftr more informas 10','�c�_','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (123,'�i�X',6250,'icrosoftr more informas 10','�n��U��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (124,'�����S',1540,'icrosoftr more informas 10','��������','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (125,'�o�i�i',2550,'icrosoftr more informas 10','�o�c','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (126,'�X�C�J',150,'icrosoftr more informas 10','�č��@�\','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (127,'�~�J��',25130,'icrosoftr more informas 10','���ăO�b�Y','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (128,'�C�`�S',13450,'icrosoftr more informas 10','�L��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (129,'�g�}�g',25230,'icrosoftr more informas 10','�N�����G��','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (130,'�L���E��',15430,'icrosoftr more informas 10','����JA','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (131,'����',23250,'icrosoftr more informas 10','����','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (132,'�i�X',6250,'icrosoftr more informas 10','�c�_','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (133,'�C�`�S',6250,'icrosoftr more informas 10','�n��U��','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (134,'�����S',1540,'icrosoftr more informas 10','��������','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (135,'�o�i�i',2550,'icrosoftr more informas 10','�o�c','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (136,'�X�C�J',150,'icrosoftr more informas 10','�č��@�\','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (137,'�~�J��',25130,'icrosoftr more informas 10','���ăO�b�Y','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (138,'�C�`�S',13450,'icrosoftr more informas 10','�L��','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (139,'�g�}�g',25230,'icrosoftr more informas 10','�N�����G��','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (140,'�L���E��',15430,'icrosoftr more informas 10','����JA','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (141,'����',23250,'icrosoftr more informas 10','����','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (142,'�i�X',6250,'icrosoftr more informas 10','�c�_','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (143,'�����S',1540,'icrosoftr more informas 10','�n��U��','fruit1',600,'http://localhost:8080/img/pinguo.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (144,'�o�i�i',2550,'icrosoftr more informas 10','��������','fruit2',700,'http://localhost:8080/img/xiangjiao.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (145,'�X�C�J',150,'icrosoftr more informas 10','�o�c','fruit3',600,'http://localhost:8080/img/xigua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (146,'�~�J��',25130,'icrosoftr more informas 10','�č��@�\','fruit4',700,'http://localhost:8080/img/juzi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (147,'�C�`�S',13450,'icrosoftr more informas 10','���ăO�b�Y','fruit5',600,'http://localhost:8080/img/caomei.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (148,'�g�}�g',25230,'icrosoftr more informas 10','�L��','vegetable2',700,'http://localhost:8080/img/fanqie.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (149,'�L���E��',15430,'icrosoftr more informas 10','�N�����G��','vegetable1',600,'http://localhost:8080/img/huanggua.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (150,'����',23250,'icrosoftr more informas 10','����JA','fruit5',700,'http://localhost:8080/img/taozi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (151,'�i�X',6250,'icrosoftr more informas 10','����','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
Insert into C##ADMIN.GOODS (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC) values (152,'�C�`�S',6250,'icrosoftr more informas 10','�c�_','vegetable1',700,'http://localhost:8080/img/qiezi.jpg');
REM INSERTING into C##ADMIN.WORKTABLE
SET DEFINE OFF;
Insert into C##ADMIN.WORKTABLE (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC,COUNT,USER_ID) values (3,'�X�C�J',150,'icrosoftr more informas 10','�n��U��','fruit3',600,'http://localhost:8080/img/xigua.jpg',1,'100001');
Insert into C##ADMIN.WORKTABLE (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC,COUNT,USER_ID) values (4,'�~�J��',25130,'icrosoftr more informas 10','��������','fruit4',700,'http://localhost:8080/img/juzi.jpg',1,'100001');
Insert into C##ADMIN.WORKTABLE (ID,ITEMNAME,STORAGE,DETAIL,SZK,JUNGLE,PRICE,PIC,COUNT,USER_ID) values (105,'�����S',1540,'icrosoftr more informas 10','�o�c','fruit1',600,'http://localhost:8080/img/pinguo.jpg',3,'100001');
--------------------------------------------------------
--  DDL for Index PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##ADMIN"."PK" ON "C##ADMIN"."GOODS" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Index PRINT_INDEX1
--------------------------------------------------------

  CREATE INDEX "C##ADMIN"."PRINT_INDEX1" ON "C##ADMIN"."CART_HISTORY_ADD" ("BUY_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  DDL for Index WORKTABLE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##ADMIN"."WORKTABLE_PK" ON "C##ADMIN"."WORKTABLE" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST" ;
--------------------------------------------------------
--  Constraints for Table ADDRESSINFO
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("USER_NAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("ADDRESS_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("ADDRESS_NAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("ADDRESS_SZK" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("ADDRESS" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("POST" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."ADDRESSINFO" MODIFY ("PHONE_NUM" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table A_MST_CATEGORY
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."A_MST_CATEGORY" MODIFY ("CATEGORY_CD" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."A_MST_CATEGORY" MODIFY ("CATEGORY_NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table BUYERLIST
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."BUYERLIST" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."BUYERLIST" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."BUYERLIST" MODIFY ("NAME" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CARTLIST
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("LISTNO" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("ITEMNAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("STORAGE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("PRICE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CARTLIST" MODIFY ("PIC" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CART_HISTORY
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("BUY_NO" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("ITEMNAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("COUNT" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("PRICE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("PIC" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("SZK" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY" MODIFY ("USER_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CART_HISTORY_ADD
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("BUY_NO" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("BUYDATE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("USER_NAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("ADDRESS_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("ADDRESS_NAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("ADDRESS_SZK" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("ADDRESS" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("POST" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("PHONE_NUM" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."CART_HISTORY_ADD" MODIFY ("TOTAL" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GOODS
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("ITEMNAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("STORAGE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("PRICE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("PIC" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" ADD CONSTRAINT "PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST"  ENABLE;
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("DETAIL" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("SZK" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."GOODS" MODIFY ("JUNGLE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table WORKTABLE
--------------------------------------------------------

  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("ITEMNAME" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("STORAGE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("PRICE" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("PIC" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" ADD CONSTRAINT "WORKTABLE_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "TEST"  ENABLE;
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "C##ADMIN"."WORKTABLE" MODIFY ("SZK" NOT NULL ENABLE);
