import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import TableContainer from '@material-ui/core/TableContainer';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 60,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Detail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            list:[],
            user_id:'100001'
        }; 
        this.getData(this.props.id)
    }
    getData(id){
             axios.get(`/detail/${id}`)
                .then((res)=>{
                    this.setState({
                        list:res.data
                    })
                })
                .catch((error)=>{
                    console.log(error)
                })
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    getRealStorage=(count,id)=>{
        axios.get(`/getStorage/${id}`)
        .then((res)=>{
            let stortage= (res.data.find(item=>item.id==id).storage)
            if((stortage-count)>=0){
                axios.post("/addCart",{
                        'id':id,
                        'count':count,
                        'user_id':this.state.user_id
                }).then(res=>{
                    
                })  
                .catch((error)=>{
                    console.log(error)
                })
                window.location.href=`/cartList/${this.state.user_id}`
            }else{
                console.log(count,res.data.find(item=>item.id==id).storage)
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doInsert=()=>{
        let id = this.props.match.params.id
        const result1 = /^\d+$/.test(this.state.count)
        const result2 = /^([1-9]\d*|0)$/.test(this.state.count)
        if(!(this.state.count.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            if(result1){
                if(this.state.count>0){
                    if(result2){
                        this.getRealStorage(this.state.count,id)
                    }else{
                        alert("頭数字を0以外で入力してください")
                    }
                }else{
                    alert("最小値は1です")
                }
            }else{
                alert("数字または整数を入力してください")
            }
        }else{
            alert("注文数はからです")
        } 
    }
    render(){
        const { classes } = this.props;
        return(
            <TableContainer component={Paper} style={{height:"780px"}}>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                <br/>
                                &nbsp;&nbsp;<Link to = '/'>ホーム</Link>
                                &nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;{value.itemName}
                                <br/><br/>
                                <img src={value.pic} style={{height:"250px",width:"300px",position:"absolute",left:"350px",top:"200px"}}/>
                                    <Table aria-label="caption table" style={{width:"400px" ,position:"absolute",left:"680px",top:"200px"}}>
                                    <TableCell>
                                    <Typography variant="h6" color="inherit" noWrap>
                                        {value.itemName}
                                    </Typography>
                                    </TableCell>
                                    <TableCell></TableCell>
                                    <TableRow>
                                        <TableCell>斡旋品#:</TableCell>
                                        <TableCell align="left">100001</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>価額：</TableCell>
                                        <TableCell align="left">￥{Number(value.price).toLocaleString('en-US')}</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>担当部署：</TableCell>
                                        <TableCell align="left">{value.szk}部署</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>在庫数：</TableCell>
                                        <TableCell align="left">{Number(value.storage).toLocaleString('en-US')}</TableCell>
                                    </TableRow>
                                    </Table>
                                    <div>
                                    <div style={{position:"absolute",left:"370px",top:"500px",fontSize:"20px"}}>
                                        特別価格
                                    </div>
                                    <div style={{position:"absolute",left:"370px",top:"520px",fontSize:"15px"}}>
                                        まちづくり情報センター（20冊未満）￥2500
                                        <br/>
                                        まちづくり情報センター（20冊以上）￥500
                                    </div>
                                    <div style={{position:"absolute",left:"370px",top:"600px",fontSize:"20px"}}>
                                        詳細
                                    </div>
                                    <div style={{position:"absolute",left:"370px",top:"620px",fontSize:"15px"}}>
                                        {value.detail}
                                    </div>
                                    </div>
                                </div>
                        })
                    }
                    <div style = {{position:"absolute",left:"1250px",top:"250px"}}>
                    <form style = {{borderRadius:"10%",border:"1px solid rgba(0,0,0,0.2)",width:"250px",height:"250px"}}>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{position:"absolute",left:"60px",top:"100px",fontSize:"20px"}}>
                                注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" value = {this.state.count} onChange = {this.handleCount}/>
                            </div>
                            <Button color="primary" variant="outlined" style={{position:"absolute",left:"60px",top:"150px"}} className={classes.button} onClick = {this.doInsert}>
                                カートに入れる
                            </Button>
                    </form>
                    </div>
                </div>
            </TableContainer>
        )
    }
}
export default withStyles(styles)(withRouter(Detail));