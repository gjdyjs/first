import React, { Component } from 'react';
import {AppBar,Button,CssBaseline,TextField,Select,MenuItem,FormControl,InputLabel,FormControlLabel,Checkbox} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import axios from 'axios';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 600,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 800,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
  });
class SubMainHeader extends Component{
    constructor(arg){
        super(arg)
        this.state = {
            txt:'',
            jungleCd:'',
            jungleName:'',
            flag:0,
            list:[]
        }
        this.getData()
    }
    handleInput = (e) =>{
      this.setState({
          txt:e.target.value
      })
    }
    handleSearch=(e)=>{
        let id = this.state.txt
        if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
          var data = {id:id,jungleCd:this.state.jungleCd,jungleName:this.state.jungleName,flag:this.state.flag}
          data = JSON.stringify(data)
          this.props.history.push(`/list/${data}`);
        }
    }
    handleJungle=(e)=>{
      this.setState({
        jungleCd:e.target.value,
        jungleName:this.state.list.find(item=>item.category_cd==e.target.value).category_name
    })
    }
    handleCheckbox=(e)=>{
      this.setState({
        flag:this.state.flag==0?1:0
      })
      
    }
    getData(){
      axios.get("/Sub")
         .then((res)=>{
             this.setState({
                list:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar position="fixed" color="default" elevation={0} className={classes.appBar}>
              <div style={{backgroundColor:"white",position:"fixed",top:"65px",width:"100%"}}>
                <FormControl variant="outlined" size = "small" className={classes.formControl}>
                        <InputLabel>ジャンル（部署）</InputLabel>
                        <Select style={{textAlign:"left"}} onChange={this.handleJungle}>
                            {
                              this.state.list.map(function(value,key){
                                  return <MenuItem value={value.category_cd} key = {key}>{value.category_name}</MenuItem>
                                  })
                            }
                        </Select>
                  </FormControl>
                <TextField id="outlined-basic" label="商品名" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                    検索
                </Button>
                <FormControlLabel className={classes.checkbox} control={<Checkbox color="primary"/>} checked={this.state.flag==0?true:false} onChange={this.handleCheckbox} label="予約斡旋品を含む"/>
              </div> 
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(withRouter(SubMainHeader));

