import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button} from '@material-ui/core';
import { withRouter } from 'react-router';
import TableContainer from '@material-ui/core/TableContainer';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import qs from 'qs';
import {Link} from "react-router-dom";
import axios from 'axios';
const styles = theme => ({
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
});
class GoodsList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            total:'',
            fee:'500',
            list:[]
        };
        this.getData(this.props.data.id)
    }
    getData(id){
        axios.get(`/workTable/${id}`)
           .then((res)=>{
               this.setState({
                   list:res.data
               })
               this.allPrice()
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.price)*Number(item.count)
        }
        this.setState({
            total:allPrice
        })
    }
    doJump=()=>{
        this.props.history.push(`/address/${this.props.data.id}`);
    }
    //注文する前、在庫数確認、問題なければ注文成功
    getRealStorage=(list,data)=>{
        let newList = list.map(item=>{return {id:item.id}})
        var dataParams = JSON.stringify(newList)
        console.log(dataParams)
        axios.get(`/getCartStorage/${dataParams}`)
        .then((res)=>{
            // if(((res.data.find(item=>item.id==id).storage)-count)>=0){
            //             axios.post("/cartHistory",{
            //                 list:this.state.list,
            //                 addressInfo:data
            //             }).then(res=>{
                            
            //             })  
            //             .catch((error)=>{
            //                 console.log(error)
            //             })
            //             this.props.history.push(`/print/${data}`);
            // }else{
            //     console.log(count,res.data.find(item=>item.id==id).storage)
            //     alert("在庫エラー")
            // }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doSubmit=(e)=>{
        e.preventDefault();
        var data = {
            szk:this.props.data.szk,
            szk_name:this.props.data.szk_name,
            user_id:this.props.data.user_id,
            user_name:this.props.data.user_name,
            address_id:this.props.data.address_id,
            address_name:this.props.data.address_name,
            address_szk:this.props.data.address_szk,
            post:this.props.data.post,
            address:this.props.data.address,
            phone_num:this.props.data.phone_num,
            id:this.props.data.id,
            total:this.state.total
        }
        data = JSON.stringify(data) 
        this.getRealStorage(this.state.list,data)
    }
    render(){
        const {classes} = this.props;
        return(
            <TableContainer component={Paper}>
            <div className = "cartList" style = {{textAlign:"left",width:"900px"}}>
                <br/>
                &nbsp;&nbsp;<Link to = '/'>ホーム</Link>
                &nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;<Link to={`/address/${this.props.data.id}`}>発送先入力</Link>
                &nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;注文確認
                <Table aria-label="caption table">
                    <TableRow>
                        <TableCell></TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </Table>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                    <Table aria-label="caption table">
                                    <TableRow>
                                        <TableCell align="left">                                        
                                        <img width={280} src={value.pic} style = {{float:"left",height:"180px"}}/>
                                        <div style = {{textAlign:"left"}}>  
                                            <h1>{value.itemName}</h1>
                                            斡旋品#: <br/>
                                            担当部署：{value.szk}<br/>
                                            在庫数：{value.storage-value.count}<br/>
                                            価額：￥{Number(value.price).toLocaleString('en-US')}<br/>
                                            <div>注文数:{value.count}</div> 
                                        </div></TableCell>
                                    </TableRow>
                                    </Table>
                                </div>
                        })
                    }
                </div>
                <div style = {{position:"absolute",left:"1300px",top:"100px"}}>
                    
                    <form style = {{borderRadius:"10%",width:"250px",height:"350px",border:"1px solid rgba(0,0,0,0.2)"}}>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                            <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                            <h3>送料:{this.state.fee} 円</h3>
                            <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                            <h3>合計:{Number(parseInt(this.state.total)+parseInt(this.state.fee)).toLocaleString('en-US')} 円</h3>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doSubmit}>
                                注文
                            </Button>
                            <br/><br/>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doJump}>
                                発送先入力に戻る
                            </Button>
                            </div>
                    </form>
                    
                </div>
            </div>
            </TableContainer>  
        )
    }
}
export default withStyles(styles)(withRouter(GoodsList));