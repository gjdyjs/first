import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
const styles = theme => ({
      root: {
        display: 'flex',
      },
});
class AddressInfo extends Component{
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <TableContainer component={Paper}>
                <div style={{width:"100%"}}>
                <Table aria-label="caption table">
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            入力者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>担当部署</TableCell>
                    <TableCell align="left">{this.props.data.szk}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>担当者</TableCell>
                        <TableCell align="left">{this.props.data.szk_name}</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            注文者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>注文者＃</TableCell>
                        <TableCell align="left">{this.props.data.user_id}:{this.props.data.user_name}</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            発送先
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow>
                        <TableCell>発送先＃</TableCell>
                        <TableCell align="left">{this.props.data.address_id}:{this.props.data.address_name}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>発送先部署</TableCell>
                        <TableCell align="left">{this.props.data.address_szk}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>郵便番号</TableCell>
                        <TableCell align="left">{this.props.data.post}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>住所</TableCell>
                        <TableCell align="left">{this.props.data.address}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell>電話番号</TableCell>
                        <TableCell align="left">{this.props.data.phone_num}</TableCell>
                    </TableRow>
                </Table>
                </div>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(AddressInfo);