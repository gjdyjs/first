import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import axios from 'axios';
const styles = theme => ({
      root: {
        display: 'flex',
      },
});
class AddressInfo extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            add:[]
        };
        this.getAddData(this.props.id)
    }
    getAddData(id){
        axios.get(`/cartHistoryAdd/${id}`)
           .then((res)=>{
               this.setState({
                    add:res.data
               })
               console.log(this.state.add)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                {
                    this.state.add.map((value,key)=>{
                        return  <div style={{width:"75%"}} key={key}>
                                <Table aria-label="caption table">
                                        <TableCell>
                                        <Typography variant="h6" color="inherit" noWrap>
                                            入力者
                                        </Typography>
                                        </TableCell>
                                        <TableCell></TableCell>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%"}}>担当部署</TableCell>
                                    <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.szk}</TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>担当者</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.szk_name}</TableCell>
                                    </TableRow>
                                </Table>
                                <br/>
                                <Table aria-label="caption table" >
                                        <TableCell>
                                        <Typography variant="h6" color="inherit" noWrap>
                                            注文者
                                        </Typography>
                                        </TableCell>
                                        <TableCell></TableCell>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%"}}>注文者＃</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.user_id}:{value.user_name}</TableCell>
                                    </TableRow>
                                </Table>
                                <br/>
                                <Table aria-label="caption table" >
                                        <TableCell>
                                        <Typography variant="h6" color="inherit" noWrap>
                                            発送先
                                        </Typography>
                                        </TableCell>
                                        <TableCell></TableCell>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>発送先＃</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.address_id}:{value.address_name}</TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%"}}>発送先部署</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.address_szk}</TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>郵便番号</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.post}</TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>住所</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.address}</TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>電話番号</TableCell>
                                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{value.phone_num}</TableCell>
                                    </TableRow>
                                </Table>
                                </div>
                    })
                }               

            </div>
        )
    }
}
export default withStyles(styles)(AddressInfo);