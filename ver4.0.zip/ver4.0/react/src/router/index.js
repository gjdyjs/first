import React,{Component} from "react";
import {Switch,Route} from "react-router-dom";
import Index from "../view/index";
import Home from "../view/list/index";
import DetailIndex from "../view/detail/index";
import CartIndex from "../view/cartList/index";
import AddressIndex from "../view/address/index";
import CartConfirmIndex from "../view/confirm/index";
import PrintIndex from "../view/print/index";
import CartHistory from "../view/cartHistory/index";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                <Route exact path = '/' component = {Index}/>
                <Route path = '/list/:data' component = {Home}/>
                <Route path = '/detail/:id' component = {DetailIndex}/>
                <Route path = '/cartList/:id' component = {CartIndex}/>
                <Route path = '/address/:id' component = {AddressIndex}/>
                <Route path = '/cartConfirm/:data' component = {CartConfirmIndex}/>
                <Route path = '/print/:id' component = {PrintIndex}/>
                <Route path = '/cartHistory/:id' component = {CartHistory}/>
            </Switch>

        );
    }
}
export default RouterIndex;