import React,{Component} from "react";
import {Switch,Route,Redirect} from "react-router-dom";
import Home from "../view/index/home";
import Detail from "../view/detail/detail";
import Cart from "../view/cart/cart";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                <Route path = "/" exact render = {()=>(
                    <Redirect to = "/index"/>
                )}/>
                <Route path = '/index/:id' component = {Home}/>
                <Route path = '/detail/:id' component = {Detail}/>
                <Route path = '/cart/:id' component = {Cart}/>
            </Switch>

        );
    }
}
export default RouterIndex;