import React, { Component } from 'react';
import { Layout } from 'antd';
import Sub from "./sub";
import IndexList from "./list";
const {  Content } = Layout;
export default class Home extends Component{
    constructor(props){
        super(props)
        this.state = {
            info:"あいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システム"
        }
    }
    render(){
        let id = this.props.match.params.id;
        return(
            <div>
                <Content style={{ padding: '0 50px' }}>
                    <Layout className="site-layout-background" style={{ padding: '24px 0' }}> 
                        <Sub/>
                        <Content style={{ padding: '0 24px', minHeight: 840 }}>
                        <IndexList id = {id}/>
                        </Content>
                    </Layout>
                </Content>
                
            </div>
        )
    }
}