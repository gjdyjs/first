import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
export default class Detail extends Component{
    constructor(props){
        super(props)
        this.state = {
            list:[],
            count:''      
        }
        
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    doSubmit=(e)=>{
        e.preventDefault();
        let id = this.props.match.params.id;
        this.props.history.push("/cart/"+id);
    }

    componentWillMount(){  
        let id = this.props.match.params.id;
        axios.get(`https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/list?id=${id}`)
            .then((res)=>{                             
                this.setState({
                    list:res.data
                })
            })
            .catch(function(error){
                console.error();
            })
    }

    render(){
        return(
               <div>
                    <div style = {{marginLeft:"30px",marginTop:"20px"}}>  
                        <Link to = "/">ホーム</Link>
                        <span style = {{marginLeft:"50px",marginRight:"50px"}}>商品名</span>
                        {
                            this.state.list.map((value,key)=>{                                     
                                        return  <div key = {key} style = {{marginTop:"120px",marginLeft:"80px"}}>
                                                    <div style = {{float:"left",height:"700px"}}>                                                                                                                         
                                                        <img src = {value.pic} style={{height:"300px"}}/>
                                                        <h2>詳細:</h2><h3>{value.detail}</h3>
                                                    </div>
                                                    <div style = {{position:"absolute",left:"800px"}}>
                                                        <h1>{value.itemName}</h1>
                                                        <u><h3>{value.szk}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{value.price}円</h3></u>
                                                        <u><h3>在庫が{value.storage}冊があります。</h3></u>
                                                    </div>
                                                </div>    
                            })
                        }
                    </div>
                    <div style = {{float:"right",position:"absolute",left:"1200px",top:"300px"}}>
                        <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"250px"}}>
                            <br/>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{textAlign:"center"}}> 
                            <br/>
                            <h3>注文数: <input type = "text" value = {this.state.count} onChange = {this.handleCount} style = {{width:"100px"}}/></h3>
                            <br/>
                            <br/>
                            <input type = "submit" value = "カートに入れる" onClick = {this.doSubmit} /><br/><br/>
                            </div>
                        </form>
                    </div>
                </div>
        )
    }
}
