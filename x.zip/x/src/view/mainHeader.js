import React, { Component } from 'react';
import { Layout, Menu, Row,Col } from 'antd';
// import {Link} from 'react-router-dom';
import {connect} from "react-redux";
import { withRouter } from 'react-router';
import axios from 'axios';
import '../css/mainHeader.css';
const { Header } = Layout;
class MainHeader extends Component{
    constructor(arg){
        super(arg)
        this.state = {
            txt:''
        }
        this.getData();
    }
    handleInput = (e) =>{
        this.setState({
            txt:e.target.value
        })
    }
    handleSearch=(e)=>{
        let id = this.state.txt
        this.props.history.push("/index/"+id);
    }
    getData(){
        this.props.dispatch((dispatch)=>{
            dispatch({
                type:"HEADER_UPDATA"
            });
            axios.get("https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/jungle")
                .then((res)=>{
                    dispatch({
                        type:"HEADER_UPDATA_SUCC",
                        data: res.data
                    });
                })
                .catch((error)=>{
                    dispatch({
                        type:"HEADER_UPDATA_REEOR",
                        data: error
                    });
                })
        });
    }
    render(){
        let {data} = this.props;
        return(
            <Layout>
                <Header className="header">
                    <Row>
                        <Col style = {{color:"white",fontSize:"30px"}} md = {18}>
                        斡旋品発注システム
                        </Col>
                        <Col style = {{textAlign:"right"}} md = {6}>

                            <Menu theme="dark" mode="horizontal">
                                <Menu.Item key="1">カート</Menu.Item>
                                <Menu.Item key="2">注文履歴</Menu.Item>
                                <Menu.Item key="3">マニュアル</Menu.Item>
                                <Menu.Item key="4">ログアウト</Menu.Item>
                            </Menu>
                        </Col>
                    </Row>
                </Header>
                <Row style={{ margin: '10px 0',position:"relative"}}>
                        <Col md = {8}>
                            <select style = {{width:"80%",height:"25px",marginLeft:"10px"}}>
                                {
                                    data.map((value,key)=>{
                                           return <option key = {key}>{value.jungle}</option>
                                    })
                                }
                            </select>                           
                        </Col>
                        <Col md = {12} >
                            <input type = "text"  value = {this.state.txt} style = {{width:"80%"}} placeholder = "商品" onChange = {this.handleInput}/>
                            <input type = "button" value = "検索" onClick = {this.handleSearch}/>
                        </Col>
                        <Col md = {4}>
                            <input type = "checkbox" />予約斡旋品のみ
                        </Col>
                </Row>
            </Layout>
        )
    }

}
export default connect(state=>(state.mainHeader))(withRouter(MainHeader));
