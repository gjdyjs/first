import React, { Component } from 'react';
import MainHeader from './view/mainHeader';
import RouterIndex from "./router/index";
export default class App extends Component{
    render(){
      return (
        <div>
          <MainHeader/>
          <RouterIndex/>
        </div>
      )
    }
}

