function cart(state = {data:[]},action){
    switch(action.type){
        case "LIST_UPDATA":
            return{
                data:state.data
            }
        case "LIST_UPDATA_SUCC":
            return{
                data:action.data
            }
        case "LIST_UPDATA_REEOR":
            return{
                data:[]
            }
        default:
            return state;
    }
}
export default cart;