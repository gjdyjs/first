function mainHeader(state = {data:[]},action){
    switch(action.type){
        case "HEADER_UPDATA":
            return{
                data:state.data
            }
        case "HEADER_UPDATA_SUCC":
            return{
                data:action.data
            }
        case "HEADER_UPDATA_REEOR":
            return{
                data:[]
            }
        default:
            return state;
    }
}
export default mainHeader;