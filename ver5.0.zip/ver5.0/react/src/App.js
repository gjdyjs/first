import React, { Component } from 'react';
import RouterIndex from './router/index';
import MainHeader from './view/mainHeader';

export default class App extends Component{
    render(){
      return (
        <div>
          <MainHeader/>
          <RouterIndex/>
        </div>
      )
    }
}
