import React, { Component } from 'react';
import {Button,TextField} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import {Link} from "react-router-dom";
import axios from 'axios';
import DialogThumonsha from './dialogThumonsha';
import DialogHassosaki from './dialogHassosaki';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        minWidth: 100,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Address extends Component{
    constructor(props){
        super(props);
        this.state = {
            total:'',
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            version:'',
            addInfo:[],
            userList:[],
            arr:[]
        };
    }
    componentDidMount(){
        this.getData()
    }
    getData(){
            axios.get(`/assen/AssenhinCartList/`+Date.parse(new Date()),{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    list:res.data
                })
                this.allPrice()
            })
            .catch((error)=>{
                console.log(error)
            })
           axios.get("/assen/selectDefaultAddress",{
            headers:{"token":sessionStorage.getItem("token")}
            })
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    version:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    getInfo1(thumonshaCd,thumonshaName){
        this.setState({
            thumonshaCd:thumonshaCd,
            thumonshaName:thumonshaName
        })
    }
    getInfo2(hassosakiCd,hassosakiName,address,hassosakiBusho,yubinNum,telNum){
        this.setState({
            hassosakiCd:hassosakiCd,
            hassosakiName:hassosakiName,
            hassosakiBusho:hassosakiBusho,
            address:address,
            yubinNum:yubinNum,
            telNum:telNum
        })
    }
    handleClear=(e)=>{
        this.setState({
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
          })
    }
    doConfirm=(e)=>{
        e.preventDefault();
        if(!(this.state.tantoBushoName==''||this.state.tantoshaName==''||this.state.thumonshaName==''||
        this.state.yubinNum==''||this.state.address==''||this.state.telNum==''||
        this.state.hassosakiName==''||this.state.hassosakiBusho=='')){
            axios.post("/assen/updateHassosakiAll/",
                {
                    nyuryokushaCd:this.state.nyuryokushaCd.toString(),
                    nyuryokushaName:this.state.nyuryokushaName.toString(),
                    tantoBushoName:this.state.tantoBushoName.toString(),
                    tantoshaName:this.state.tantoshaName.toString(),
                    thumonshaCd:this.state.thumonshaCd.toString(),
                    thumonshaName:this.state.thumonshaName.toString(),
                    hassosakiCd:this.state.hassosakiCd.toString(),
                    hassosakiName:this.state.hassosakiName.toString(),
                    hassosakiBusho:this.state.hassosakiBusho.toString(),
                    yubinNum:this.state.yubinNum.toString(),
                    address:this.state.address.toString(),
                    telNum:this.state.telNum.toString(),
                    torihikisakiCd:this.props.id.toString(),
                    version:this.state.version.toString()
                },
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                if(res.data-this.state.version>0){
                    this.props.history.push(`/assen/cartConfirm/${this.props.id}`)
                }else{
                    alert("発送先情報更新が失敗しました") 
                }
            })
            .catch((error)=>{
                console.log(error)
            })
        }else(
            alert("必須項目を入力してください")
        )
    }
    doJump=()=>{
        this.props.history.push(`/assen/cartList/${this.props.id}`);
    }
    handleInput=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
        if(e.target.name=="thumonshaCd"){
            if(e.target.value.length>=4){
                this.autoSetUser(e.target.value)
            }
        }
        if(e.target.name=="hassosakiCd"){
            if(e.target.value.length>=4){
                this.autoSetAddress(e.target.value)
            }
        }
    }
    autoSetUser=(thumonshaCd)=>{
            axios.get(`/assen/searchThumonshaList/${thumonshaCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setUserOnly(thumonshaCd)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    autoSetAddress=(hassosakiCd)=>{
            axios.get(`/assen/selectHassosaki/${hassosakiCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    addInfo:res.data
                })
                this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    setUserOnly=(thumonshaCd)=>{
        this.state.arr=this.state.userList.find(item=>item.thumonshaCd==thumonshaCd)
        this.setState({
            thumonshaName:this.state.arr.thumonshaName,
            userList:[],
            arr:[]
        })
    }
    setAdressOnly=(addInfo)=>{
        this.setState({
            hassosakiName:addInfo[0].hassosakiName,
            hassosakiCd:addInfo[0].hassosakiCd,
            address:addInfo[0].address,
            hassosakiBusho:addInfo[0].hassosakiBusho,
            yubinNum:addInfo[0].yubinNum,
            telNum:addInfo[0].telNum,
            addInfo:[],
            arr:[]
        })
    }
    handleCopy=(e)=>{
        if(!(this.state.thumonshaCd.toString().replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            axios.get(`/assen/selectHassosaki/${this.state.thumonshaCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
              this.setState({
                addInfo:res.data
              })
              this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
        }
    }
    render(){
        const { classes } = this.props;
        return(
                <div>
                    <div>
                    <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;発送先入力
                    </div>
                    <div style = {{width:"70%",height:"150px"}}>
                        <h1>入力者</h1>
                        <div name="nyuryokushaCd">
                            {this.state.nyuryokushaCd}
                        </div>
                        <div name="nyuryokushaName">
                            {this.state.nyuryokushaName}
                        </div>
                        <div>
                            担当部署&nbsp;<span name="tantoBushoName" style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　
                            <TextField id="outlined-basic" variant="outlined" name="tantoBushoName" value={this.state.tantoBushoName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>担当者&nbsp;<span name="tantoshaName" style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" name="tantoshaName" value={this.state.tantoshaName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>注文者&nbsp;&nbsp;&nbsp;
                            <DialogThumonsha getInfo1={(thumonshaCd,thumonshaName)=>this.getInfo1(thumonshaCd,thumonshaName)}/> 
                        </h1>
                        <div>
                            注文者#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <TextField id="outlined-basic" variant="outlined" name="thumonshaCd" value={this.state.thumonshaCd} className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" variant="outlined" name="thumonshaName" value={this.state.thumonshaName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>
                            <div>
                            発送先&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <DialogHassosaki getInfo2={(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)=>this.getInfo2(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)}/>
                            <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-40px"}} className={classes.button} onClick = {this.handleCopy} >
                            注文者コピー
                            </Button>&nbsp;
                            <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-40px"}} className={classes.button} onClick = {this.handleClear}>
                            クリア
                            </Button>
                        </h1>

                        <div>
                            発送先#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="hassosakiCd" value={this.state.hassosakiCd} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" name="hassosakiName" value={this.state.hassosakiName} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>
                            発送先部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="hassosakiBusho" value={this.state.hassosakiBusho} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            郵便番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="yubinNum" value={this.state.yubinNum} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            住所&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="address" value={this.state.address} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>             
                        </div>
                        <br/>                                          
                        <div>
                            電話番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" name="telNum" value={this.state.telNum} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                                       
                    </div>                                
                    <div style = {{float:"right",position:"absolute",left:"70%",top:"200px"}}>
                    <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"350px"}}>
                        <br/>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                        <br/>
                        <h3 style={{color:"red"}}>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                        <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button} onClick = {this.doConfirm}>
                            注文内容確認
                        </Button>
                        <br/><br/>
                        <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button} onClick = {this.doJump}>
                            カートに戻る
                        </Button>
                        </div>
                    </form>
                    </div>
                </div>
        )
    }
}
export default withStyles(styles)(withRouter(Address));