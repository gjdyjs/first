import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button} from '@material-ui/core';
import { withRouter } from 'react-router';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import axios from 'axios';
const styles = theme => ({
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
});
class GoodsList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            souryou:'',
            list:[],
            total:'',
            juhattyubi:''
        };
        this.getListData(this.props.id)
    }
    getListData(id){
        axios.get(`/assen/getThumonzumiAssenhinList/${id}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
           })
           .catch((error)=>{
               console.log(error)
           })
        axios.get("/assen/getSouryou/",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                souryou:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    doJump=()=>{
        this.props.history.push("/assen/top");
    }
    doPrint=()=>{
        var newStr = document.getElementById("print").innerHTML;
        var win = window.open("","newWindow","height=800,width=700,top=100");
        win.document.body.innerHTML = newStr;
        win.print();
    }
    render(){
        const {classes} = this.props;
        return(
            <div className = "cartList" style = {{textAlign:"left",width:"900px"}}>
                <div style={{color:"red"}}>※注文が完了しました。</div>
                <Table aria-label="caption table" style={{width:"400px"}}>
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap style={{color:"red"}}>
                            注文情報
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>発注＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.props.id}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>発注日</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.juhattyubi}</TableCell>
                    </TableRow>
                </Table>
                <Table aria-label="caption table">
                    <TableRow>
                        <TableCell></TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </Table>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                    <Table aria-label="caption table">
                                    <TableRow>
                                        <TableCell align="left">                                        
                                        <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                        width={280} style = {{float:"left",height:"180px"}}/>
                                        <div style = {{textAlign:"left"}}>  
                                        <h3>{value.assenhinName}</h3>
                                            <div>斡旋品＃:{value.assenhinCd}</div>
                                            担当部署：{value.bushoName}<br/>
                                            {
                                                value.kaiinTekiyou?
                                                <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} <span style={{color:"red"}}>※会員価額適用</span></div>:
                                                <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} </div>
                                            }
                                            <div>注文数:{value.thumonSuu}</div> 
                                        </div></TableCell>
                                    </TableRow>
                                    </Table>
                                </div>
                        })
                    }
                </div>
                
                <div style = {{position:"absolute",left:"70%",top:"150px"}}>
                    <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"350px"}}>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{textAlign:"center"}}> 
                                <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                                    <h3>送料:{this.state.souryou} 円</h3>
                                    <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                                    <h3 style={{color:"red"}}>合計:{Number(parseInt(this.state.total)+parseInt(this.state.souryou)).toLocaleString('en-US')} 円</h3>
                                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doPrint}>
                                        印刷
                                    </Button>
                                    <br/><br/>
                                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doJump}>
                                        ホームに戻る
                                    </Button>
                            </div>
                    </form>
                </div>
            </div>
        )
    }
}
export default withStyles(styles)(withRouter(GoodsList));