import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import AddressInfo from './addressInfo';
import GoodsList from './goodsList';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import {Link} from "react-router-dom";
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class PrintIndex extends Component{
    render(){
        let id = window.atob(this.props.match.params.id);
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <TableContainer component={Paper}>
                <Container maxWidth="lg" >
                    <Toolbar/>
                    <br/>
                    &nbsp;&nbsp;<Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>
                    &nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;注文履歴修正完了
                    <br/><br/>
                    <div id = "print">
                    <GoodsList id = {id}/>
                    <br/>
                    <AddressInfo id = {id}/>
                    <br/>
                    </div>
                </Container>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(PrintIndex);