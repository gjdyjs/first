import React, { Component } from 'react';
import {AppBar,Button,CssBaseline,TextField,Select,MenuItem,FormControl,InputLabel,FormControlLabel,Checkbox} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import qs from 'qs';
import axios from 'axios';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 500,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 700,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
  });
class SubMainHeader extends Component{
    constructor(arg){
        super(arg)
        this.state = {
            txt:'',
            categoryCd:'',
            categoryName:'',
            searchYoyaku:0,
            list:[]
        }
        this.getData()
    }
    handleInput = (e) =>{
      this.setState({
          txt:e.target.value
      })
    }
    handleSearch=(e)=>{
        const orderType = 10
        let id = this.state.txt
        if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
          var data = {searchAssenhinName:id,searchCategoryId:this.state.categoryCd.toString(),searchYoyaku:this.state.searchYoyaku,orderType:orderType}
          data = qs.stringify(data)
          this.props.history.push(`/assen/list/${data}`);
        }
    }
    handleCategory=(e)=>{
      this.setState({
        categoryName:e.target.value,
        categoryCd:this.state.list.find(item=>item.categoryName==e.target.value).categoryCd
      })
    }
    handleCheckbox=(e)=>{
      this.setState({
        searchYoyaku:this.state.searchYoyaku==0?1:0
      })
      
    }
    getData(){
      axios.get("/assen/Category",{
        headers:{"token":sessionStorage.getItem("token")}
        })
         .then((res)=>{
             this.setState({
                list:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar  color="default" elevation={0} className={classes.appBar}>
              <div style={{backgroundColor:"white",position:"absolute",top:"65px",width:"100%"}}>
                <FormControl variant="outlined" size = "small" className={classes.formControl} 
                style={{width:"20%"}}>
                        <InputLabel>ジャンル（部署）</InputLabel>
                        <Select style={{textAlign:"left"}} onChange={this.handleCategory} value = {this.state.categoryName}>
                            {
                              this.state.list.map(function(value,key){
                                  return <MenuItem value={value.categoryName} key={key}>{value.categoryName}</MenuItem>
                                  })
                            }
                        </Select>
                  </FormControl>
                <TextField id="outlined-basic" label="商品名" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput} 
                style={{position:"absolute",width:"50%"}}/>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}
                style={{position:"relative",left:"50%"}}
                >
                    検索
                </Button>
                <FormControlLabel style={{position:"relative",width:"10%",left:"50%"}} className={classes.checkbox} control={<Checkbox color="primary"/>} checked={this.state.searchYoyaku==0?true:false} onChange={this.handleCheckbox} label="予約斡旋品を含む"/>
              </div> 
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(withRouter(SubMainHeader));

