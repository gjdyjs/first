import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import SubMainHeader from '../subMainHeader';
import Detail from './detail';
const styles = theme => ({
    root: {
        display: 'flex',
      },
});
class DetailIndex extends Component{
    render(){
        let text = this.props.match.params.data;
        let data = {
            assenhinCd:text.substring(text.indexOf("=")+1,text.indexOf("&")),
            hansuu:text.substring(text.indexOf("=",text.indexOf("=")+1)+1,text.length)
        }
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <SubMainHeader/>
                <Detail data = {data}/>
            </div>
        )
    }
}
export default withStyles(styles)(DetailIndex);