import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import axios from 'axios';
const styles = theme => ({
      root: {
        display: 'flex',
      },
});
class AddressInfo extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            list:[],
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            version:''
        };
        this.getData(this.props.id)
    }
    getData(id){
        axios.get("/assen/selectDefaultAddress",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                 tantoBushoName:res.data.tantoBushoName,
                 tantoshaName:res.data.tantoshaName,
                 thumonshaCd:res.data.thumonshaCd,
                 thumonshaName:res.data.thumonshaName,
                 hassosakiCd:res.data.hassosakiCd,
                 hassosakiName:res.data.hassosakiName,
                 hassosakiBusho:res.data.hassosakiBusho,
                 yubinNum:res.data.yubinNum,
                 address:res.data.address,
                 telNum:res.data.telNum,
                 version:res.data.version
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>               
                <div style={{width:"75%"}}>
                <Table aria-label="caption table">
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            入力者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>担当部署</TableCell>
                    <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoBushoName}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>担当者</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoshaName}</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            注文者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>注文者＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.thumonshaCd}:{this.state.thumonshaName}</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <Table aria-label="caption table" >
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            発送先
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>発送先＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.hassosakiCd}:{this.state.hassosakiName}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>発送先部署</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.hassosakiBusho}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>郵便番号</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.yubinNum}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>住所</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.address}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>電話番号</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.telNum}</TableCell>
                    </TableRow>
                </Table>
                </div>
            </div>
        )
    }
}
export default withStyles(styles)(AddressInfo);