import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import FormControl from '@material-ui/core/FormControl';
import {Button} from '@material-ui/core';
import {TextField} from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Pagination from "material-ui-flat-pagination";
import qs from 'qs';
import { withRouter } from 'react-router';
const styles = theme => ({
    root: {
        flexGrow: 1,
        display: 'flex',
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 130,
      },
});
class CartHistoryList extends Component{
    constructor(arg){
        super(arg);   
        this.state = {
            list:[],
            syukkomachi:'出庫待ち',
            syukkozumi:'出庫済み',
            offset: 0,
            perPage: 5,
            selectKey:'',
            nendo:'',
            years:[],
            currentTime:''
        };
        this.getData(this.props.id) 
    }
    getDataWithRules(nendo,selectKey){
        var data = {nendo:nendo.toString(),juhattyuCd:selectKey}
        data = JSON.stringify(data)
        axios.get(`/assen/historyListByNendo/${data}`,
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                list:res.data,
                offset:0
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    getData(id){
        axios.get(`/assen/historyListByTorihisakiCd/${id}`+Date.parse(new Date()),
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                list:res.data,
            })
        })
        .catch((error)=>{
            console.log(error)
        })
        axios.get("/assen/getNendoList",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                years:res.data,
                nendo:res.data[0]
            })
        })
        .catch((error)=>{
            console.log(error)
        })
        axios.get("/assen/getServerTime",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                currentTime:res.data,
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    handleInput=(e)=>{
        this.setState({
            selectKey:e.target.value
        })
    }
    handleSelect=()=>{
        this.getDataWithRules(this.state.nendo,this.state.selectKey)
    }
    handleClickPagination = offset => {
        this.setState({ offset })
    }
    handleSort=(e)=>{
        this.setState({
            nendo:e.target.value
        })
        this.getDataWithRules(e.target.value,this.state.selectKey)
    }
    doJumpDeatil=(juhattyuCd,nendo)=>{
        var data = {juhattyuCd:juhattyuCd,nendo:nendo,torihisakiCd:this.props.id}
        data = qs.stringify(data)
        var encode = window.btoa(data)
        this.props.history.push(`/assen/detailHistory/${encode}`)
    }
    doJumpUpdate=(juhattyuCd,nendo)=>{
        var data = {juhattyuCd:juhattyuCd,nendo:nendo,torihisakiCd:this.props.id,times:'0'+Date.parse(new Date())}
        data = qs.stringify(data)
        var encode = window.btoa(data)
        this.props.history.push(`/assen/updateHistory/${encode}`);
    }
    compaire(juhattyubiStr,currentTime){
        let time = juhattyubiStr.replace("/","")
        let cartTime = time.replace("/","")
        let compaireResult = true
        if(currentTime-cartTime>0){
            return compaireResult
        }else{
            compaireResult = false
        }
        return compaireResult
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                    <div style={{width:"100%"}}>
                        <div style={{width:"80%",position:"relative",left:"150px"}}>
                        <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;注文履歴一覧
                        <br/><br/>
                            <div style={{fontSize:"15px"}}>
                            発注#：
                            <TextField id="outlined-basic" value={this.state.selectKey} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            <Button color="primary" variant="outlined"  style={{position:"relative",left:"10px",backgroundColor:"orange",color:"black",top:"2px"}} className={classes.button} onClick = {this.handleSelect}>
                                発注＃検索
                            </Button>
                            </div>
                            <br/>
                            <div style={{fontSize:"15px"}}>
                            年度：&nbsp;&nbsp;
                                <FormControl variant="outlined" size = "small" className={classes.formControl}>
                                    <Select style={{textAlign:"left"}} onChange={this.handleSort} value={this.state.nendo}>
                                        {
                                            this.state.years.map(function(value,key){
                                                return (
                                                    <MenuItem value={value} key={key}>{value}年度</MenuItem>
                                                )
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </div>
                        </div>
                        <br/>
                        <List dense compoent="span" style={{width:"80%",position:"relative",left:"150px"}}>
                            {this.state.list
                            .slice(this.state.offset,this.state.offset+this.state.perPage)
                            .map((value,key) => {
                                return (
                                    <div key={key}>
                                    <Table aria-label="caption table" >
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.1)"}}>
                                        <TableCell>発注＃:{value.juhattyuCd}</TableCell>
                                        <TableCell>発注日：{value.juhattyubiStr}</TableCell>
                                        <TableCell></TableCell>
                                        <TableCell></TableCell>
                                        <TableCell>
                                        {
                                        this.compaire(value.juhattyubiStr,this.state.currentTime)?
                                        <Button variant="outlined" onClick={()=>this.doJumpDeatil(value.juhattyuCd,value.nendo)}     
                                        style={{backgroundColor:"infobackground"}}>詳細確認</Button>:
                                        <Button variant="outlined" onClick={()=>this.doJumpUpdate(value.juhattyuCd,value.nendo)} 
                                        style={{backgroundColor:"orange"}}>注文変更</Button>
                                        }
                                        </TableCell>
                                    </TableRow>
                                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>
                                        <TableCell style={{textAlign:"center"}}>商品名</TableCell>
                                        <TableCell style={{textAlign:"center"}}>斡旋品＃</TableCell>
                                        <TableCell style={{textAlign:"center"}}>注文数</TableCell>
                                        <TableCell style={{textAlign:"center"}}>価額</TableCell>
                                        <TableCell style={{textAlign:"center"}}>出庫</TableCell>
                                    </TableRow>
                                    {
                                        value.historyList.map((v,k)=>{
                                            return (
                                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}} key={k}>
                                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",textAlign:"center",color:"red"}}>{v.assenhinName}</TableCell>
                                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",textAlign:"center"}}>{v.assenhinCd}</TableCell>
                                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",textAlign:"right"}}>{v.thumonSuu}</TableCell>
                                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",textAlign:"right"}}>￥{v.kingaku}</TableCell>
                                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",textAlign:"center"}}>{v.syukkoFlag==0?this.state.syukkomachi:this.state.syukkozumi}</TableCell>
                                            </TableRow>
                                            ) 
                                        })
                                    }
                                    </Table>
                                    <br/>
                                    </div>
                                );
                            })}
                            <Pagination
                            currentPageColor='default'
                            style={{position:"relative",left:"350px"}}
                            size='large'
                            limit={this.state.perPage}
                            offset={this.state.offset}
                            total={this.state.list.length}
                            onClick={(e, offset) => this.handleClickPagination(offset)}
                            />
                        </List>
                        <br/>
                    </div>

            </div>
        )
    }
}
export default withStyles(styles)(withRouter(CartHistoryList));