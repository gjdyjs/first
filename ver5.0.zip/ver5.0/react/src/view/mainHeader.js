import React, { Component } from 'react';
import {AppBar,CssBaseline,Toolbar,Typography,Badge,Button,Popover} from '@material-ui/core';
import {Link} from "react-router-dom";
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import FileSave from 'file-saver'; 
import axios from 'axios';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    toolbar: {
        flexWrap: 'wrap',
      },
    toolbarTitle: {
        flexGrow: 1,
      },
    link: {
        margin: theme.spacing(1, 1.5),
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 600,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 800,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
    typography: {
        padding: theme.spacing(1),
      },
  });
class MainHeader extends Component{
    constructor(props){
      super(props)
      this.state={
        open:false,
        anchorEl: null,
        count:''
      }
      this.getAuthentication()
    }
    getAuthentication(){
      axios.get("/assen/Authentication")
      .then((res)=>{
          sessionStorage.setItem("userId",res.data.userId)
          sessionStorage.setItem("torihikisakiName",res.data.torihikisakiName)
          sessionStorage.setItem("torihikisakiCd",res.data.torihikisakiCd)
          sessionStorage.setItem("token",res.data.csrfKey)
          this.getData(sessionStorage.getItem("torihikisakiCd"))
      })
      .catch((error)=>{
          console.log(error)
      })
    }
    getData(id){
      axios.get(`/assen/Count/${id}`+Date.parse(new Date()),{
        headers:{"token":sessionStorage.getItem("token")}
        })
         .then((res)=>{
             this.setState({
                count:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    handleClick=(e)=>{
      this.setState({
        open:true,
        anchorEl:e.currentTarget 
      })
    }
    handleClose=()=>{
      this.setState({
        open:false,
        anchorEl:null
      })
    }
    handleDownload=()=>{
      let filename = "test.pdf"
      let URLToPDF = "/assen/manual"
      this.downloadPDF(URLToPDF,filename)
    }
    downloadPDF(URLToPDF,PDFName) {
      var oReq = new XMLHttpRequest();
      oReq.open("GET", URLToPDF, true);
      oReq.setRequestHeader("token",sessionStorage.getItem("token"));
      oReq.responseType = "blob";
      oReq.onload = function() {
        var file = new Blob([oReq.response], { 
            type: 'application/pdf'
        });
        FileSave.saveAs(file, PDFName);
      };
      oReq.send();
    }

    handleLogout=()=>{
      axios.get("/assen/logout")
      .then((res)=>{
          sessionStorage.removeItem("userId")
          sessionStorage.removeItem("torihikisakiCd")
          sessionStorage.removeItem("torihikisakiName")
          sessionStorage.removeItem("token")
          window.location.href="/assen/login"
      })
      .catch((error)=>{
          console.log(error)
      })
    }
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar position="fixed" color="default" elevation={0} className={classes.appBar} >
              <Toolbar className={classes.toolbar} style={{borderBottom:"solid 1px"}}>
                <Typography variant="h6" color="inherit" noWrap className={classes.toolbarTitle} style={{color:"green"}}>
                  斡旋品発注システム
                </Typography>
                <nav>
                  <Link variant="button" to="/assen/top" style={{ textDecoration:'none',color:'blue'}} className={classes.link}>
                    ホーム
                  </Link>
                  <Link variant="button" to={`/assen/cartList/${sessionStorage.getItem("userId")}`} className={classes.link}>
                    <Badge badgeContent={this.state.count} color="secondary">
                    <i className="material-icons">shopping_cart</i>
                    </Badge>
                  </Link>
                  <Link variant="button" to={`/assen/history/${sessionStorage.getItem("userId")}`} style={{ textDecoration:'none',color:'blue'}} className={classes.link}>
                    注文履歴
                  </Link>
                  <Button onClick={this.handleDownload} style={{ textDecoration:'none',color:'blue'}} className={classes.link}>
                    マニュアル
                  </Button>
                </nav>
                  <Button onClick={this.handleClick} className={classes.link}>
                  <i className="material-icons">person</i>
                  </Button>
                  <Popover open={this.state.open} anchorEl={this.state.anchorEl} onClose={this.handleClose} anchorOrigin={{vertical:'top',horizontal:'right'}}>
                      <Typography className={classes.typography}>ユーザーID：{sessionStorage.getItem("torihikisakiCd")}</Typography>
                      <Typography className={classes.typography}>ユーザー名：{sessionStorage.getItem("torihikisakiName")}</Typography>
                      <Button variant="button" color="primary" variant="outlined" style={{left:"90px"}} onClick={this.handleLogout}>
                        ログアウト
                      </Button>
                  </Popover>         
              </Toolbar>
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(withRouter(MainHeader));

