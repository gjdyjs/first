import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import axios from 'axios';
import Category from './category';
import SubMainHeader from './subMainHeader';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class Index extends Component{
    constructor(props){
      super(props)
      this.state={
        list:[],
        systemMessage:'',
        janetMessage:''
      }
      this.getData()
    }
    getData(){
        axios.get("/assen/systemMessage",{
          headers:{"token":sessionStorage.getItem("token")}
          })
          .then((res)=>{
              this.setState({
                  systemMessage:res.data
              })
          })
          .catch((error)=>{
              console.log(error)
          })
         axios.get("/assen/janetMessage",{
          headers:{"token":sessionStorage.getItem("token")}
          })
         .then((res)=>{
             this.setState({
                  janetMessage:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
            <CssBaseline />
            <SubMainHeader/>
            <Category/>
            <Container maxWidth="lg" style={{backgroundColor:"white",height:'930px'}}>
              <Toolbar />
              <Toolbar />
              <br/><br/><br/><br/>
              <form style={{border:"solid 1px"}}>
                <h2 style={{textAlign:"center"}}>JANET推進チームからのお知らせ</h2>
                <hr/>
                <div dangerouslySetInnerHTML={{__html: this.state.systemMessage}}/>
              </form>
              <br/><br/><br/><br/>
              <form style={{border:"solid 1px"}}>
                <h2 style={{textAlign:"center"}}>システムからのお知らせ</h2>
                <hr/>
                <div dangerouslySetInnerHTML={{__html: this.state.janetMessage}}/>
              </form>
            </Container>
          </div>
        )
    }
}
export default withStyles(styles)(Index);