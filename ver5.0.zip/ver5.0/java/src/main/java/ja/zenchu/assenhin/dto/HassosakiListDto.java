package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 発送先のリスト
 * @author take
 *
 */
@Getter
@Setter
public class HassosakiListDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6300038219102931018L;
	/** 発送先CD */
	private int hassosakiCd;
	/** 発送先名 */
	private String hassosakiName;

}
