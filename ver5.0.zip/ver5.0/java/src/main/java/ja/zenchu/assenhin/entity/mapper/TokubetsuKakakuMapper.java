package ja.zenchu.assenhin.entity.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TokubetsuKakakuMapper {
	
	/**
	 * 注文前カート状態の斡旋品会員摘要の判定
	 * @param assenhinCd
	 * @param hansuu
	 * @param torihikisakiCd
	 * @param thumonshaCd
	 * @param thumonSuu
	 * @return
	 */
	String getTokubetsuKakaku(Integer assenhinCd, Short hansuu, Integer torihikisakiCd, Integer thumonshaCd, Short thumonSuu);
	
	/**
	 * 注文後当日注文時の斡旋品会員摘要の判定（当日注文テーブルから判定）
	 * @param torihikisakiCd
	 * @param nendo
	 * @param juhattyuCd
	 * @param juhatttyuMeisaiCd
	 * @param thumonshaCd
	 * @param thumonSuu
	 * @return
	 */
	String getTokubetsuKakakuByJuhattyuCd(Integer torihikisakiCd,  Short nendo, Integer juhattyuCd, Short juhattyuMeisaiCd, Integer thumonshaCd, Short thumonSuu);

}
