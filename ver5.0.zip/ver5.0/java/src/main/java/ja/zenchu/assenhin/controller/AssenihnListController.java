package ja.zenchu.assenhin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.AssenhinListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.AssenihnListService;

/**
 * 斡旋品検索結果一覧画面
 *
 */
@RestController
public class AssenihnListController {
	@Autowired
	AssenihnListService assenhinListService;
	/**
	 * 一覧画面商品情報を取得
	 *
	 */
    @RequestMapping(value = "/list/{data}",method= RequestMethod.GET)
    public List<AssenhinListDto> GetList(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	String searchAssenhinName=(String) map.get("searchAssenhinName");
    	short searchCategoryId= 0;
    	if(!map.get("searchCategoryId").toString().isEmpty()) {
    		searchCategoryId = Short.parseShort( (String) map.get("searchCategoryId"));
    	}
    	int orderType = Integer.valueOf((String) map.get("orderType")).intValue();
    	boolean searchYoyaku = true;
    	if(Integer.valueOf((String) map.get("searchYoyaku")).intValue() == 0) {
    		searchYoyaku = true;
    	}else {
    		searchYoyaku = false; 
    	}
    	return assenhinListService.selectAssenhinList(searchAssenhinName, searchCategoryId, searchYoyaku, orderType,loginUserDto);
    }
}
