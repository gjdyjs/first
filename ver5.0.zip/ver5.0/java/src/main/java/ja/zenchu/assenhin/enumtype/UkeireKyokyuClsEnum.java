package ja.zenchu.assenhin.enumtype;

/**
 * 受入供給区分（斡旋品では発注のみ)
 * @author take
 *
 */
public enum UkeireKyokyuClsEnum {

	/** 発注のみ */
	HATTYU(1);
	private int ukeireCls;
	
	private UkeireKyokyuClsEnum(int i) {
		this.ukeireCls = i;
	}
	
	public short getUkeireCls() {
		return (short) this.ukeireCls;
	}

}
