package ja.zenchu.assenhin.controller;


import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.tomcat.util.buf.UriUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriUtils;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.CategoryDto;
import ja.zenchu.assenhin.dto.DownloadDataDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.service.CartService;
import ja.zenchu.assenhin.service.CategoryService;
import ja.zenchu.assenhin.service.ManualService;
import ja.zenchu.assenhin.service.TopMessageService;

/**
 *ホーム画面
 *
 */
@RestController
public class TopPageController {
	@Autowired
	CategoryService categoryService;
	@Autowired
	CartService cartService;
	@Autowired
	TopMessageService topMessageService;
	@Autowired
	ManualService manualService;
	/**
	 *カテゴリーリストを取得
	 *
	 */
    @RequestMapping(value="/Category")
    public List<CategoryDto> GetCategory(){
    	String cateGoryList;
    	Gson gson = new Gson();
    	return categoryService.searchCategoryList();
    }
	/**
	 * システムメッセージを取得
	 *
	 */
//    @RequestMapping(value="/systemMessage")
//    public String GetSystemMessage(@RequestHeader("token") String token){
//    	System.out.println(token);
//    	String systemMessage = topMessageService.getSystemMessage();
//    	return systemMessage;
//    }
    @RequestMapping(value="/systemMessage")
    public String GetSystemMessage(){
    	String systemMessage = topMessageService.getSystemMessage();
    	return systemMessage;
    }
	/**
	 * JANETメッセージを取得
	 *
	 */
    @RequestMapping(value="/janetMessage")
    public String GetJanetMessage(){
    	String janetMessage = topMessageService.getJanetMessage();
    	return janetMessage;
    }
	/**
	 * カートのカウントを取得
	 *
	 */
    @RequestMapping(value = "/Count/{key}",method= RequestMethod.GET)
    public int GetWorkTableCount(@PathVariable("key") String id){
    	String key = id.substring(0,8);
    	int torihikisakiCd = Integer.valueOf((String) key).intValue();
    	return cartService.getCartCount(torihikisakiCd);
    }
    
    /**
     * マニュアルダウンロード
     * ファイルのバイナリを返す。ファイル名はhttpheaderにセットする。
     * @return
     */
    @GetMapping(value = "/manual")
    public ResponseEntity<byte[]> getDownloadManual() {
    	DownloadDataDto rtnDto = manualService.getManual();
    	final String fileName = UriUtils.encode(rtnDto.getManualName(), StandardCharsets.UTF_8.name());
    	final String headername = "attachment; filename*=utf-8''" + fileName;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.add(HttpHeaders.CONTENT_DISPOSITION, headername);
		return new ResponseEntity<>(rtnDto.getFileData(), headers, HttpStatus.OK);

    }
}
