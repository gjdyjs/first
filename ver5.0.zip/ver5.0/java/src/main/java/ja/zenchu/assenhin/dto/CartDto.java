package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.util.List;


import lombok.Getter;
import lombok.Setter;

/***
 * カートデータを返す
 * 一時テーブルで使用するUUIDも返す。
 * @author take
 *
 */
@Getter
@Setter
public class CartDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3468229675354383880L;

	/** 一時テーブルのキーとなるUUID */
	private String UUID;
	
	private List<CartListDto> cartList;

}
