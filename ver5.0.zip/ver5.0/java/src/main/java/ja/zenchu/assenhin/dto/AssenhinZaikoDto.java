package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 在庫数データ
 */
@Getter
@Setter
public class AssenhinZaikoDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5657506049534239940L;
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	/** 在庫数 */
	private int zaikoSuu;
}
