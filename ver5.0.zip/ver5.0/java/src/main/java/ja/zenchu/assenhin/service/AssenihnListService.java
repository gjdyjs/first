package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import ja.zenchu.assenhin.dto.AssenhinListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.SearchAssenhinDto;
import ja.zenchu.assenhin.entity.mapper.AAssenhinMapper;

/**
 * 斡旋品の検索リスト(斡旋品検索用）
 * @author take
 *
 */
@RestController
public class AssenihnListService {

	@Autowired
	protected AAssenhinMapper aAssenhinMapper;

	/**
	 * 斡旋品検索の想定メソッド
	 * @param searchAssenhinName　検索用斡旋品名
	 * @param searchCategoryId カテゴリID
	 * @param searchYoyaku 予約斡旋品を含むかどうか(含む場合True)
	 * @param orderType　並び順
	 * @param userDto ログイン時に取得するDto（価格区分ここから設定する）
	 * @return
	 */
	public List<AssenhinListDto> selectAssenhinList(String searchAssenhinName, Short searchCategoryId, boolean searchYoyaku, int orderType, LoginUserDto userDto) {
		//検索条件にセット
		SearchAssenhinDto searchDto = new SearchAssenhinDto();
		searchDto.setSearchCategoryId(searchCategoryId);
		searchDto.setSearchAssenhinName(searchAssenhinName);
		searchDto.setKijunbi(LocalDate.now());
		searchDto.setYoyakuFlag(searchYoyaku);
		searchDto.setKakakuSetteiCls(userDto.getKakakuSetteiCls());
		searchDto.setOrderType(orderType);
		//検索結果をリターン
		return aAssenhinMapper.searchAssenhinList(searchDto);
	}
}
