package ja.zenchu.assenhin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.entity.AZaiko;
import ja.zenchu.assenhin.entity.AZaikoKey;
import ja.zenchu.assenhin.entity.mapper.AZaikoMapper;

/**
 * 在庫数の取得・更新を行うサービス
 * @author take
 *
 */
@Service
public class ZaikoService {

	@Autowired
	AZaikoMapper aZaikoMapper;
	

	/**
	 * 斡旋品の在庫数を取得
	 * @param assenhinCd
	 * @param hansuu
	 * @return 在庫数
	 */
	public int getZaikoSuu(Integer assenhinCd, Short hansuu) {
		Integer zaikoSuu = aZaikoMapper.getZaikoSuu(assenhinCd, hansuu);
		return zaikoSuu != null ? zaikoSuu : 0;
	}
	
	/**
	 * 在庫数更新
	 * @param assenhinCd
	 * @param hansuu
	 * @param thumonSuu 注文数（注文数分在庫数からマイナス）
	 * @return
	 */
	public int updateZaikoSuu(Integer assenhinCd, Short hansuu, final int thumonSuu) { 
		AZaikoKey key = new AZaikoKey();
		key.setAssenhinCd(assenhinCd);
		key.setHansuu(hansuu);
		AZaiko zaiko = aZaikoMapper.selectByPrimaryKey(key);
		//発注後在庫数マイナス。
		zaiko.setHattyugoZaikosuu(zaiko.getHattyugoZaikosuu() - thumonSuu);;
		return aZaikoMapper.updateHattyugoZaikosuu(zaiko);
	}
	/**
	 * 在庫データ取得
	 * @param assenhinCd
	 * @param hansuu
	 * @return
	 */
	public AZaiko getZaikoData(Integer assenhinCd, Short hansuu) {
		AZaikoKey key = new AZaikoKey();
		key.setAssenhinCd(assenhinCd);
		key.setHansuu(hansuu);
		return aZaikoMapper.selectByPrimaryKey(key);
	}
	public int updateHattyugoZaikosuu(AZaiko zaiko) {
		return aZaikoMapper.updateHattyugoZaikosuu(zaiko);
	}
	
}
