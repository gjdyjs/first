package ja.zenchu.assenhin.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;

/**
 * 日付処理の共通クラス
 * @author take
 *
 */
public class DateUtility {

	private DateUtility() {
		
	}
	
	private static DateTimeFormatter YYYYMMDDSLASH = DateTimeFormatter.ofPattern("yyyy/MM/dd");
	
	private static DateTimeFormatter YYYYMMDDNONSLASH = DateTimeFormatter.ofPattern("yyyyMMdd");
	
	/**
	 * ｙｙｙｙ/MM/dd形式への日付文字列変換(LocalDate型)
	 * @param ld
	 * @return
	 */
	public static String getFormatDateSlash(LocalDate ld) {
		if (ld == null) {
			return StringUtils.EMPTY;
		}
		return ld.format(YYYYMMDDSLASH);
	}
	/**
	 * yyyyMMdd形式への日付文字列変換
	 * @param lTime
	 * @return
	 */
	public static String getFormatDateNonSlash(LocalDate lDate) {
		if (lDate == null) {
			return StringUtils.EMPTY;
		}
		return lDate.format(YYYYMMDDNONSLASH);
	}
	
	/**
	 * 現在日をyyyyMMdd形式の文字列で返すメソッド
	 * @return
	 */
	public static String getNowDateNoSlash() {
		return getFormatDateNonSlash(LocalDate.now());
	}
}
