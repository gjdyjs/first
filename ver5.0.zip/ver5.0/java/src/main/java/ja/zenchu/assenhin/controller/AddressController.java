package ja.zenchu.assenhin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.AddressInfoDto;
import ja.zenchu.assenhin.dto.HassosakiListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.ThumonshaListDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.AddressService;
import ja.zenchu.assenhin.service.JuhattyuService;

/**
 * 発送先入力画面
 *
 */
@RestController
public class AddressController {
	@Autowired
	AddressService addressService;
	@Autowired
	JuhattyuService juhattyuService;
	/**
	 * デフォルト発送先情報を取得
	 *
	 */
    @RequestMapping(value = "/selectDefaultAddress",method= RequestMethod.GET)
    public AddressInfoDto GetDefaultAddress(@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	AddressInfoDto addressInfoDto = addressService.selectDefaultAddress(loginUserDto);
    	return addressInfoDto;
    }
	/**
	 * 注文者検索
	 *
	 */
    @RequestMapping(value = "/searchThumonshaList/{key}",method= RequestMethod.GET)
    public List<ThumonshaListDto> GetThumonshaList(@PathVariable("key") String searchKey){
    	Gson gson = new Gson();
    	List<ThumonshaListDto> result = addressService.searchThumonshaList(searchKey);
    	return result;
    }
	/**
	 *発送先検索
	 *
	 */
    @RequestMapping(value = "/searchHassosakiList/{key}",method= RequestMethod.GET)
    public List<HassosakiListDto> GetHassosakiList(@PathVariable("key") String searchKey){
    	Gson gson = new Gson();
    	List<HassosakiListDto> result = addressService.searchHassosakiList(searchKey);
    	return result;
    }
	/**
	 * 発送先情報を取得
	 *
	 */
    @RequestMapping(value = "/selectHassosaki/{key}",method= RequestMethod.GET)
    public List<AddressInfoDto> GetHassosaki(@PathVariable("key") int torihikisakiCd){
    	Gson gson = new Gson();
    	AddressInfoDto addressInfoDto = addressService.selectHassosaki(torihikisakiCd);
    	List<AddressInfoDto> result = new ArrayList();
    	result.add(addressInfoDto);
    	return result;
    }
	/**
	 * 注文内容確認
	 *
	 */
    @RequestMapping(value = "/updateHassosakiAll",method= RequestMethod.POST)
    public int UpdateHassosakiAll(@RequestBody String params){
    	AddressInfoDto addressInfoDto = new AddressInfoDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int torihikisakiCd = Integer.valueOf((String) map.get("torihikisakiCd")).intValue();
    	addressInfoDto.setNyuryokushaCd(Integer.valueOf((String) map.get("nyuryokushaCd")).intValue());
    	addressInfoDto.setNyuryokushaName((String)map.get("nyuryokushaName"));
    	addressInfoDto.setTantoBushoName((String)map.get("tantoBushoName"));
    	addressInfoDto.setTantoshaName((String)map.get("tantoshaName"));
    	if(!map.get("thumonshaCd").toString().isEmpty()) {
    		addressInfoDto.setThumonshaCd((String) map.get("thumonshaCd"));
    	}else {
    		addressInfoDto.setThumonshaCd(null);
    	}
    	if(!map.get("hassosakiCd").toString().isEmpty()) {
    		addressInfoDto.setHassosakiCd((String) map.get("hassosakiCd"));
    	}else {
    		addressInfoDto.setHassosakiCd(null);
    	}
    	addressInfoDto.setThumonshaName((String)map.get("thumonshaName"));
    	addressInfoDto.setHassosakiName((String)map.get("hassosakiName"));
    	addressInfoDto.setHassosakiBusho((String)map.get("hassosakiBusho"));
    	addressInfoDto.setYubinNum((String)map.get("yubinNum"));
    	addressInfoDto.setAddress((String)map.get("address"));
    	addressInfoDto.setTelNum((String)map.get("telNum"));
    	addressInfoDto.setVersion(Integer.valueOf((String) map.get("version")).intValue());
    	int version = addressService.updateHassosakiAll(torihikisakiCd,addressInfoDto);
    	return version;
    }
	/**
	 * 注文
	 *
	 */
    @RequestMapping(value = "/insertJuhattyuData",method= RequestMethod.POST)
	public int InsertJuhattyuData(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	return juhattyuService.insertJuhattyuData(loginUserDto);
	}
	/**
	 * 送料検索
	 *
	 */
    @RequestMapping(value = "/getSouryou",method= RequestMethod.GET)
	public int GetSouryou(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	int souryou = loginUserDto.getSouryou();
    	return souryou;
	}
    
}