package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * カート件数チェック用？
 * @author take
 *
 */
@Getter
@Setter
public class CartCheckDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5742429397271232843L;

	/** 斡旋品# */
	private int assenhinCd;
	/** 版数 */
	private int hansuu;
	/** 注文数？ */
	private int thumonSuu;
}
