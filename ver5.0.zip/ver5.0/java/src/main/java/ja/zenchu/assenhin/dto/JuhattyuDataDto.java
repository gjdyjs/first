package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 履歴画面で受発注の送料とバージョンを返すDTO
 * @author take
 *
 */
@Setter
@Getter
public class JuhattyuDataDto implements Serializable{

	   /**
	 * 
	 */
	private static final long serialVersionUID = 8654876227944777127L;

	private Short nendo;

	   private Integer juhattyuCd;

	   private Integer souryou;
	   
	   private Integer version;
}
