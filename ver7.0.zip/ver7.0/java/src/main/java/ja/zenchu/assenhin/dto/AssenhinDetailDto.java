package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;

/**
 * 斡旋品詳細画面用
 * @author take
 *
 */
@Getter
public class AssenhinDetailDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6038643872260155391L;
	
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	/** 斡旋品名 */
	private String assenhinName;
	/** 在庫数 */
	private int zaikoSuu;
	/**  部署名 */
	private String bushoName;
	/** 価格 */
	private int kakaku;
	/** 概要（備考） */
	private String gaiyo;
	/** 予約斡旋品区分 */
	private short yoyakuCls;
	public void setAssenhinCd(int assenhinCd) {
		this.assenhinCd = assenhinCd;
	}
	public void setHansuu(short hansuu) {
		this.hansuu = hansuu;
	}
	public void setAssenhinName(String assenhinName) {
		this.assenhinName = assenhinName;
	}
	public void setZaikoSuu(int zaikoSuu) {
		this.zaikoSuu = zaikoSuu;
	}
	public void setBushoName(String bushoName) {
		this.bushoName = bushoName;
	}
	public void setKakaku(int kakaku) {
		this.kakaku = kakaku;
	}
	public void setGaiyo(String gaiyo) {
		this.gaiyo = StringUtils.defaultString(gaiyo);
	}
	public void setYoyakuCls(short yoyakuCls) {
		this.yoyakuCls = yoyakuCls;
	}
	
}
