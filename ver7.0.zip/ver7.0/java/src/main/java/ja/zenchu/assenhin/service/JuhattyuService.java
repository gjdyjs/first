package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.DeleteJuhattyuMeisaiListDto;
import ja.zenchu.assenhin.dto.JuhattyuDataDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.SearchAssenhinDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuSplitDto;
import ja.zenchu.assenhin.entity.AAssenhin;
import ja.zenchu.assenhin.entity.AAssenhinKey;
import ja.zenchu.assenhin.entity.AHassosakiWork;
import ja.zenchu.assenhin.entity.AJuhattyu;
import ja.zenchu.assenhin.entity.AJuhattyuMeisai;
import ja.zenchu.assenhin.entity.AZaiko;
import ja.zenchu.assenhin.entity.AZaikoKey;
import ja.zenchu.assenhin.entity.MSaibanKanri;
import ja.zenchu.assenhin.entity.mapper.AAssenhinMapper;
import ja.zenchu.assenhin.entity.mapper.ACartMapper;
import ja.zenchu.assenhin.entity.mapper.AHassosakiWorkMapper;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMapper;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMeisaiMapper;
import ja.zenchu.assenhin.entity.mapper.AZaikoMapper;
import ja.zenchu.assenhin.entity.mapper.MSaibanKanriMapper;
import ja.zenchu.assenhin.entity.mapper.TokubetsuKakakuMapper;
import ja.zenchu.assenhin.enumtype.AllTorihikisakiEnum;
import ja.zenchu.assenhin.enumtype.DeleteFlagEnum;
import ja.zenchu.assenhin.enumtype.KaikeiRendoEnum;
import ja.zenchu.assenhin.enumtype.KihyoClsEnum;
import ja.zenchu.assenhin.enumtype.SeikyushoOutFlagEnum;
import ja.zenchu.assenhin.enumtype.ShukkoFlagEnum;
import ja.zenchu.assenhin.enumtype.UkeireKyokyuClsEnum;
import ja.zenchu.assenhin.logic.JuhattyuLogic;

/**
 * 注文データを取り扱うサービス
 * 注文の登録・更新・削除
 * @author take
 *
 */
@Service
public class JuhattyuService {

	@Autowired
	MSaibanKanriMapper mSaibanKMapper;
	
	@Autowired
	ACartMapper aCartMapper;
	
	@Autowired
	AHassosakiWorkMapper aHassosakiWorkMapper;
	
	@Autowired
	AJuhattyuMeisaiMapper aJuhattyuMeisaiMapper;
	
	@Autowired
	AJuhattyuMapper aJuhattyuMapper;
	
	@Autowired
	ZaikoService zaikoService;
	
	@Autowired
	JuhattyuLogic juhattyuLogic;
	
	/**
	 * 発注新規登録
	 * 一時テーブルに登録されているデータを元に受発注を新規登録
	 * @param torihikisakiCd
	 * @return 新規の受発注番号を返す。登録に失敗した場合は0を返す。
	 */
	@Transactional
	public int insertJuhattyuData(LoginUserDto loginUserDto) {
		//基準日
		final LocalDate juhattyubi = LocalDate.now();
		//更新日時
		final LocalDateTime koushinNichiji = LocalDateTime.now();
		//採番番号
		final int newJuhattyuCd = getNewTsuban(loginUserDto, koushinNichiji);
		//カート情報取得
		List<CartListDto> cartList = aCartMapper.searchCartList(loginUserDto.getTorihikisakiCd(), loginUserDto.getKakakuSetteiCls(), juhattyubi);
		if (cartList.size() == 0) {
			//TODO エラー処理見直し
			throw new IllegalArgumentException("カート取得不正");
		}
		
		//発送先情報
		AHassosakiWork work = aHassosakiWorkMapper.selectByPrimaryKey(loginUserDto.getTorihikisakiCd());
		if (work == null) {
			//TODO エラー処理見直し
			throw new IllegalArgumentException("発送先取得不正");
		}
		//注文者・発送先Null対応
		if (work.getThumonshaCd() == null) {
			work.setThumonshaCd(AllTorihikisakiEnum.SONOTA.getTorihikisakiCd());
		}
		if (work.getHassosakiCd() == null) {
			work.setHassosakiCd(AllTorihikisakiEnum.SONOTA.getTorihikisakiCd());
		}
		//受発注明細
		short juhattyuMeisaiCd = 0;
		for (CartListDto cartDto : cartList) {
			//受発注明細
			juhattyuMeisaiCd++;
			AJuhattyuMeisai aMeisai = juhattyuLogic.createNewJuhattyuMeisaiData(newJuhattyuCd, juhattyuMeisaiCd, juhattyubi, cartDto, work, loginUserDto);
			aJuhattyuMeisaiMapper.insert(aMeisai);
			//在庫数
			AZaiko zaiko = zaikoService.getZaikoData(cartDto.getAssenhinCd(), cartDto.getHansuu());
			//発注後在庫数修正
			zaiko.setHattyugoZaikosuu(zaiko.getHattyugoZaikosuu() - cartDto.getThumonSuu());
			zaikoService.updateHattyugoZaikosuu(zaiko);
		}
		//受発注管理情報
		AJuhattyu juhattyu = createJuhattyuData(newJuhattyuCd, juhattyubi, work, loginUserDto);
		int ins =  aJuhattyuMapper.insert(juhattyu);
		if (ins == 1) {
			//不要データ削除
			aCartMapper.deleteByTorihikisakiCd(loginUserDto.getTorihikisakiCd());
			aHassosakiWorkMapper.deleteByPrimaryKey(loginUserDto.getTorihikisakiCd());
			return newJuhattyuCd;
		}
		return 0;
	}
	
	/**
	 * 当日注文時の発注削除
	 * @param juhattyuCd 受発注番号
	 * @param version バージョン
	 * @param loginUserDto
	 */
	public void deleteAllJuhattyuData(final int juhattyuCd, int version, LoginUserDto loginUserDto) {
		//受発注削除
		int juhattyudel = aJuhattyuMapper.deleteJuhattyuData(loginUserDto.getTargetNendo(), juhattyuCd, version);
		if (juhattyudel == 0) {
			//エラー処理
			throw new IllegalArgumentException("受発注削除エラー");
		}
		List<DeleteJuhattyuMeisaiListDto> delList = aJuhattyuMeisaiMapper.selectDeleteJuhattyuMeisaiList(loginUserDto.getTargetNendo(), juhattyuCd);
		for (DeleteJuhattyuMeisaiListDto dDto : delList) {
			
			//在庫更新
			AZaiko zaiko = zaikoService.getZaikoData(dDto.getAssenhinCd(), dDto.getHansuu());
			//発注後在庫数修正
			zaiko.setHattyugoZaikosuu(zaiko.getHattyugoZaikosuu() + dDto.getHattyuSuuryo());
			zaikoService.updateHattyugoZaikosuu(zaiko);
			//受発注明細削除
			aJuhattyuMeisaiMapper.deleteJuhattyuMeisaiData(loginUserDto.getTargetNendo(), juhattyuCd, dDto.getJuhattyuMeisaiCd());
		}
	}
	/**
	 * 受発注バージョンと送料
	 * @param nendo
	 * @param juhattyuCd
	 * @return
	 */
	public JuhattyuDataDto getJuhattyuVersion(final Short nendo, final int juhattyuCd) {
		return aJuhattyuMapper.getJuhattyuData(nendo, juhattyuCd);
	}
	
	/**
	 * 新規登録用受発注データ作成
	 * @param juhattyuCd
	 * @param juhattyubi
	 * @param work
	 * @param loginUserDto
	 * @return
	 */
	private AJuhattyu createJuhattyuData(
			final int juhattyuCd, LocalDate juhattyubi,
			 AHassosakiWork work, LoginUserDto loginUserDto) {
		AJuhattyu juhattyu = new AJuhattyu();
		juhattyu.setNendo(loginUserDto.getTargetNendo());
		juhattyu.setJuhattyuCd(juhattyuCd);
		juhattyu.setHattyumotoCd(loginUserDto.getTorihikisakiCd());
		juhattyu.setTantoBusho(work.getTantoBusho());
		juhattyu.setTantosha(work.getTantosha());
		juhattyu.setUkeireKyokyuCls(UkeireKyokyuClsEnum.HATTYU.getUkeireCls());
		juhattyu.setJuhattyubi(juhattyubi);;
		juhattyu.setNyuryokushaCd(work.getNyuryokushaCd());
		juhattyu.setKihyoCls(KihyoClsEnum.HATTYU.getKihyoCls());
		juhattyu.setSyukkoFlag(ShukkoFlagEnum.MISHUKKO.getShukkoFlag());
		juhattyu.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
		juhattyu.setVersion(1);;
		juhattyu.setSouryou(loginUserDto.getSouryou());
		return juhattyu;
		
	}


	


	/**
	 * 新規登録時に新規採番番号を取得する。
	 * @param loginUserDto
	 * @return
	 */
	private int getNewTsuban(LoginUserDto loginUserDto, LocalDateTime koushinNichiji) {
		MSaibanKanri mSaiban = mSaibanKMapper.getSaibanKanri(loginUserDto.getTargetNendo());
		final int newJuhattyuCd = mSaiban.getNowNum() + 1;
		mSaiban.setNowNum(newJuhattyuCd);;
		mSaiban.setKoushinNichiji(koushinNichiji);
		mSaiban.setKoushinshaCd(loginUserDto.getTorihikisakiCd());
		mSaibanKMapper.updateSaibanKanri(mSaiban);
		return newJuhattyuCd;
	}

}
