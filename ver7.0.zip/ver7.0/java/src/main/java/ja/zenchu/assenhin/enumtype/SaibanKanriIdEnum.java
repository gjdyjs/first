package ja.zenchu.assenhin.enumtype;
/**
 * 採番管理ID（ひとまず受発注のみ）
 * @author take
 *
 */
public enum SaibanKanriIdEnum {

	JUHATTYU(3);
	
	private int saibanId;
	
	private SaibanKanriIdEnum(int i) {
		this.saibanId = i;
	}
	
	public short getSaibanId() {
		return (short) saibanId;
	}
}
