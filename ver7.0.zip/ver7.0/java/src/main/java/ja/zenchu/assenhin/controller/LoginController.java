package ja.zenchu.assenhin.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
public class LoginController {
	@RequestMapping(value="/login")
	public String login(Model model, @ModelAttribute("modelMap") ModelMap modelMap) {
		if (!modelMap.isEmpty()) {
			model.addAttribute("errorMsg", "入力された ログイン ID または パスワード が正しくありません。");
		}

		return "login";
	}

	@RequestMapping(value="/login-error")
	public String loginError(RedirectAttributes redirectAttributes) {
		ModelMap modelMap = new ModelMap();
		modelMap.addAttribute("isLoginError", true);
		redirectAttributes.addFlashAttribute("modelMap", modelMap);

		return "redirect:/login";
	}
	
    @RequestMapping(value="/top")
    public String TopPage(){
    	return "/index";
    }
    
    @RequestMapping(value="/logout")
    public String logout(){
    	return "login";
    }
}
