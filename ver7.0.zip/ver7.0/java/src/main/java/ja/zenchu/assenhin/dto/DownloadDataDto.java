package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * マニュアルファイルダウンロード用
 * @author take
 *
 */
@Data
public class DownloadDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8970516700138911071L;

	/** マニュアル名 */
	private String manualName;
	/** マニュアルファイル(byte配列） */
	private byte[] fileData;
}
