package ja.zenchu.assenhin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.CartService;


/**
 * カート画面
 *
 */
@RestController
public class CartController {
	@Autowired
	CartService cartService;
	/**
	 * カート一覧を取得
	 *
	 */
    @RequestMapping(value = "/AssenhinCartList/{key}",method= RequestMethod.GET)
    public List<CartListDto> GetCartList(@PathVariable("key") String timeStamp,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	return cartService.getCartList(loginUserDto);
    }
	/**
	 * 注文確認画面
	 * カート一覧最終取得
	 *
	 */
    @RequestMapping(value = "/FinalAssenhinCartList",method= RequestMethod.GET)
    public List<CartListDto> GetFinalCartList(@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	boolean isSaishuCheck = true;
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	return cartService.getCartList(loginUserDto,isSaishuCheck);
    }
	/**
	 * 注文した商品を削除
	 *
	 */
    @RequestMapping(value = "/delete",method= RequestMethod.POST)
    public int DeleteCart(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	int assenhinCd = Integer.valueOf((String) map.get("assenhinCd")).intValue();
    	short hansuu=Short.parseShort( (String) map.get("hansuu"));
    	int version = Integer.valueOf((String) map.get("version")).intValue();
    	return cartService.deleteCart(assenhinCd,hansuu,version,loginUserDto);
    }
	/**
	 * 注文商品の注文数を更新
	 *
	 */
    @RequestMapping(value = "/updateThumonsuu",method= RequestMethod.POST)
    public int UpdateThumonsuu(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	int assenhinCd = Integer.valueOf((String) map.get("assenhinCd")).intValue();
    	short hansuu=Short.parseShort( (String) map.get("hansuu"));
    	short  thumonSuu = Short.parseShort( (String) map.get("thumonSuu"));
    	int version = Integer.valueOf((String) map.get("version")).intValue();
    	return cartService.updateThumonsuu(assenhinCd,hansuu,thumonSuu,version,loginUserDto);
    }
}
