package ja.zenchu.assenhin.enumtype;

/**
 * 削除フラグ管理用（1が無効）
 * @author take
 *
 */
public enum DeleteFlagEnum {

	/** 削除フラグ：有効 */
	YUUKOU(0),
	/** 削除フラグ：無効 */
	MUKOU(1);
	
	private int delFlg;
	
	private DeleteFlagEnum(int i) {
		this.delFlg = i;
	}
	
	public short getDeleteFlag() {
		return (short) this.delFlg;
	}
}
