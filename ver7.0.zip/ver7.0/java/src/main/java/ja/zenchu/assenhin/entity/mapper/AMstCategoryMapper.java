package ja.zenchu.assenhin.entity.mapper;

import java.time.LocalDate;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ja.zenchu.assenhin.dto.CategoryDto;

/**
 * カテゴリ
 * @author take
 *
 */
@Mapper
public interface AMstCategoryMapper {

    /**
     * 未定を除くカテゴリのリスト
     * @param kijunbi　表示の基準日（基本的に現在日を想定）
     * @return
     */
    List<CategoryDto> searchCategoryList(LocalDate kijunbi);
}