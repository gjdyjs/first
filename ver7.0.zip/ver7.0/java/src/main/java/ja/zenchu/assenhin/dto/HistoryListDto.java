package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.time.LocalDate;

import ja.zenchu.assenhin.enumtype.ShukkoFlagEnum;
import ja.zenchu.assenhin.utils.DateUtility;
import lombok.Getter;
import lombok.Setter;

/**
 * 注文履歴一覧用Dto
 * @author take
 *
 */
@Getter
@Setter
public class HistoryListDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4169275164452698809L;
	
	/** 注文年度 */
	private short nendo;

	/** 注文ID（受発注#) */
	private int juhattyuCd;
	/** 受発注日 */
	private LocalDate juhattyubi;
	/** 注文明細番号(受発注明細#) */
	private int juhattyuMeisaiCd;
	/** 斡旋品# */
	private int assenhinCd;
	/** 版数 */
	private short hansuu;
	/** 斡旋品名 */
	private String assenhinName;
	/** 注文数 */
	private int thumonSuu;
	/** 取引先# */
	private int torihikisakiCd;
	/** 金額 */
	private int kingaku;
	/** 在庫数（必要？） */
	private int zaikoSuu;
	/** 出庫フラグ */
	private short syukkoFlag;
	/***
	 * 出庫済みかどうか
	 * ※出庫済みの場合〇をつける
	 * @return
	 */
	public boolean isShukkoZumi() {
		return ShukkoFlagEnum.isShukkoZumi(syukkoFlag);
	}
}
