package ja.zenchu.assenhin.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 受発注明細の削除リスト作成用
 * @author take
 *
 */
@Getter
@Setter
public class DeleteJuhattyuMeisaiListDto {

   private Short nendo;

   private Integer juhattyuCd;

   private Short juhattyuMeisaiCd;
   
   private Integer assenhinCd;
   
   private Short hansuu;
   
   private Integer hattyuSuuryo;
}
