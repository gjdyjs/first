package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;

/**
 * 特別価格取得Functionからの取得結果を分解して格納するためのDto
 * Functionは文字列で返すことにしたので「_」で分解してそれを数値化
 * @author take
 *
 */
@Getter
public class TokubetsuKakakuSplitDto implements Serializable {
	
	/**
	 * コンストラクタ
	 * ※来ないと思うがキーがNullや空欄の物はとりあえず事前チェックでエラーにしたい。
	 * @param key キー
	 */
	public TokubetsuKakakuSplitDto(String key) {
		if (StringUtils.isEmpty(key))  {
			isKakakuFound = false;
			isKaiinKakaku = false;
			return;
		}
		String[] str = StringUtils.split(key, "_");;
		if (str.length == 3) {
			isKakakuFound = true;
			//キーを分解
			tanka = Integer.parseInt(str[0]);
			kakakuCls = Short.parseShort(str[1]);
			kaiinCls = Short.parseShort(str[2]);
			//価格区分4以上は特別価格対応である。
			isKaiinKakaku = kakakuCls >= 4 ? true : false;
		} else {
			isKakakuFound = false;
			isKaiinKakaku = false;
		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1543339766539441445L;

	private Integer tanka;
	
	private Short kakakuCls;
	
	private Short kaiinCls;
	
	/** 特別価格対象か */
	private boolean isKaiinKakaku;

	/** 価格を取得できたか */
	private boolean isKakakuFound;
}
