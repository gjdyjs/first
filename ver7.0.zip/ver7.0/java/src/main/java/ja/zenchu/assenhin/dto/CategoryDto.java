package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * カテゴリ情報
 * @author take
 *
 */
@Getter
@Setter
public class CategoryDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8347632733636681045L;

	/**  カテゴリCD */
	private short categoryCd;
	/** カテゴリ名 */
	private String categoryName;
	

}
