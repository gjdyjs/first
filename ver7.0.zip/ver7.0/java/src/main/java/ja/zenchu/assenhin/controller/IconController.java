package ja.zenchu.assenhin.controller;


import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.IconDataDto;
import ja.zenchu.assenhin.entity.mapper.AAssenhinIconMapper;

/**
 * 斡旋品アイコン画像用
 * @author take
 *
 */
@Controller
public class IconController {

	@Autowired
	AAssenhinIconMapper iconMapper;
	
	@Autowired
	ResourceLoader resourceLoader;
	
	/**
	 * アイコンのバイト配列を返す
	 * 300px*300pxの正方形のアイコンが返る想定。
	 * @param params
	 * @return
	 * @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value="/getIcon")
	public HttpEntity<byte[]> getIconImage(@RequestParam int assenhinCd,@RequestParam short hansuu) throws IOException {
		IconDataDto rtnDto =  iconMapper.getAssenhinIconData(assenhinCd, hansuu);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_PNG); //TODO png固定で書いているが、拡張子で分けるかも
		//アイコン画像があった場合その画像を返す。
		if (rtnDto != null) {
			byte[] b = rtnDto.getFileData();
			headers.setContentLength(b.length);
			return new HttpEntity<byte[]>(b, headers);
		}
		//なかった場合static下のNoimage.pngを返す。
		Resource resource = resourceLoader.getResource("classpath:" + "/static/img/Noimage.png");
		InputStream img = resource.getInputStream();
		byte[] b = IOUtils.toByteArray(img);
		headers.setContentLength(b.length);
		return new HttpEntity<>(b, headers);
	}
	
//	/**
//	 * アイコンの画像ファイルbase64Encode文字列を返す
//	 * 300px*300pxの正方形のアイコンが返る想定。
//	 * @param params
//	 * @return
//	 * @throws IOException
//	 */
//	
//	@RequestMapping(value="/getIcon64")
//	public HttpEntity<String> getIconImageBase64(@RequestParam int assenhinCd,@RequestParam short hansuu) throws IOException {
//		IconDataDto rtnDto =  iconMapper.getAssenhinIconData(assenhinCd, hansuu);
//		HttpHeaders headers = new HttpHeaders();
//		headers.setContentType(MediaType.IMAGE_PNG); //TODO png固定で書いているが、拡張子で分けるかも
//		//アイコン画像があった場合その画像を返す。
//		if (rtnDto != null) {
//			byte[] b = rtnDto.getFileData();
//			final String b64 = Base64.getEncoder().encodeToString(b);
//			return new HttpEntity<String>(b64, headers);
//		}
//		//なかった場合static下のNoimage.pngを返す。
//		Resource resource = resourceLoader.getResource("classpath:" + "/static/img/Noimage.png");
//		InputStream img = resource.getInputStream();
//		byte[] b = IOUtils.toByteArray(img);
//		final String b64 = Base64.getEncoder().encodeToString(b);
//		System.out.println(new HttpEntity<>(b64, headers));
//		return new HttpEntity<>(b64, headers);
//	}
	
}
