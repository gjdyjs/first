package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.entity.mapper.AJanetMessageMapper;
import ja.zenchu.assenhin.entity.mapper.AKenchuMessageMapper;

/**
 * メッセージ表示用
 * @author take
 *
 */
@Service
public class TopMessageService {

	@Autowired
	AKenchuMessageMapper aKenchuMessageMapper;
	
	@Autowired
	AJanetMessageMapper aJanetMessageMapper;
	
	
	/**
	 * システムメッセージ
	 * @return
	 */
	public String getSystemMessage() {
		List<String> msgList = aKenchuMessageMapper.getMessageList(LocalDate.now());
		StringBuilder build = new StringBuilder();
		for (String str : msgList) {
			build.append(str);
		}
		return build.toString();
	}
	

	/**
	 * Janetメッセージ
	 * @return
	 */
	public String getJanetMessage() {
		List<String> msgList = aJanetMessageMapper.getMessageList(LocalDate.now());
		StringBuilder build = new StringBuilder();
		for (String str : msgList) {
			build.append(str);
		}
		return build.toString();
	}
}
