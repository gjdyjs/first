package ja.zenchu.assenhin.enumtype;

/**
 * 斡旋品起票区分用
 * @author take
 *
 */
public enum KihyoClsEnum {

	/** 発注 */
	HATTYU("H");
	private String kihyoCls;
	
	private KihyoClsEnum(String s) {
		this.kihyoCls = s;
	}
	
	public String getKihyoCls() {
		return this.kihyoCls;
	}
}
