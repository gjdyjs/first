self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dacdb9ae77ba3260777ade5fb54e8ee4",
    "url": "/assen/index.html"
  },
  {
    "revision": "61f7740cb3987903b18e",
    "url": "/assen/static/js/2.1c465935.chunk.js"
  },
  {
    "revision": "5e9b6f5c16b720e8a86875f97734673e",
    "url": "/assen/static/js/2.1c465935.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fd4f4d0667132b79c8ad",
    "url": "/assen/static/js/main.1e27b592.chunk.js"
  },
  {
    "revision": "d463cde1f7b698f7d8fc",
    "url": "/assen/static/js/runtime-main.bf39bdfd.js"
  }
]);