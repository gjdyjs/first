import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import CartHistoryList from './list';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class CartHistory extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root}
            style={{position:"absolute",width:"80%",left:"10%",backgroundColor:"white",border:"1px solid rgba(0,0,0,0.1)"}}
            >
                <TableContainer component={Paper}>
                <CartHistoryList id = {id}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(CartHistory);