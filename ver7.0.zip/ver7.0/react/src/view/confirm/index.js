import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import Confirm from './confirm';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class CartConfirmIndex extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root}
            style={{position:"absolute",width:"80%",left:"10%",backgroundColor:"white",border:"1px solid rgba(0,0,0,0.1)"}}
            >
                <TableContainer component={Paper}>
                <Confirm id = {id}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(CartConfirmIndex);