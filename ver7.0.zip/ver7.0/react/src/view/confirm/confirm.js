import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button} from '@material-ui/core';
import { withRouter } from 'react-router';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import {Link} from "react-router-dom";
import axios from 'axios';
const styles = theme => ({
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
});
class Confirm extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            total:'',
            souryou:'',
            list:[],
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            version:'',
            list:[]
        };
        this.getListData()
        this.getAddData(this.props.id)
    }
    getAddData(id){
        axios.get("/assen/selectDefaultAddress",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                 tantoBushoName:res.data.tantoBushoName,
                 tantoshaName:res.data.tantoshaName,
                 thumonshaCd:res.data.thumonshaCd,
                 thumonshaName:res.data.thumonshaName,
                 hassosakiCd:res.data.hassosakiCd,
                 hassosakiName:res.data.hassosakiName,
                 hassosakiBusho:res.data.hassosakiBusho,
                 yubinNum:res.data.yubinNum,
                 address:res.data.address,
                 telNum:res.data.telNum,
                 version:res.data.version
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    getListData(){
        axios.get("/assen/FinalAssenhinCartList",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                list:res.data
            })
            this.allPrice()
        })
        .catch((error)=>{
            console.log(error)
        })
        axios.get("/assen/getSouryou",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            this.setState({
                souryou:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    doJump=()=>{
        this.props.history.push(`/assen/address/${this.props.id}`);
    }
    getRealStorage=()=>{
        axios.get("/assen/getCartListRealStorage",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            if(res.data){
                axios.post("/assen/insertJuhattyuData",
                    {
                        torihikisakiCd:this.props.id.toString()
                    },
                    {
                        headers:{"token":sessionStorage.getItem("token")}
                    }
                )
                .then(res=>{
                    if(res.data!=0){
                        var encode = window.btoa(res.data)
                        window.location.href=`/assen/print/${encode}`
                    }else{
                        alert("注文が失敗しました")
                    }
                })  
                .catch((error)=>{
                    console.log(error)
                })
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doSubmit=(e)=>{
        e.preventDefault();
        this.getRealStorage()
    }
    render(){
        const {classes} = this.props;
        return(
            <div className = "cartList" style={{position:"absolute",top:"10%",width:"100%"}}>
                <div style={{position:"absolute",width:"100%",backgroundColor:"white"}}>
                    <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>
                    &gt;&gt;<Link to={`/assen/address/${this.props.id}`} style={{ textDecoration:'none',color:'blue'}}>発送先入力</Link>
                    &gt;&gt;注文確認
                    <Table aria-label="caption table">
                        <TableRow>
                            <TableCell></TableCell>
                            <TableCell></TableCell>
                        </TableRow>
                    </Table>
                    <div>
                        {
                            this.state.list.map((value,key)=>{
                                return<div key={key}>
                                        <Table aria-label="caption table" style={{width:"65%"}}>
                                        <TableRow>
                                            <TableCell align="left">                                        
                                            <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                            style = {{float:"left",height:"200px",width:"200px"}}/>
                                            <div style = {{textAlign:"left"}}>  
                                                <h3 style={{width:"70%"}}>{value.assenhinName}</h3>
                                                <div>斡旋品＃:{value.assenhinCd}</div>
                                                担当部署：{value.bushoName}<br/>
                                                在庫数：{value.zaikoSuu-value.thumonSuu}<br/>
                                                {
                                                    value.kaiinTekiyou?
                                                    <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} <span style={{color:"red"}}>※会員価額適用</span></div>:
                                                    <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} </div>
                                                }
                                                <div>注文数:{value.thumonSuu}</div> 
                                            </div>
                                            </TableCell>
                                        </TableRow>
                                        </Table>
                                    </div>
                            })
                        }
                    </div>
                    <div style={{position:"absolute",width:"100%",backgroundColor:"white",borderRight:"1px solid rgba(0,0,0,0.1)",borderLeft:"1px solid rgba(0,0,0,0.1)"}}>
                        <Table aria-label="caption table" style={{width:"65%"}}>
                                <TableCell>
                                <Typography variant="h6" color="inherit" noWrap>
                                    入力者
                                </Typography>
                                </TableCell>
                                <TableCell></TableCell>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>担当部署</TableCell>
                            <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoBushoName}</TableCell>
                            </TableRow>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>担当者</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoshaName}</TableCell>
                            </TableRow>
                        </Table>
                        <br/>
                        <Table aria-label="caption table" style={{width:"65%"}}>
                                <TableCell>
                                <Typography variant="h6" color="inherit" noWrap>
                                    注文者
                                </Typography>
                                </TableCell>
                                <TableCell></TableCell>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>注文者＃</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.thumonshaCd}:{this.state.thumonshaName}</TableCell>
                            </TableRow>
                        </Table>
                        <br/>
                        <Table aria-label="caption table" style={{width:"65%"}}>
                                <TableCell>
                                <Typography variant="h6" color="inherit" noWrap>
                                    発送先
                                </Typography>
                                </TableCell>
                                <TableCell></TableCell>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>発送先＃</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.hassosakiCd}:{this.state.hassosakiName}</TableCell>
                            </TableRow>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>発送先部署</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.hassosakiBusho}</TableCell>
                            </TableRow>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>郵便番号</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.yubinNum}</TableCell>
                            </TableRow>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>住所</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.address}</TableCell>
                            </TableRow>
                            <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                                <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>電話番号</TableCell>
                                <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.telNum}</TableCell>
                            </TableRow>
                        </Table>
                        <br/>
                        </div>
                </div>
                <div style = {{position:"absolute",left:"70%",top:"135px"}}>
                    <form style = {{borderRadius:"10%",width:"250px",height:"350px",border:"5px solid rgba(0,0,0,0.2)"}}>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                            <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                            <h3>送料:{this.state.souryou} 円</h3>
                            <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                            <h3 style={{color:"red"}}>合計:{Number(parseInt(this.state.total)+parseInt(this.state.souryou)).toLocaleString('en-US')} 円</h3>
                            <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doSubmit}>
                                注文
                            </Button>
                            <br/><br/>
                            <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doJump}>
                                発送先入力に戻る
                            </Button>
                            </div>
                    </form>
                    
                </div>
            </div>
           
        )
    }
}
export default withStyles(styles)(withRouter(Confirm));