import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import axios from 'axios';
import qs from 'qs';
import { withRouter } from 'react-router';
class Sub extends Component{
    constructor(props){
      super(props)
      this.state={
        list:[]
      }
      this.getData()
    }
    getData(){
      axios.get("/assen/Category",{
        headers:{"token":sessionStorage.getItem("token")}
      })
         .then((res)=>{
             this.setState({
                list:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    handleSearch=(categoryCd,categoryName)=>{
          const orderType = 10
          var data = {searchAssenhinName:"",searchCategoryId:categoryCd,searchCategoryName:categoryName,searchYoyaku:0,orderType:orderType}
          data = qs.stringify(data)
          this.props.history.push(`/assen/list/${data}`);
    }
    render(){
        return(
              <div>
                <List style={{position:"absolute",width:"11%",top:"12%",left:"0%",zIndex:"998"}}>
                  {
                    this.state.list.map((value,key)=>(
                    <ListItem button key={key} >
                      <ListItemText style={{textAlign:"center"}} primary={value.categoryName} onClick = {()=>this.handleSearch(value.categoryCd,value.categoryName)}/>
                    </ListItem>
                    ))
                  }
                </List>
                <Divider />
              </div>
          
        )
    }
}
export default withRouter(Sub);