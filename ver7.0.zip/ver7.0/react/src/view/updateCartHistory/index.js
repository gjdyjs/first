import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Toolbar from '@material-ui/core/Toolbar';
import ThumonDetail from './thumonDetail';
import qs from 'qs';
import {Link} from "react-router-dom";
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class UpdateCarthistory extends Component{
    render(){
        let data = window.atob(this.props.match.params.data);
        data = qs.parse(data);
        const {classes} = this.props;
        return(
            <div className={classes.root}
            style={{position:"absolute",width:"80%",left:"10%",backgroundColor:"white"}}
            >
                <Toolbar/>
                <br/>
                    <div>
                        <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>
                        &gt;&gt;注文履歴修正
                    </div>
                    <div id = "print">
                    <ThumonDetail data = {data}/>
                    </div>
            </div>
        )
    }
}
export default withStyles(styles)(UpdateCarthistory);