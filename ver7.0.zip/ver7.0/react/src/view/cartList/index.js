import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import SubMainHeader from '../subMainHeader';
import CartList from './cartList';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class CartIndex extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",height:"100%",width:"80%",left:"10%"}}>
                <TableContainer component={Paper}>
                <SubMainHeader/>
                <CartList id = {id}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(CartIndex);