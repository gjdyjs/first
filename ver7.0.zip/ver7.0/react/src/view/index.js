import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import axios from 'axios';
import Category from './category';
import SubMainHeader from './subMainHeader';
const styles = theme => ({
    root: {
        display: 'flex',
        minWidth: '960px',
        minHeight: '700px',
        backgroundColor:"white",
      },
});
class Index extends Component{
    constructor(props){
      super(props)
      this.state={
        list:[],
        systemMessage:'',
        janetMessage:''
      }
      this.getData()
    }
    getData(){
        axios.get("/assen/systemMessage",{
          headers:{"token":sessionStorage.getItem("token")}
          })
          .then((res)=>{
              this.setState({
                  systemMessage:res.data
              })
          })
          .catch((error)=>{
              console.log(error)
          })
         axios.get("/assen/janetMessage",{
          headers:{"token":sessionStorage.getItem("token")}
          })
         .then((res)=>{
             this.setState({
                  janetMessage:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",height:"100%",width:"80%",left:"10%",backgroundColor:"white"}}>
              <TableContainer component={Paper}>
              <SubMainHeader/>
              <Category/>
                <form style={{border:"solid 1px",height:"200px",position:"absolute",width:"50%",left:"25%",top:"20%",textAlign:"center"}}>
                  <h2 style={{textAlign:"center"}}>JANET推進チームからのお知らせ</h2>
                  <hr/>
                  <div dangerouslySetInnerHTML={{__html: this.state.systemMessage}}/>
                </form>
                <form style={{border:"solid 1px",height:"200px",position:"absolute",width:"50%",left:"25%",top:"50%",textAlign:"center"}}>
                  <h2 style={{textAlign:"center"}}>システムからのお知らせ</h2>
                  <hr/>
                  <div dangerouslySetInnerHTML={{__html: this.state.janetMessage}}/>
                </form>
              </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(Index);