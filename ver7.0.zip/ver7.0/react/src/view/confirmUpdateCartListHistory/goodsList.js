import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button} from '@material-ui/core';
import { withRouter } from 'react-router';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import {Link} from "react-router-dom";
import axios from 'axios';
import qs from 'qs';
const styles = theme => ({
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
});
class GoodsList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            total:'',
            souryou:'',
            list:[],
            juhattyubi:'',
            jyuhatyuVersion:''
        };
        this.getListData(this.props.data)
    }
    getListData(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuAssenhinListUpdate/${dataParams}`+Date.parse(new Date()),
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
               this.getJuhattyuVersion(res.data[0].nendo,res.data[0].juhattyuCd)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getJuhattyuVersion=(nendo,juhattyuCd)=>{
        axios.get("/assen/getJuhattyuVersion",{
            params:{
                nendo:nendo,
                juhattyuCd:juhattyuCd
            },
            headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            this.setState({
                souryou:res.data.souryou,
                jyuhatyuVersion:res.data.version
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    doJump=()=>{
        var data = {juhattyuCd:this.props.data.juhattyuCd,nendo:this.props.data.nendo,
            torihisakiCd:this.props.data.torihisakiCd,times:'1'+Date.parse(new Date())}
        data = qs.stringify(data)
        var encode = window.btoa(data)   
        this.props.history.push(`/assen/updateHistory/${encode}`);
    }
    getRealStorage=()=>{
        axios.get("/assen/getThumonzumiCartListStorage",
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            if(res.data){
                axios.post("/assen/updateJuhattyuData",
                    {
                        version:this.state.jyuhatyuVersion.toString(),
                        nendo:this.props.data.nendo.toString(),
                        juhattyuCd:this.props.data.juhattyuCd.toString()
                    },
                    {
                        headers:{"token":sessionStorage.getItem("token")}
                    }                 
                ).then(res=>{
                    var encode = window.btoa(res.data)
                    res.data!=0?this.props.history.push(`/assen/endUpdateHistory/${encode}`):alert("注文が失敗しました")
                })
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doSubmit=(e)=>{
        e.preventDefault();
        this.getRealStorage()
    }
    render(){
        const {classes} = this.props;
        return(
            <div className = "cartList" style = {{textAlign:"left",width:"70%"}}>
                <br/>
                <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>
                &gt;&gt;注文履歴修正確認
                <Table aria-label="caption table">
                    <TableRow>
                        <TableCell></TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </Table>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                    <Table aria-label="caption table">
                                    <TableRow>
                                        <TableCell align="left">                                        
                                        <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                        style = {{float:"left",height:"200px",width:"200px"}}/>
                                        <div style = {{textAlign:"left"}}>  
                                            <h3>{value.assenhinName}</h3>
                                            <div>斡旋品＃:{value.assenhinCd}</div>
                                            担当部署：{value.bushoName}<br/>
                                            在庫数：{value.zaikoSuu}<br/>
                                            {
                                                value.kaiinTekiyou?
                                                <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} <span style={{color:"red"}}>※会員価額適用</span></div>:
                                                <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} </div>
                                            }
                                            <div>注文数:{value.thumonSuu}</div> 
                                        </div></TableCell>
                                    </TableRow>
                                    </Table>
                                </div>
                        })
                    }
                </div>
                <div style = {{position:"absolute",left:"70%",top:"150px",backgroundColor:"white"}}>
                    <form style = {{borderRadius:"10%",width:"250px",height:"350px",border:"5px solid rgba(0,0,0,0.2)"}}>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                            <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                            <h3>送料:{this.state.souryou} 円</h3>
                            <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                            <h3 style={{color:"red"}}>合計:{Number(parseInt(this.state.total)+parseInt(this.state.souryou)).toLocaleString('en-US')} 円</h3>
                            <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doSubmit}>
                                注文
                            </Button>
                            <br/><br/>
                            <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doJump}>
                                修正画面に戻る
                            </Button>
                            </div>
                    </form>
                    
                </div>
            </div>
           
        )
    }
}
export default withStyles(styles)(withRouter(GoodsList));