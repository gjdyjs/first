import React,{Component} from "react";
import {Switch,Route} from "react-router-dom";
import Index from "../view/index";
import Home from "../view/list/index";
import DetailIndex from "../view/detail/index";
import CartIndex from "../view/cartList/index";
import AddressIndex from "../view/address/index";
import CartConfirmIndex from "../view/confirm/index";
import PrintIndex from "../view/print/index";
import CartHistory from "../view/cartHistory/index";
import DetailCarthistory from "../view/detailCartHistory/index";
import UpdateCartHistory from "../view/updateCartHistory/index";
import ConfirmUpdateCartListHistory from "../view/confirmUpdateCartListHistory/index";
import EndUpdateCartListHistory from "../view/endUpdateCartListHistory/index";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                <Route exact path = '/assen/top' component = {Index}/>
                <Route path = '/assen/list/:data' component = {Home}/>
                <Route path = '/assen/detail/:data' component = {DetailIndex}/>
                <Route path = '/assen/cartList/:id' component = {CartIndex}/>
                <Route path = '/assen/address/:id' component = {AddressIndex}/>
                <Route path = '/assen/cartConfirm/:id' component = {CartConfirmIndex}/>
                <Route path = '/assen/print/:id' component = {PrintIndex}/>
                <Route path = '/assen/history/:id' component = {CartHistory}/>
                <Route path = '/assen/detailHistory/:data' component = {DetailCarthistory}/>
                <Route path = '/assen/updateHistory/:data' component = {UpdateCartHistory}/>
                <Route path = '/assen/confirmUpdateHistory/:data' component = {ConfirmUpdateCartListHistory}/>
                <Route path = '/assen/endUpdateHistory/:id' component = {EndUpdateCartListHistory}/>
            </Switch>

        );
    }
}
export default RouterIndex;