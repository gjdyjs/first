import React,{Component} from "react";
import {Switch,Route, Redirect} from "react-router-dom";
import PrivateRoute from "./privateRoute";
import Login from "../view/login";
import Index from "../view/index";
import Home from "../view/list/index";
import DetailIndex from "../view/detail/index";
import CartIndex from "../view/cartList/index";
import AddressIndex from "../view/address/index";
import CartConfirmIndex from "../view/confirm/index";
import PrintIndex from "../view/print/index";
import CartHistory from "../view/cartHistory/index";
import DetailCarthistory from "../view/detailCartHistory/index";
import UpdateCartHistory from "../view/updateCartHistory/index";
import ConfirmUpdateCartListHistory from "../view/confirmUpdateCartListHistory/index";
import EndUpdateCartListHistory from "../view/endUpdateCartListHistory/index";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                <Route exact path = '/assen/login' component = {Login}/>
                <Redirect from="/*" to="/assen/login"/>
                <PrivateRoute path = '/assen/top' component = {Index}/>
                <PrivateRoute path = '/assen/list/:data' component = {Home}/>
                <PrivateRoute path = '/assen/detail/:data' component = {DetailIndex}/>
                <PrivateRoute path = '/assen/cartList/:id' component = {CartIndex}/>
                <PrivateRoute path = '/assen/address/:id' component = {AddressIndex}/>
                <PrivateRoute path = '/assen/cartConfirm/:id' component = {CartConfirmIndex}/>
                <PrivateRoute path = '/assen/print/:id' component = {PrintIndex}/>
                <PrivateRoute path = '/assen/history/:id' component = {CartHistory}/>
                <PrivateRoute path = '/assen/detailHistory/:data' component = {DetailCarthistory}/>
                <PrivateRoute path = '/assen/updateHistory/:data' component = {UpdateCartHistory}/>
                <PrivateRoute path = '/assen/confirmUpdateHistory/:data' component = {ConfirmUpdateCartListHistory}/>
                <PrivateRoute path = '/assen/endUpdateHistory/:id' component = {EndUpdateCartListHistory}/>
            </Switch>
        );
    }
}
export default RouterIndex;