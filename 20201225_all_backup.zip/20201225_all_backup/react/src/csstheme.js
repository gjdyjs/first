import { createMuiTheme, makeStyles } from '@material-ui/core';
import { teal } from '@material-ui/core/colors';
export const theme = createMuiTheme({
    typography: {
        fontFamily: [
            "メイリオ",
            "Meiryo",
            "游ゴシック",
            "Yu Gothic",
            "YuGothic",
            "Hiragino Kaku Gothic ProN",
            "Hiragino Kaku Gothic Pro",
            "ＭＳ ゴシック",
            "sans-serif"
        ].join(','),
        button: {
            textTransform: "none"
        },
        fontSize: 14,
        htmlFontSize:14
    },
    props: {
        MuiTextField: {
            variant: "filled"
        },
        MuiCheckbox: {
            color: "primary"
        },
        MuiRadio: {
            color: "primary"
        },
        MuiSwitch: {
            color: "primary"
        },
  
    },
    palette: {
        primary: {
            main: teal[500],
            light: teal[200],
            dark: teal[600]
        }
    },
    
})

export const usestyles = makeStyles({
    mainwidth: {
        minWidth : '900px'
    },

})
