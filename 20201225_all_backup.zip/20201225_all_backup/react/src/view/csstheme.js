import { createMuiTheme, makeStyles } from '@material-ui/core';
export const theme = createMuiTheme({
    typography: {
        button: {
            textTransform: "none"
        },
    },
    text:{
        fontSize: 15,
    },
    props: {
        MuiTextField: {
            variant: "filled"
        },
        MuiCheckbox: {
            color: "primary"
        },
        MuiRadio: {
            color: "primary"
        },
        MuiSwitch: {
            color: "primary"
        }
  
    },
    palette: {
        primary: {
            main: "#007bff",
            light: "#00E1FF",
            dark: "##00BFD8"
        }
    },
    
})

export const usestyles = makeStyles({
    mainwidth: {
        minWidth : '900px'
    },

})
