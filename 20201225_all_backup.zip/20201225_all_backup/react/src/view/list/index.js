import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import qs from 'qs';
import Category from '../category';
import SubMainHeader from '../subMainHeader';
import IndexList from './list';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class Home extends Component{
    render(){
        let data = qs.parse(this.props.match.params.data);
        const {classes} = this.props;
        return(
            <div className={classes.root} 
            style={{position:"absolute",height:"100%",width:"80%",left:"8%"}}>
                <TableContainer component={Paper}>
                <SubMainHeader/>
                <Category/>
                <IndexList data = {data}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(Home);