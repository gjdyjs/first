import React, { Component } from 'react';
import {Link} from "react-router-dom";
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import axios from 'axios';
import '../alert';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 80,
        minHeight: 80
      },
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0.5),
        minWidth: 50,
      },
  });
class CartList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            total:'',
            list:[]
        };
        this.getData(this.props.id)
    }
    getData(){
        axios.get(`/assen/AssenhinCartList/`+Date.parse(new Date()),{
            headers:{"token":sessionStorage.getItem("token")}
        })
           .then((res)=>{
               this.setState({
                   list:res.data
               })
               this.allPrice()
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    handleCount=(e)=>{
        this.state.list.find(item=>item.assenhinCd==e.target.name).thumonSuu=e.target.value
        this.setState({
            list:this.state.list
        })
    }
    getRealStorage=(assenhinCd,hansuu,thumonSuu,version)=>{
        let data = {
            assenhinCd:assenhinCd.toString(),
            hansuu:hansuu.toString()
        }
        let dataParams = JSON.stringify(data)
        axios.get(`/assen/getRealStorage/${dataParams}`,{
            headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            if((res.data-thumonSuu)>=0){
                axios.post("/assen/updateThumonsuu",{
                    version:version.toString(),
                    assenhinCd:assenhinCd.toString(),
                    hansuu:hansuu.toString(),
                    thumonSuu:thumonSuu.toString()
                },{
                    headers:{"token":sessionStorage.getItem("token")}
                })
                .then(res=>{
                    res.data!==0?this.getData(this.props.id):alert("変更が失敗しました")
                }) 
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doChange=(assenhinCd,hansuu,thumonSuu,version)=>{
    const result1 = /^\d+$/.test(thumonSuu)
    const result2 = /^([1-9]\d*|0)$/.test(thumonSuu)
            if(thumonSuu.length!==0){
                if(result1){
                    if(thumonSuu>0){
                        if(result2){
                            this.getRealStorage(assenhinCd,hansuu,thumonSuu,version)
                        }else{
                            alert("頭数字を0以外で入力してください")
                        }
                    }else{
                        alert("最小値は1です")
                    }
                }else{
                    alert("数字または整数を入力してください")
                }
            }else{
                alert("新たな注文数を入力してください")
            }
    }
    doDelete=(assenhinCd,hansuu,version)=>{
        axios.post("/assen/delete",{
            version:version.toString(),
            assenhinCd:assenhinCd.toString(),
            hansuu:hansuu.toString()
        },{
            headers:{"token":sessionStorage.getItem("token")}
        }).then(res=>{
            res.data===1?window.location.reload():alert("削除が失敗しました")
        })  
    }
    doSubmit=(e)=>{
        e.preventDefault();
        this.props.history.push(`/assen/address/${this.props.id}`);
    }
    doJump=()=>{
        this.props.history.push("/assen/top");
    }
    render(){
        const { classes } = this.props;
        return(
            <div className = "cartList" style={{position:"absolute",width:"100%",top:"15%"}}>
                <div style={{}}>
                    <Breadcrumbs className={classes.spacegaiyo}>
                        <Link to='/assen/top' style={{ textDecoration: 'none', color: 'blue' }}>ホーム</Link>
                        <Typography>カート内容</Typography>
                    </Breadcrumbs>
                    <div style = {{position:"absolute",left:"70%",top:"50px",backgroundColor:"white",zIndex:"998",borderRadius:"10%"}}>
                        <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"350px"}}>
                            <br/>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{textAlign:"center"}}> 
                                <br/>
                                <h3 style={{color:"red"}}>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                                <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doSubmit}>
                                    購入手続き　
                                </Button>
                                <br/><br/>
                                <Button color="primary" variant="outlined" className={classes.button2} style={{backgroundColor:"orange",color:"black"}} onClick = {this.doJump}>
                                    ホーム画面に戻る
                                </Button>
                                </div>
                        </form>
                    </div>
                <hr style={{border:"1px solid rgba(0,0,0,0.2)"}}/>
                <div style={{position:"absolute",height:'100%',width:"100%",top:"20px"}}>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key} style={{backgroundColor:"white"}}>
                                            <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                            style={{float:"left",height:"200px",width:"200px"}}/>
                                            <div style = {{textAlign:"left"}}>  
                                                <h3 style={{width:"600px"}}>{value.assenhinName}</h3> 
                                                担当部署：{value.bushoName}<br/>
                                                在庫数：{value.zaikoSuu-value.thumonSuu}<br/>
                                                価額：￥{Number(value.kakaku).toLocaleString('en-US')}<br/>
                                                <br/>
                                                <div>
                                                注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" 
                                                    name={value.assenhinCd} value = {this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu} 
                                                    onChange = {this.handleCount}/>
                                                    <Button color="primary" variant="outlined" className={classes.button}
                                                    style={{backgroundColor:"yellow",color:"black"}} 
                                                    onClick = {()=>this.doChange(value.assenhinCd,value.hansuu,
                                                    this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu,value.version)}>
                                                        変更
                                                    </Button>
                                                    <Button color="primary" variant="outlined" className={classes.button} 
                                                    style={{backgroundColor:"red",color:"black"}} 
                                                    onClick = {()=>this.doDelete(value.assenhinCd,value.hansuu,value.version)}>
                                                        削除
                                                    </Button>
                                                </div>
                                            </div>
                                </div>
                        })
                    }
                </div>
                </div>
            </div>  
        )
    }
}
export default withStyles(styles)(withRouter(CartList));