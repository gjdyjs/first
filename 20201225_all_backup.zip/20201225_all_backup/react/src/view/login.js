import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import cookie from 'react-cookies';
import axios from 'axios';
const styles = theme => ({
    root: {
        display: 'flex',
        minWidth: '960px',
        minHeight: '700px',
      },
});
class Login extends Component{
    constructor(props){
      super(props)
      this.state={
        userId:'',
        pass:''
      }
    }
    getUserID=(e)=>{
        this.setState({
            userId:e.target.value
        })
    }
    getUserPass=(e)=>{
        this.setState({
            pass:e.target.value
        })
    }
    doSubmit=(userId,password)=>{
        var fData = new FormData();
        fData.append('userId', userId.toString())
        fData.append('password', password.toString())
        axios.post("/assen/perform_login", fData)
        .then((res) => {
            if(res.data){
                axios.get("/assen/Authentication")
                .then((res)=>{
                    if(res.data!==null){
                        sessionStorage.setItem("userId",res.data.userId)
                        sessionStorage.setItem("torihikisakiName",res.data.torihikisakiName)
                        sessionStorage.setItem("torihikisakiCd",res.data.torihikisakiCd)
                        sessionStorage.setItem("token",res.data.csrfKey)
                        let inFifteenMinutes = new Date(new Date().getTime() + 1 * 1 * 60000);
                        cookie.save('token',res.data.csrfKey,{ expires: inFifteenMinutes })
                        window.location.href="/assen/top";
                    }
                })
                .catch((error)=>{
                    console.log(error)
                })
            }else{
                alert("ユーザIDまたはパスワードは正しくありません")
            }
        }).catch((error) => {
            console.log(error)
        })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",width:"99%",height:"99%",backgroundColor:'#f9f9f9'}}> 
                {
                    this.props.location.pathname==="/assen/login"?
                    <div 
                    style={{position:"relative",left:"35%",top:"20%",textAlign:"center",width:"400px",height:"300px",
                    backgroundColor:"white",borderRadius:"3px",border:"1px solid rgba(0,0,0,0.3)"}}>
                      <h3>斡旋品発注システム</h3>
                      <div style={{border:"1px solid rgba(0,0,0,0.1)"}}/>
                        <div style={{fontSize:"14px",textAlign:"left",marginLeft:"10px"}}>
                            <p>ユーザーIDとパスワードを入力してください。</p>
                            <p>ユーザーID<input type="text" required onChange={this.getUserID} value={this.state.userId} placeholder="ユーザーIDを入力してください"
                            style={{width:"200px",height:"20px",margin:"5px",borderRadius:"3px",border:"1px solid rgba(0,0,0,0.2)"}}
                            /></p>
                            <p>パスワード<input type="password" required onChange={this.getUserPass} value={this.state.pass} placeholder="パスワードを入力してください"
                            style={{width:"200px",height:"20px",margin:"5px",borderRadius:"3px",border:"1px solid rgba(0,0,0,0.2)"}}
                            /></p>
                            <input type="button" value="ログイン" onClick={()=>this.doSubmit(this.state.userId,this.state.pass)}
                            style={{backgroundColor:"#007563",color:"white",
                            width:"80px",height:"30px",fontSize:"14px",borderRadius:"3px",border:"1px solid rgba(0,0,0,0.2)"}}/>
                            <p style={{fontSize:"12px"}}>インターネット標準のSSL(Secure Socket Layer)により暗号化されます。</p>
                        </div>
                    </div>:<div/>
                }
            </div>
        )
    }
}
export default withStyles(styles)(withRouter(Login));