import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import axios from 'axios';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
    },
});
class CancelComfirm extends Component{
    constructor(props){
        super(props)
        this.state = {
            open:false,
        };
    }
    handleClickOpen=()=>{
        this.setState({
            open:true
        }) 
    }
    handleClose=()=>{
      this.setState({
        open:false
      })
    }
    doCancel=()=>{
      axios.post("/assen/cancelCartListHistory",
          {
              version:this.props.version.toString(),
              juhattyuCd:this.props.juhattyuCd.toString()
          },
          {
              headers:{"token":sessionStorage.getItem("token")}
          }
      ).then(res=>{
          this.props.history.push(`/assen/history/${this.props.torihisakiCd}`);
      }) 
    }
    render(){
      const { classes } = this.props;
        return(
            <div>
            <Button variant="outlined" color="primary" style={{backgroundColor:"orange",color:"black",width:"150px"}} onClick={this.handleClickOpen}>
              発注取消
            </Button>
            <Dialog open={this.state.open} onClose={this.handleClose}>
                <DialogContent>
                <Typography>
                    発注を取消します。よろしいですか?
                </Typography>
                </DialogContent>
              <DialogActions>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.doCancel}>
                    はい
                </Button>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleClose}>
                    いいえ
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        )
    }
}
export default withStyles(styles)(withRouter(CancelComfirm));
