import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import AddressInfo from './addressInfo';
import GoodsList from './goodsList';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import {Link} from "react-router-dom";
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class EndUpdateCartListHistory extends Component{
    render(){
        let id = window.atob(this.props.match.params.id);
        const {classes} = this.props;
        return(
            <div className={classes.root}
            style={{position:"absolute",height:"100%",width:"80%",left:"10%",backgroundColor:"white"}}
            >
                <CssBaseline />
                <TableContainer component={Paper}>
                <Container maxWidth="lg" >
                    <Toolbar/>
                    <br/>
                    <Breadcrumbs className={classes.spacegaiyo}>
                        <Link to='/assen/top' style={{ textDecoration: 'none', color: 'blue' }}>ホーム</Link>
                        <Typography>注文履歴修正完了</Typography>
                    </Breadcrumbs>
                    <br/><br/>
                    <div id = "print">
                    <GoodsList id = {id}/>
                    <br/>
                    <AddressInfo id = {id}/>
                    <br/>
                    </div>
                </Container>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(EndUpdateCartListHistory);