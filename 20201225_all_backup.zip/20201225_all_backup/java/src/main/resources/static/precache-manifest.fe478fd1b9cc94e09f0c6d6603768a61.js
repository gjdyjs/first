self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e672c6485fc0478420c5810fe665b048",
    "url": "/assen/index.html"
  },
  {
    "revision": "e7f16f519ef2d41ba609",
    "url": "/assen/static/js/2.31bf49e1.chunk.js"
  },
  {
    "revision": "4e3f8d4bad1db285aba0fceffdc7b967",
    "url": "/assen/static/js/2.31bf49e1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "45fbda10f6cfed473a1d",
    "url": "/assen/static/js/main.7a88fb94.chunk.js"
  },
  {
    "revision": "d463cde1f7b698f7d8fc",
    "url": "/assen/static/js/runtime-main.bf39bdfd.js"
  }
]);