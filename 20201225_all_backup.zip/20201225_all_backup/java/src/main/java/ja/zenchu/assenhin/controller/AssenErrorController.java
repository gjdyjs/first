package ja.zenchu.assenhin.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ja.zenchu.assenhin.security.LoginUserDetails;

@Controller
@RequestMapping("/error")
public class AssenErrorController implements ErrorController{

	@Override
	public String getErrorPath() {
		// TODO 自動生成されたメソッド・スタブ
		return "/error";
	}
	
	@RequestMapping
	  public String  error(HttpServletRequest req,@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
		Object errorCode = req.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		if (errorCode != null && errorCode.toString().equals("404") ) {
			return "forward:/";
		}
		return "/error";
		
	  }
	



}