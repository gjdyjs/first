package ja.zenchu.assenhin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.DownloadDataDto;
import ja.zenchu.assenhin.entity.mapper.MKanrenManualMapper;
import ja.zenchu.assenhin.enumtype.SystemTypeEnum;

/**
 * マニュアルファイルダウンロード用
 * @author take
 *
 */
@Service
public class ManualService {

	@Autowired
	MKanrenManualMapper mKanrenManualMapper;

	/**
	 * 斡旋品のマニュアル
	 * @return 
	 */
	public DownloadDataDto getManual() {
		return mKanrenManualMapper.getAssenManual(SystemTypeEnum.ASSENHIN.getSystemId());
	}
}
