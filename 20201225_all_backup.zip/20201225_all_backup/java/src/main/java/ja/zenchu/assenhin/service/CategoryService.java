package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.CategoryDto;
import ja.zenchu.assenhin.entity.mapper.AMstCategoryMapper;

/**
 * カテゴリ一覧の取得
 * ※現開発中のsubServiceからこちらに変更
 * @author take
 *
 */
@Service
public class CategoryService {

	@Autowired
	AMstCategoryMapper aMstCategoryMapper;
	
	/**
	 * カテゴリリストを取得
	 * @return
	 */
	public List<CategoryDto> searchCategoryList(boolean addFirst) {
		List<CategoryDto> rtnList = aMstCategoryMapper.searchCategoryList(LocalDate.now());
		if (addFirst) {
			CategoryDto defDto = new CategoryDto();
			defDto.setCategoryCd((short) 0);
			defDto.setCategoryName("　"); //表示高さ対応
			rtnList.set(0, defDto);
		}
		return rtnList;
	}
}
