package ja.zenchu.assenhin.enumtype;

/**
 * 受発注登録時に使用する空欄取引先用
 * @author take
 *
 */
public enum AllTorihikisakiEnum {

	/** その他取引先 */
	SONOTA(99999999);
	
	private int torihikisakiCd;
	
	private AllTorihikisakiEnum(int i) {
		this.torihikisakiCd = i;
	}
	
	public int getTorihikisakiCd() {
		return this.torihikisakiCd;
	}
}
