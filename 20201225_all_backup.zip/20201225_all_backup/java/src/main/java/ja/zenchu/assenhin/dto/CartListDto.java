package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.time.LocalDate;

import ja.zenchu.assenhin.utils.DateUtility;
import lombok.Getter;
import lombok.Setter;

/**
 * カートリスト用
 * @author take
 *
 */
@Getter
@Setter
public class CartListDto implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8082315190692791491L;
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	/** 斡旋品名 */
	private String assenhinName;
	/** 在庫数(カートで必要か確認) */
	private int zaikoSuu;
	/**  部署名 */
	private String bushoName;
	/** 価格 */
	private int kakaku;
	/** 注文数 */
	private int thumonSuu;
	/** バージョン（最終的にカートの更新排他制御に使いたい） */
	private int version;
	/** 価格設定区分 */
	private short kakakuCls;
	/** 予約区分 */
	private short yoyakuCls;
	
	//以下は当日注文及び注文履歴閲覧でのみ使う予定
	/** 年度 */
	private short nendo;
	/** 注文ID（受発注#) */
	private int juhattyuCd;
	/** 注文明細番号(受発注明細#) */
	private short juhattyuMeisaiCd;
	/** 受発注日 */
	private LocalDate juhattyubi;
	//最終注文確認画面と注文履歴系で使用
	/** 会員価格適用 */
	private boolean kaiinTekiyou;
	/** 削除フラグ **/
	private int deleteFlag;

	/**
	 * 受発注日表示用
	 * LocalDateをそのまま表示するわけにもいかないのでyyyy/MM/dd形式の文字列を使う。
	 * @return
	 */
	public String getJuhattyubiStr() {
		return DateUtility.getFormatDateSlash(juhattyubi);
	}
}
