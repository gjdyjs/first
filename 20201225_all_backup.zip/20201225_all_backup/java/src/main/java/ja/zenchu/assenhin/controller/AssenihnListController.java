package ja.zenchu.assenhin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.AssenhinListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.AssenihnListService;

/**
 * 斡旋品検索結果一覧画面
 *
 */
@RestController
public class AssenihnListController {
	@Autowired
	AssenihnListService assenhinListService;
	/**
	 * 一覧画面商品情報を取得
	 *
	 */
    @RequestMapping(value = "/listData/{data}",method= RequestMethod.GET)
    public List<AssenhinListDto> GetList(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	String searchAssenhinNameText=params.substring(0,params.indexOf("&"));
    	String orderTypeText = params.substring(params.lastIndexOf("&")+1,params.length());
    	String idAndYoyaku = params.substring(params.indexOf("&")+1,params.lastIndexOf("&"));
    	String searchCategoryIdText=idAndYoyaku.substring(0, idAndYoyaku.indexOf("&"));
    	String searchYoyakuText=idAndYoyaku.substring(idAndYoyaku.indexOf("&")+1, idAndYoyaku.length());
    	short searchCategoryId= 0;
    	boolean searchYoyaku = true;
    	int orderType = Integer.valueOf(orderTypeText.substring(orderTypeText.indexOf("=")+1, orderTypeText.length())).intValue();
    	String searchAssenhinName = "";
    	if(searchCategoryIdText.length()>17) {
    		searchCategoryId=Short.parseShort(searchCategoryIdText.substring(searchCategoryIdText.indexOf("=")+1, searchCategoryIdText.length()));
    	}
    	if(searchAssenhinNameText.length()>19) {
    		searchAssenhinName=searchAssenhinNameText.substring(searchAssenhinNameText.indexOf("=")+1, searchAssenhinNameText.length());
    	}
    	if(Integer.valueOf(searchYoyakuText.substring(searchYoyakuText.indexOf("=")+1, searchYoyakuText.length())).intValue() == 1) {
    		searchYoyaku=false;
    	}
    	return assenhinListService.selectAssenhinList(searchAssenhinName, searchCategoryId, searchYoyaku, orderType,loginUserDto);
    }
}
