package ja.zenchu.assenhin.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import ja.zenchu.assenhin.dto.LoginUserDto;

public class LoginUserDetails implements UserDetails {
	private static final long serialVersionUID = 1L;
	
	private LoginUserDto userDto;
	
	public LoginUserDetails(LoginUserDto user) {
		this.setUserDto(user);
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}

	public LoginUserDto getUserDto() {
		return userDto;
	}

	public void setUserDto(LoginUserDto userDto) {
		this.userDto = userDto;
	}

	@Override
	public String getUsername() {
		return this.userDto.getUserId();
	}

	@Override
	public String getPassword() {
		return this.userDto.getPassword();
	}
	/**取引先#*/
	public Integer getTorihikisakiCd() {
		return this.userDto.getTorihikisakiCd();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
}
