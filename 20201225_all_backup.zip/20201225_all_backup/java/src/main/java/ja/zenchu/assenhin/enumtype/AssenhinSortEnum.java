package ja.zenchu.assenhin.enumtype;

/**
 * 斡旋品リスト並び順ソート用
 * @author take
 *
 */
public enum AssenhinSortEnum {

	/** 登録日降順 */
	TOUROKUBI_ASC(10),
	/** 登録日昇順 */
	TOUROKUBI_DESC(20),
	/** 価格昇順 */
	KAKAKU_ASC(30),
	/** 価格降順 */
	KAKAKU_DESC(40);
	;
	
	private int sortNo;
	
	private AssenhinSortEnum(int i) {
		this.sortNo = i;
	}
	public int getSortNo() {
		return this.sortNo;
	}
	/**
	 * 並び順
	 * @param i
	 * @return
	 */
	public static AssenhinSortEnum getSortEnum(int i) {
		for (AssenhinSortEnum renum : AssenhinSortEnum.values()) {
			if (renum.getSortNo() == i) {
				return renum;
			}
		}
		//何もなければ登録日昇順（デフォルト）
		return TOUROKUBI_ASC;
	}
}
