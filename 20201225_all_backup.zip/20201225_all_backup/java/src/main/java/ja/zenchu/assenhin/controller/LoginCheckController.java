package ja.zenchu.assenhin.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.config.NonAuth;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.RtnUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.CategoryService;

/**
 * ログイン情報を取得
 *
 */
@CrossOrigin
@RestController
public class LoginCheckController {
	@NonAuth
	@PostMapping(value="/perform_login")
	public String login(Model model, @ModelAttribute("modelMap") ModelMap modelMap) {
		if (!modelMap.isEmpty()) {
			model.addAttribute("errorMsg", modelMap.getAttribute("errorMsg"));
			return null;
		}

		return "true";
	}
	@NonAuth
	@GetMapping(value="/loginRtn")
	public Boolean loginRtn(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
		return true;
	}
	
	@NonAuth
	@GetMapping(value="/loginError")
	public Boolean loginError(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
		return false;
	}	
	@NonAuth
    @GetMapping(value="/Authentication")
    public RtnUserDto Authentication(@AuthenticationPrincipal  LoginUserDetails loginUserDetails, HttpServletResponse response){
    	if (loginUserDetails != null) {
    		//ユーザー情報がある場合必要なものだけ抜き出してJsonファイルで送信
        	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
        	RtnUserDto newDto = new RtnUserDto();
        	newDto.setUserId(loginUserDto.getUserId());
        	newDto.setTorihikisakiCd(loginUserDto.getTorihikisakiCd());
        	newDto.setTorihikisakiName(loginUserDto.getTorihikisakiName());
        	newDto.setCsrfKey(loginUserDto.getCsrfKey());;
        	Cookie cookie = new Cookie("assen_csfrkey", loginUserDto.getCsrfKey());
        	cookie.setMaxAge(1 * 24 * 60 * 60);
        	response.addCookie(cookie);;
        	return newDto;
    	}
    	//ないと思うがここに来たらNullを送付
    	return null;
    } 
}
