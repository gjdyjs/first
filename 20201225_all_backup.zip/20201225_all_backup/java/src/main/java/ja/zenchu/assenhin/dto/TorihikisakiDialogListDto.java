package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 注文者・発送先のダイアログ検索で使用する取引先のリスト
 * @author take
 *
 */
@Getter
@Setter
public class TorihikisakiDialogListDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3035999692592465186L;
	/** 取引先#(キーは取引先番号なので) */
	private Integer torihikisakiCd;
	
	/** 取引先名 */
	private String torihikisakiName;

}
