package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author take
 *
 */
@Getter
@Setter
public class RtnUserDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -338053671068264995L;
	/** ユーザー情報 */
	private String userId;
	/** 取引先# */
	private Integer torihikisakiCd;
	/** 取引先名 */
	private String torihikisakiName;
	/** CSRFのキー */
	private String csrfKey;
}
