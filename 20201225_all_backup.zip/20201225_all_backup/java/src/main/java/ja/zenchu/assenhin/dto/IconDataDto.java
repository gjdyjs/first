package ja.zenchu.assenhin.dto;

import lombok.Data;

/**
 * アイコンファイルの取得用
 * @author take
 *
 */
@Data
public class IconDataDto {
	
	private byte[] fileData;

}
