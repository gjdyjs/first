package ja.zenchu.assenhin.enumtype;


/**
 * 斡旋品会員区分を取得
 * @author take
 *
 */
public enum KakakuSetteiClsEnum {

	/** 一般 */
	IPPAN(1),
	/** 県中 */
	KENCHU(2),
	/** 書店 */
	SHOTEN(3);
	
	private int kakakuCls;
	
	private KakakuSetteiClsEnum(int i) {
		this.kakakuCls = i;
	}
	/**
	 * 会員区分
	 * @return
	 */
	public short getKakakuSetteiCls() {
		return (short) this.kakakuCls;
	}
	/**
	 * 価格区分Enum取得（使わないかもしれないが）
	 * @param s　価格区分
	 * @return
	 */
	public KakakuSetteiClsEnum getKakakuSetteiClsEnum(short s) {
		int i = (int) s;
		for (KakakuSetteiClsEnum en : KakakuSetteiClsEnum.values()) {
			if (en.kakakuCls == i) {
				return en;
			}
		}
		//一致しなかった場合は一般
		return IPPAN;
	}
}
