import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button,TextField} from '@material-ui/core';
import { withRouter } from 'react-router';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import DialogThumonsha from './dialogThumonsha';
import DialogHassosaki from './dialogHassosaki';
import axios from 'axios';
import qs from 'qs';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 80,
      },
    textField2: {
        margin: theme.spacing(0),
        minWidth: 100,
      },
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class ThumonDetail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            jyuhatyuVersion:'',
            souryou:'',
            list:[],
            total:'',
            juhattyubi:'',
            nyuryokushaCd:'',
            nyuryokushaName:'',
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            addInfoVersion:'',
            addInfo:[],
            userList:[],
            arr:[]
        };
        if(this.props.data.times.indexOf(0)==0){
            this.getListData(this.props.data)
            this.getAddData(this.props.data)
        }else{
            this.getListDataUpdate(this.props.data)
            this.getAddDataUpdate(this.props.data)
        }

    }
    getAddDataUpdate(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuHassosakiUpdate/${dataParams}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    addInfoVersion:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getAddData(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuHassosaki/${dataParams}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    addInfoVersion:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getInfo1(thumonshaCd,thumonshaName){
        this.setState({
            thumonshaCd:thumonshaCd,
            thumonshaName:thumonshaName
        })
    }
    getInfo2(hassosakiCd,hassosakiName,address,hassosakiBusho,yubinNum,telNum){
        this.setState({
            hassosakiCd:hassosakiCd,
            hassosakiName:hassosakiName,
            hassosakiBusho:hassosakiBusho,
            address:address,
            yubinNum:yubinNum,
            telNum:telNum
        })
    }
    handleClear=(e)=>{
        this.setState({
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
          })
    }
    handleInput=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
        if(e.target.name=="thumonshaCd"){
            if(e.target.value.length>=4){
                this.autoSetUser(e.target.value)
            }
        }
        if(e.target.name=="hassosakiCd"){
            if(e.target.value.length>=4){
                this.autoSetAddress(e.target.value)
            }
        }
    }
    autoSetUser=(thumonshaCd)=>{
            axios.get(`/assen/searchThumonshaList/${thumonshaCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setUserOnly(thumonshaCd)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    autoSetAddress=(hassosakiCd)=>{
            axios.get(`/assen/selectHassosaki/${hassosakiCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                this.setState({
                    addInfo:res.data
                })
                this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    setUserOnly=(thumonshaCd)=>{
        this.state.arr=this.state.userList.find(item=>item.thumonshaCd==thumonshaCd)
        this.setState({
            thumonshaName:this.state.arr.thumonshaName,
            userList:[],
            arr:[]
        })
    }
    setAdressOnly=(addInfo)=>{
        this.setState({
            hassosakiName:addInfo[0].hassosakiName,
            hassosakiCd:addInfo[0].hassosakiCd,
            address:addInfo[0].address,
            hassosakiBusho:addInfo[0].hassosakiBusho,
            yubinNum:addInfo[0].yubinNum,
            telNum:addInfo[0].telNum,
            addInfo:[],
            arr:[]
        })
    }
    handleCopy=(e)=>{
        if(!(this.state.thumonshaCd.toString().replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            axios.get(`/assen/selectHassosaki/${this.state.thumonshaCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
              this.setState({
                addInfo:res.data
              })
              this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
        }
    }
    getListDataUpdate(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuAssenhinListUpdate/${dataParams}`+Date.parse(new Date()),
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
               this.getJuhattyuVersion(res.data[0].nendo,res.data[0].juhattyuCd)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getListData(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuAssenhinList/${dataParams}`+Date.parse(new Date()),
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
               this.getJuhattyuVersion(res.data[0].nendo,res.data[0].juhattyuCd)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getJuhattyuVersion=(nendo,juhattyuCd)=>{
        axios.get("/assen/getJuhattyuVersion",{
            params:{
                nendo:nendo,
                juhattyuCd:juhattyuCd
            },
            headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            this.setState({
                souryou:res.data.souryou,
                jyuhatyuVersion:res.data.version
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    handleCount=(e)=>{
        this.state.list.find(item=>item.assenhinCd==e.target.name).thumonSuu=e.target.value
        this.setState({
            list:this.state.list
        })
    }
    getRealStorage=(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)=>{
        let data = {
            assenhinCd:assenhinCd.toString(),
            hansuu:hansuu.toString()
        }
        let dataParams = JSON.stringify(data)
        axios.get(`/assen/getRealStorage/${dataParams}`,
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            if((res.data-thumonSuu)>=0){
                axios.post("/assen/updateToujitsuThumonSuu",
                    {
                        thumonshaCd:this.state.thumonshaCd.toString(),
                        version:version.toString(),
                        nendo:nendo.toString(),
                        juhattyuCd:juhattyuCd.toString(),
                        thumonSuu:thumonSuu.toString(),
                        juhattyuMeisaiCd:juhattyuMeisaiCd.toString()
                    },
                    {
                        headers:{"token":sessionStorage.getItem("token")}
                    }
                ).then(res=>{
                    res.data!=0?this.getListDataUpdate(this.props.data):alert("変更が失敗しました")
                })               
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doChange=(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)=>{
    const result1 = /^\d+$/.test(thumonSuu)
    const result2 = /^([1-9]\d*|0)$/.test(thumonSuu)
            if(thumonSuu.length!=0){
                if(result1){
                    if(thumonSuu>0){
                        if(result2){
                            this.getRealStorage(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)
                        }else{
                            alert("頭数字を0以外で入力してください")
                        }
                    }else{
                        alert("最小値は1です")
                    }
                }else{
                    alert("数字または整数を入力してください")
                }
            }else{
                alert("注文数を入力してください")
            }
    }
    doDelete=(nendo,juhattyuCd,juhattyuMeisaiCd,version)=>{
        axios.post("/assen/deleteToujitsuThumon",
            {
                nendo:nendo.toString(),
                version:version.toString(),
                juhattyuCd:juhattyuCd.toString(),
                juhattyuMeisaiCd:juhattyuMeisaiCd.toString()
            },
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        ).then(res=>{
            res.data==1?this.getListDataUpdate(this.props.data):alert("削除が失敗しました")
        })
    }
    doUpdate=(e)=>{
        e.preventDefault();
        if(!(this.state.thumonshaName==''||this.state.yubinNum==''||this.state.address==''||
        this.state.telNum==''||this.state.hassosakiName==''||this.state.hassosakiBusho=='')){
            axios.post("/assen/updateToujitsuHassosaki",
                {
                    nyuryokushaCd:this.state.nyuryokushaCd.toString(),
                    nyuryokushaName:this.state.nyuryokushaName.toString(),
                    tantoBushoName:this.state.tantoBushoName.toString(),
                    tantoshaName:this.state.tantoshaName.toString(),
                    thumonshaCd:this.state.thumonshaCd.toString(),
                    thumonshaName:this.state.thumonshaName.toString(),
                    hassosakiCd:this.state.hassosakiCd.toString(),
                    hassosakiName:this.state.hassosakiName.toString(),
                    hassosakiBusho:this.state.hassosakiBusho.toString(),
                    yubinNum:this.state.yubinNum.toString(),
                    address:this.state.address.toString(),
                    telNum:this.state.telNum.toString(),
                    version:this.state.addInfoVersion.toString()
                },
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                if(res.data-this.state.addInfoVersion>0){
                    var data = {juhattyuCd:this.props.data.juhattyuCd,nendo:this.props.data.nendo,torihisakiCd:this.props.data.torihisakiCd}
                    data = qs.stringify(data)
                    var encode = window.btoa(data)
                    this.props.history.push(`/assen/confirmUpdateHistory/${encode}`)
                }else{
                    alert("発送先情報更新が失敗しました") 
                }
            })
            .catch((error)=>{
                console.log(error)
            })
        }else(
            alert("必須項目を入力してください")
        )
    }
    doCancel=()=>{
        axios.post("/assen/cancelCartListHistory",
            {
                version:this.state.jyuhatyuVersion.toString(),
                juhattyuCd:this.props.data.juhattyuCd.toString()
            },
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        ).then(res=>{
            this.props.history.push(`/assen/history/${this.props.data.torihisakiCd}`);
        }) 
    }
    doPrint(){
        var newStr = document.getElementById("print").innerHTML;
        var win = window.open("","newWindow","height=800,width=700,top=100");
        win.document.body.innerHTML = newStr;
        win.print();
    }
    render(){
        const {classes} = this.props;
        return(
            <div>
            <div className = "cartList" style = {{textAlign:"left",width:"900px"}}>
                <Table aria-label="caption table" style={{width:"400px"}}>
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap style={{color:"red"}}>
                            注文情報
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>発注＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.props.data.juhattyuCd}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>発注日</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.juhattyubi}</TableCell>
                    </TableRow>
                </Table>
                <Table aria-label="caption table">
                    <TableRow>
                        <TableCell></TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </Table>
                <div>
                {
                    this.state.list.map((value,key)=>{
                        return<div key={key}>
                        <div>
                        <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                        style={{float:"left",height:"200px",width:"200px"}}/>
                        <div style = {{textAlign:"left"}}>  
                        <h3>{value.assenhinName}</h3> 
                        <div>斡旋品＃:{value.assenhinCd}</div>
                        担当部署:{value.bushoName}<br/>
                        在庫数:{value.zaikoSuu}<br/>
                            {
                            value.kaiinTekiyou?
                            <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} <span style={{color:"red"}}>※会員価額適用</span></div>:
                            <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} </div>
                            }
                        <br/>
                        <div>
                        注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" 
                            name={value.assenhinCd} value = {this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu} 
                            onChange = {this.handleCount}/>
                            <Button color="primary" variant="outlined" className={classes.button} 
                            onClick = {()=>this.doChange(value.assenhinCd,value.hansuu,value.nendo,value.juhattyuCd,
                            this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu,value.juhattyuMeisaiCd,value.version)}>
                                変更
                            </Button>
                            <Button color="primary" variant="outlined" className={classes.button} 
                            onClick = {()=>this.doDelete(value.nendo,value.juhattyuCd,value.juhattyuMeisaiCd,value.version)}>
                                削除
                            </Button>
                        </div>
                        <hr style={{border:"1px solid rgba(0,0,0,0.2)"}}/> 
                        </div>
                        </div>
                        </div>
                    })
                }
                </div>
                
                <div style = {{position:"absolute",left:"70%",top:"150px"}}>
                <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"400px"}}>
                <h2 style={{textAlign:"left"}}>カート</h2>
                <div style={{textAlign:"center"}}> 
                    <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                    <h3>送料:{this.state.souryou} 円</h3>
                    <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                    <h3 style={{color:"red"}}>合計:{Number(parseInt(this.state.total)+parseInt(this.state.souryou)).toLocaleString('en-US')} 円</h3>
                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doUpdate}>
                        修正
                    </Button>
                    <br/><br/>
                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doCancel}>
                        発注取消
                    </Button>
                    <br/><br/>
                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doPrint}>
                        印刷
                    </Button>
                    </div>
                </form>
                </div>
            </div>
            <div>
                <div style = {{width:"70%"}}>
                    <Table aria-label="caption table">
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            入力者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>担当部署</TableCell>
                    <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoBushoName}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>担当者</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoshaName}</TableCell>
                    </TableRow>
                    </Table>
                    <br/>
                    <h2>注文者&nbsp;&nbsp;&nbsp;
                        <DialogThumonsha getInfo1={(thumonshaCd,thumonshaName)=>this.getInfo1(thumonshaCd,thumonshaName)}/> 
                    </h2>
                    <div>
                        注文者#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <TextField id="outlined-basic" variant="outlined" name="thumonshaCd" value={this.state.thumonshaCd} className={classes.textField2} size = "small" onChange = {this.handleInput}/>&nbsp;
                        <TextField id="outlined-basic" variant="outlined" name="thumonshaName" value={this.state.thumonshaName} className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                    </div>
                    <h2>
                        <div>
                        発送先&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                        <DialogHassosaki getInfo2={(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)=>this.getInfo2(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)}/>
                        <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-40px"}} className={classes.button} onClick = {this.handleCopy} >
                        注文者コピー
                        </Button>&nbsp;
                        <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-40px"}} className={classes.button} onClick = {this.handleClear}>
                        クリア
                        </Button>
                    </h2>

                    <div>
                        発送先#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                        <TextField id="outlined-basic" name="hassosakiCd" value={this.state.hassosakiCd} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>&nbsp;
                        <TextField id="outlined-basic" name="hassosakiName" value={this.state.hassosakiName} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                    </div>
                    <br/>
                    <div>
                        発送先部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                        <TextField id="outlined-basic" name="hassosakiBusho" value={this.state.hassosakiBusho} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                    </div>
                    <br/>                                          
                    <div>
                        郵便番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                        <TextField id="outlined-basic" name="yubinNum" value={this.state.yubinNum} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                    </div>
                    <br/>                                          
                    <div>
                        住所&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                        <TextField id="outlined-basic" name="address" value={this.state.address} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>             
                    </div>
                    <br/>                                          
                    <div>
                        電話番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                        <TextField id="outlined-basic" name="telNum" value={this.state.telNum} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                    </div>
                                   
                </div>                                
            </div>
            </div>         
        )
    }
}
export default withStyles(styles)(withRouter(ThumonDetail));