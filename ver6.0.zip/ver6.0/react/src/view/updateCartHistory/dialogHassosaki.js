import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Pagination from "material-ui-flat-pagination";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
  dialog: {
    height:800,
    },
  textField: {
      margin: theme.spacing(0),
      minWidth: 500,
    },
  button: {
      margin: theme.spacing(0),
      minWidth: 50,
    },
  table: {
      minWidth: 300,
    },
  tableCell: {
      minWidth: 170,
    },
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
    },
});
class DialogHassosaki extends Component{
    constructor(props){
        super(props)
        this.state = {
            open:false,
            txt:'',
            radioValue:'',
            offset: 0,
            perPage: 5,
            list:[],
            hassosakiList:[]
        };
    }
    handleClickOpen=()=>{
        this.setState({
            open:true
        }) 
    }
    handleInput=(e)=>{
      this.setState({
        txt:e.target.value
      })
    }
    handleSearch=()=>{
      let id = this.state.txt
      if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
        axios.get(`/assen/searchHassosakiList/${id}`,
          {
            headers:{"token":sessionStorage.getItem("token")}
          }
        )
        .then((res)=>{
            this.setState({
               list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
      }
    }
    handleClickPagination = offset => {
      this.setState({ offset })
    }
    handleClose=()=>{
      this.setState({
          list:[],
          open:false
      })
    }
    handleRadio=(e)=>{
      this.setState({
          radioValue:e.target.value
      })
    }
    handleCheck=(hassosakiCd)=>{
      if(!(hassosakiCd.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
          this.searchHassosaki(hassosakiCd)
      }else{
        alert("発送先を選んでください")
      }
    }
    searchHassosaki=(id)=>{
      axios.get(`/assen/selectHassosaki/${id}`,
        {
          headers:{"token":sessionStorage.getItem("token")}
        }
      )
      .then((res)=>{
        this.setState({
          hassosakiList:res.data
        })
        this.props.getInfo2(this.state.hassosakiList[0].hassosakiCd,this.state.hassosakiList[0].hassosakiName,
          this.state.hassosakiList[0].address,this.state.hassosakiList[0].hassosakiBusho,this.state.hassosakiList[0].yubinNum,
          this.state.hassosakiList[0].telNum) 
      })
      .catch((error)=>{
          console.log(error)
      })
      this.setState({
        open:false,
        list:[],
        hassosakiList:[],
        radioValue:''
      })
    }
    render(){
      const { classes } = this.props;
        return(
            <div>
            <Button variant="outlined" color="primary" onClick={this.handleClickOpen}>
              検索
            </Button>
            <Dialog open={this.state.open} onClose={this.handleClose} className={classes.dialog}>
              <DialogContent>
                <TextField id="outlined-basic" label="検索条件（発送先＃または発送先名）" variant="outlined" className={classes.textField} onChange = {this.handleInput}/>
              </DialogContent>
              <DialogActions>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                    検索
                </Button>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {()=>this.handleCheck(this.state.radioValue)}>
                    発送先選択
                </Button>
              </DialogActions>
              <TableContainer>
                <Table  aria-label="caption table">
                  <TableHead>
                    <TableRow>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                  {this.state.list
                  .slice(this.state.offset,this.state.offset+this.state.perPage)
                  .map((value,key) => {
                      return (
                          <div key={key}>
                            <TableRow>
                              <TableCell align="right" >
                                <input type="radio" value={value.hassosakiCd} checked={this.state.radioValue==value.hassosakiCd} onChange={this.handleRadio}/>
                              </TableCell>
                              <TableCell align="right" >{value.hassosakiCd}</TableCell>
                              <TableCell align="right" >{value.hassosakiName}</TableCell>
                            </TableRow>
                          </div>
                              );
                          })}                    
                              <Pagination
                              currentPageColor='default'
                              size='large'
                              style={{position:"absolute",left:"200px"}}
                              limit={this.state.perPage}
                              offset={this.state.offset}
                              total={this.state.list.length}
                              onClick={(e, offset) => this.handleClickPagination(offset)}
                              />
                  </TableBody>
                </Table>
              </TableContainer>
            </Dialog>
          </div>
        )
    }
}
export default withStyles(styles)(DialogHassosaki);
