import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import ListItem from '@material-ui/core/ListItem';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from "material-ui-flat-pagination";
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box';
const styles = theme => ({
    root: {
        flexGrow: 1,
        display: 'flex',
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
});
class IndexList extends Component{
    constructor(arg){
        super(arg);   
        this.state = {
            list:[],
            offset: 0,
            perPage: 10,
            orderCd:''     
        };
        this.getData(this.props.data) 
    }
    shouldComponentUpdate(nextProps){
        if(this.props.data.searchAssenhinName !== nextProps.data.searchAssenhinName||
            this.props.data.searchCategoryId!==nextProps.data.searchCategoryId||
            this.props.data.searchYoyaku!==nextProps.data.searchYoyaku
            ){
            this.state.offset = 0;
            this.getData(nextProps.data);
            return false;
        }
        return true;
    }
    getData(data){
        axios.get(`/assen/listData/searchAssenhinName=${data.searchAssenhinName}&searchCategoryId=${data.searchCategoryId}&searchYoyaku=${data.searchYoyaku}&orderType=${data.orderType}`,
            {
            headers:{"token":sessionStorage.getItem("token")}
            })
        .then((res)=>{
            this.setState({
                list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    handleClickPagination = offset => {
        this.setState({ offset })
    }
    handleSort=(e)=>{
        this.setState({
            orderCd:e.target.value
        })
        axios.get(`/assen/listData/searchAssenhinName=${this.props.data.searchAssenhinName}&searchCategoryId=${this.props.data.searchCategoryId}&searchYoyaku=${this.props.data.searchYoyaku}&orderType=${e.target.value.toFixed()}`,
        {
        headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            this.setState({
                list:res.data,
                offset:0
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{height:'100%',position:"absolute",width:"100%",top:"15%"}}>
                <Grid container spacing={5}>
                    <Grid item lg={6} style={{position:"absolute",left:"15%",top:"-2%",fontSize:"15px"}}>
                    <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>&gt;&gt;
                    {this.props.data.searchAssenhinName!=""?this.props.data.searchAssenhinName:this.props.data.searchCategoryName}検索結果
                    </Grid>
                    <Grid item lg={6}>
                    <FormControl variant="outlined" size = "small" className={classes.formControl} style={{position:"absolute",top:"0%",left:"60%"}}>
                        <InputLabel>並び順</InputLabel>
                        <Select style={{textAlign:"left"}} onChange={this.handleSort} value={this.state.orderCd}>
                            <MenuItem value={10}>登録日昇順</MenuItem>
                            <MenuItem value={20}>登録日降順</MenuItem>
                            <MenuItem value={30}>価額昇順</MenuItem>
                            <MenuItem value={40}>価額降順</MenuItem>
                        </Select>
                    </FormControl>
                    </Grid>
                    <Grid item lg={12}>
                    <div style={{backgroundColor:"white",top:"10%"}}>
                        <List dense compoent="span">
                            {this.state.list
                            .slice(this.state.offset,this.state.offset+this.state.perPage)
                            .map((value,key) => {
                                return (
                                    <div key={key}>
                                    <ListItem key={value.assenhinCd} style={{height:'100%',width:"80%",top:"15%",left:"20%"}}>
                                        <Link to={`/assen/detail/assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}>
                                            <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                            style={{height:"200px",width:"200px"}}
                                            />
                                        </Link>
                                        <ListItemText>
                                        <Link to={`/assen/detail/assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`} 
                                        style={{ textDecoration:'none',color:'blue'}}>{value.assenhinName}</Link>
                                            <div>斡旋品＃:{value.assenhinCd}</div>
                                            <div>価額：{value.kakaku}</div>
                                            <div>在庫数：{value.zaikoSuu}</div>
                                            <div>担当部署：{value.bushoName}</div>
                                        </ListItemText>
                                    </ListItem>
                                    <Divider style={{width:"70%",left:"20%"}}/>
                                    </div>
                                );
                            })}
                        </List>
                        <Box component="span">
                            <Pagination
                            currentPageColor='default'
                            size='large'
                            style={{position:"absolute",left:"43%"}}
                            limit={this.state.perPage}
                            offset={this.state.offset}
                            total={this.state.list.length}
                            onClick={(e, offset) => this.handleClickPagination(offset)}
                            />
                        </Box>
                    </div>
                    </Grid> 
                </Grid>
            </div>
        )
    }
}
export default withStyles(styles)(IndexList);