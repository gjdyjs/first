import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import qs from 'qs';
import Category from '../category';
import SubMainHeader from '../subMainHeader';
import IndexList from './list';
// const styles = theme => ({
//     // root: {
//     //     display: 'flex',
//     //   },
// });
class Home extends Component{
    render(){
        let data = qs.parse(this.props.match.params.data);
        // const {classes} = this.props;
        return(
            <div style={{position:"absolute",height:"100%",width:"80%",left:"10%",backgroundColor:"white"}}>
                <SubMainHeader/>
                <Category/>
                <IndexList data = {data}/>
            </div>
        )
    }
}
export default Home;
// export default withStyles(styles)(Home);