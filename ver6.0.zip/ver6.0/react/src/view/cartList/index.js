import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import SubMainHeader from '../subMainHeader';
import CartList from './cartList';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class CartIndex extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",height:"100%",width:"80%",left:"10%",backgroundColor:"white"}}>
                <SubMainHeader/>
                <CartList id = {id}/>
            </div>
        )
    }
}
export default withStyles(styles)(CartIndex);