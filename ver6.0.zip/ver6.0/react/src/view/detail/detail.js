import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import Table from '@material-ui/core/Table';
import Typography from '@material-ui/core/Typography';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    root: {
        display: 'flex',
      },
    textField: {
        margin: theme.spacing(0),
        maxWidth: 60,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Detail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            list:[],
            tokubetsuKakakuListLength:'',
            tokubetsuKakakuList:[]
        };
        this.getData(this.props.data.assenhinCd,this.props.data.hansuu)
    }
    getData(assenhinCd,hansuu){
        var data = {
            assenhinCd:assenhinCd,
            hansuu:hansuu
        }
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/detailList/assenhinCd=${assenhinCd}&hansuu=${hansuu}`,
            {
            headers:{"token":sessionStorage.getItem("token")}
            })
        .then((res)=>{
            this.setState({
                list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
        // axios.get(`/assen/detail/${dataParams}`,{
        //     headers:{"token":sessionStorage.getItem("token")}
        //     })
        // .then((res)=>{
        //     this.setState({
        //         list:res.data
        //     })
        // })
        // .catch((error)=>{
        //     console.log(error)
        // })
        axios.get(`/assen/getTokubetsuKakakuList/${dataParams}`,{
            headers:{"token":sessionStorage.getItem("token")}
            })
        .then((res)=>{
            res.data.length==0?this.setState({tokubetsuKakakuListLength:0}):this.setState({tokubetsuKakakuListLength:res.data.length})
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    getRealStorage=(count,assenhinCd)=>{
        let data = {
            assenhinCd:assenhinCd,
            hansuu:this.props.data.hansuu,
            thumonSuu:count
        }
        let dataParams = JSON.stringify(data)
        axios.get(`/assen/getRealStorage/${dataParams}`,{
            headers:{"token":sessionStorage.getItem("token")}
            })
        .then((res)=>{
            if((res.data-count)>=0){
                axios.post("/assen/insertCart/",{
                    assenhinCd:assenhinCd.toString(),
                    hansuu:this.props.data.hansuu.toString(),
                    thumonSuu:count.toString()
                },{
                    headers:{"token":sessionStorage.getItem("token")}
                })
                .then(res=>{
                    if(res.data==1){
                        window.location.href=`/assen/cartList/${sessionStorage.getItem("userId")}`
                    }else{
                        alert("注文が失敗しました")
                    }
                })  
                .catch((error)=>{
                    console.log(error)
                })
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doInsert=()=>{
        let assenhinCd = this.props.data.assenhinCd
        let count = this.state.count
        const result1 = /^\d+$/.test(count)
        const result2 = /^([1-9]\d*|0)$/.test(count)
        if(!(count.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            if(result1){
                if(count>0){
                    if(result2){
                        this.getRealStorage(count,assenhinCd)
                    }else{
                        alert("頭数字を0以外で入力してください")
                    }
                }else{
                    alert("最小値は1です")
                }
            }else{
                alert("数字または整数を入力してください")
            }
        }else{
            alert("注文数はからです")
        } 
    }
    render(){
        const { classes } = this.props;
        return(
                <div>
                    <div style = {{position:"absolute",width:"70%"}}>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key} style={{position:"absolute",width:"100%"}}>
                                        <div style={{position:"absolute",top:"150px",left:"10%"}}>
                                            <Link to = '/assen/top' style={{ textDecoration:'none',color:'blue'}}>ホーム</Link>
                                            &gt;&gt;{value.assenhinName}
                                        </div>
                                        <div style={{position:"absolute",top:"200px",left:"10%"}}>
                                        <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                        style={{height:"300px",width:"300px"}}/>
                                        <Typography variant="h6" color="inherit" noWrap
                                        style={{position:"absolute",top:"10%",left:"120%"}}
                                        >
                                            {value.assenhinName}
                                        </Typography>
                                        <Table aria-label="caption table" style={{position:"absolute",top:"30%",width:"100%",left:"120%"}}>
                                            <TableRow>
                                                <TableCell>斡旋品#:</TableCell>
                                                <TableCell align="left">{value.assenhinCd}</TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell>価額：</TableCell>
                                                <TableCell align="left">￥{Number(value.kakaku).toLocaleString('en-US')}</TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell>担当部署：</TableCell>
                                                <TableCell align="left">{value.bushoName}部署</TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell>在庫数：</TableCell>
                                                <TableCell align="left">{Number(value.zaikoSuu).toLocaleString('en-US')}</TableCell>
                                            </TableRow>
                                        </Table>
                                        </div>
                                            <div style={{position:"absolute",left:"15%",top:"550px",fontSize:"20px"}}>
                                                {
                                                    this.state.tokubetsuKakakuListLength>0?
                                                    <div>
                                                    <div style={{color:"green"}}>
                                                        特別価格
                                                    </div>
                                                    <div >
                                                        まちづくり情報センター(20冊未満)<span style={{color:"red"}}>￥{Number(value.kakaku).toLocaleString('en-US')}</span>
                                                        <br/>
                                                        まちづくり情報センター(20冊以上)<span style={{color:"red"}}>￥{Number(value.kakaku).toLocaleString('en-US')}</span>
                                                    </div>
                                                    </div>
                                                    :<div></div>
                                                }
                                                <br/>
                                                <div style={{color:"green"}}>
                                                    詳細
                                                </div>
                                                <div >
                                                    {value.gaiyo}
                                                </div>
                                            </div>
                                    </div>
                        })
                    }
                    </div>
                    <div style = {{position:"absolute",width:"30%",left:"70%",top:"270px",backgroundColor:"white"}}>
                    <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"250px"}}>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{position:"absolute",left:"60px",top:"100px",fontSize:"20px"}}>
                                注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" value = {this.state.count} onChange = {this.handleCount}/>
                            </div>
                            <Button color="primary" variant="outlined" style={{position:"absolute",left:"60px",top:"150px",backgroundColor:"orange",color:"black"}} className={classes.button} onClick = {this.doInsert}>
                                カートに入れる
                            </Button>
                    </form>
                    </div>
                </div>
            
        )
    }
}
export default withStyles(styles)(withRouter(Detail));