import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import AddressInfo from './addressInfo';
import GoodsList from './goodsList';
import qs from 'qs';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class CartConfirmIndex extends Component{
    render(){
        let data = window.atob(this.props.match.params.data);
        data = qs.parse(data);
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <TableContainer component={Paper}>
                <Container maxWidth="lg" >
                    <Toolbar/>
                    <br/>
                    <GoodsList data = {data}/>
                    <br/>
                    <AddressInfo data = {data}/>
                    <br/>
                </Container>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(CartConfirmIndex);