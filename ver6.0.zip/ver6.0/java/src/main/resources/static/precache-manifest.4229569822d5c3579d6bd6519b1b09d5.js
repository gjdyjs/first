self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d9e8b146396da402964517be899a093c",
    "url": "/assen/index.html"
  },
  {
    "revision": "3f0e16ae3541cb71de82",
    "url": "/assen/static/js/2.e99a9db3.chunk.js"
  },
  {
    "revision": "5e9b6f5c16b720e8a86875f97734673e",
    "url": "/assen/static/js/2.e99a9db3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "806c5504a4a9fd6f0611",
    "url": "/assen/static/js/main.3e208c03.chunk.js"
  },
  {
    "revision": "d463cde1f7b698f7d8fc",
    "url": "/assen/static/js/runtime-main.bf39bdfd.js"
  }
]);