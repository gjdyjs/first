package ja.zenchu.assenhin.security;

import java.time.LocalDate;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.entity.mapper.AAssenTorihikisakiMapper;
import ja.zenchu.assenhin.entity.mapper.AUserKaiinMapper;
import ja.zenchu.assenhin.entity.mapper.MKihonNendoKanriMapper;
import ja.zenchu.assenhin.entity.mapper.MKoteiKoumokuMapper;
import ja.zenchu.assenhin.entity.mapper.MSystemUserMapper;

@Service
public class LoginUserDetailsService implements UserDetailsService {
	@Autowired
	MSystemUserMapper mSystemUserMapper;
	@Autowired
	AAssenTorihikisakiMapper aAssenTorihikisakiMapper;
	@Autowired
	AUserKaiinMapper aUserKaiinMapper;
	@Autowired
	MKoteiKoumokuMapper mKoteiKoumokuMapper;
	@Autowired
	MKihonNendoKanriMapper mKihonNendoKanriMapper;
	
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		LocalDate kijunbi = LocalDate.now();
		LoginUserDto loginDto= mSystemUserMapper.selectUser(userId, kijunbi);

		if (loginDto == null) {
			throw new UsernameNotFoundException("User Not Found");
		}
		//価格区分取得
		final Short kakakuCls = aAssenTorihikisakiMapper.getKakakuSetteiCls(loginDto.getTorihikisakiCd(), kijunbi);
		if (kakakuCls == null) {
			throw new UsernameNotFoundException("AssenTorihikisaki Not Found");
		}
		loginDto.setKakakuSetteiCls(kakakuCls);
		//会員区分
		loginDto.setKaiinClsList(aUserKaiinMapper.getKaiinClsList(loginDto.getTorihikisakiCd()));
		//送料
		loginDto.setSouryou(mKoteiKoumokuMapper.getSouryou());
		//処理年度
		loginDto.setTargetNendo(mKihonNendoKanriMapper.getNendo(kijunbi));
		//キー
		final String csrfkey = UUID.randomUUID().toString();
		loginDto.setCsrfKey(csrfkey);
		return new LoginUserDetails(loginDto);
	}
}
