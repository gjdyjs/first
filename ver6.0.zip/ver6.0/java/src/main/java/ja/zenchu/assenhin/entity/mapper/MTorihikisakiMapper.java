package ja.zenchu.assenhin.entity.mapper;

import java.time.LocalDate;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ja.zenchu.assenhin.dto.AddressInfoDto;
import ja.zenchu.assenhin.dto.HassosakiListDto;
import ja.zenchu.assenhin.dto.SearchTorihikisakiDialogDto;
import ja.zenchu.assenhin.dto.SelectTorihikisakiByKeyDto;
import ja.zenchu.assenhin.dto.ThumonshaListDto;
import ja.zenchu.assenhin.dto.TorihikisakiDialogListDto;

/**
 * 取引先検索用
 * @author take
 *
 */
@Mapper
public interface MTorihikisakiMapper {
	/**
	 * 注文者の検索（一般のユーザーで一部除く条件有）
	 * @param searchDto 検索条件用
	 * @return
	 */
    List<ThumonshaListDto> searchThumonshaList(SearchTorihikisakiDialogDto searchDto);
    
    /**
     * 発送先の検索用（有効な全取引先対象）
	 * @param searchDto 検索条件用
     * @return
     */
    List<HassosakiListDto> searchHassosakiList(SearchTorihikisakiDialogDto searchDto);
    
    /***
     * 取引先#を特定して必要な住所情報を取得する
     * @param torihikisakiCd 取引先#
     * @param kijunbi 基準日（現在日で良い）
     * @return
     */
    SelectTorihikisakiByKeyDto selectTorihikisakiByKey(Integer torihikisakiCd, LocalDate kijunbi);
    
    String getNyuryokushaName(String userId, Integer torihikisakiCd, LocalDate kijunbi);
}