package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ja.zenchu.assenhin.dto.AddressInfoDto;
import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuSplitDto;
import ja.zenchu.assenhin.dto.UpdateToujitsuThumonSuuDto;
import ja.zenchu.assenhin.entity.AJuhattyu;
import ja.zenchu.assenhin.entity.AJuhattyuKey;
import ja.zenchu.assenhin.entity.AJuhattyuMeisai;
import ja.zenchu.assenhin.entity.AJuhattyuMeisaiKey;
import ja.zenchu.assenhin.entity.AToujitsuHassosaki;
import ja.zenchu.assenhin.entity.AZaiko;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMapper;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMeisaiMapper;
import ja.zenchu.assenhin.entity.mapper.AToujitsuAssenhinMapper;
import ja.zenchu.assenhin.entity.mapper.AToujitsuHassosakiMapper;
import ja.zenchu.assenhin.entity.mapper.MTorihikisakiMapper;
import ja.zenchu.assenhin.enumtype.AllTorihikisakiEnum;
import ja.zenchu.assenhin.enumtype.DeleteFlagEnum;
import ja.zenchu.assenhin.enumtype.KihyoClsEnum;
import ja.zenchu.assenhin.enumtype.ShukkoFlagEnum;
import ja.zenchu.assenhin.enumtype.UkeireKyokyuClsEnum;
import ja.zenchu.assenhin.logic.JuhattyuLogic;
import ja.zenchu.assenhin.utils.StringUtility;

/**
 * 注文済みの商品リスト・発送先データを取り扱うサービス
 * @author take
 *
 */
@Service
public class ThumonzumiDetailService {

	@Autowired
	AJuhattyuMeisaiMapper aJuhattyuMeisaiMapper;
	@Autowired
	AJuhattyuMapper aJuhattyuMapper;
	@Autowired
	MTorihikisakiMapper mTorihikisakiMapper;
	@Autowired
	AToujitsuHassosakiMapper aToujitsuHassosakiMapper;
	
	@Autowired
	AToujitsuAssenhinMapper aToujitsuAssenhinMapper;
	
	@Autowired
	ZaikoService zaikoService;
	
	@Autowired
	JuhattyuLogic juhattyuLogic;
	
	/**
	 * 注文済みの商品リストを表示
	 * @param nendo 年度
	 * @param juhattyuCd 受発注番号
	 * @param isToujitsuHenshu 当日注文編集画面の場合のみtrue、それ以外はFalseをセット
	 * @return
	 */
	@Deprecated
	public List<CartListDto> getThumonzumiAssenhinList(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd, boolean isToujitsuHenshu) {
		List<CartListDto> rtnList =  aJuhattyuMeisaiMapper.getThumonzumiAssenhinList(nendo, juhattyuCd);
		if (isToujitsuHenshu) {
			aToujitsuAssenhinMapper.deleteToujitsuThumonAll(loginUserDto.getTorihikisakiCd());
			aToujitsuAssenhinMapper.copyThumonzumiData(loginUserDto.getTorihikisakiCd(), nendo, juhattyuCd);
		}
		return rtnList;
	}
	/**
	 * 注文済みの商品リストを表示
	 * @param nendo 年度
	 * @param juhattyuCd 受発注番号
	 * @return
	 */
	public List<CartListDto> getThumonzumiAssenhinList(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd) {
		List<CartListDto> rtnList =  aJuhattyuMeisaiMapper.getThumonzumiAssenhinList(nendo, juhattyuCd);
		return rtnList;
	}
	/**
	 * 注文履歴を当日データにコピー
	 * @param loginUserDto
	 * @param nendo
	 * @param juhattyuCd
	 */
	public void copyToujitsuThumonWork(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd) {
		aToujitsuAssenhinMapper.deleteToujitsuThumonAll(loginUserDto.getTorihikisakiCd());
		aToujitsuAssenhinMapper.copyThumonzumiData(loginUserDto.getTorihikisakiCd(), nendo, juhattyuCd);
	}
	/**
	 * 編集中の当日注文情報を取得
	 * 当日注文編集用コピーテーブルから取得
	 */
	public List<CartListDto> getToujitsuHenshuAssenhinList(LoginUserDto loginUserDto) {
		List<CartListDto> rtnList = aToujitsuAssenhinMapper.getToujitsuThumonList(loginUserDto.getTorihikisakiCd());
		return rtnList;
	}
	/**
	 * 編集中の当日注文発送先情報を取得
	 * 当日発送先編集用のコピーテーブルから取得
	 * @param loginUserDto
	 * @return
	 */
	public AddressInfoDto getToujitsuHenshuHassosaki(LoginUserDto loginUserDto) {
		AToujitsuHassosaki ath = aToujitsuHassosakiMapper.selectByPrimaryKey(loginUserDto.getTorihikisakiCd());
		AddressInfoDto rtnDto = copyAddressDto(ath);
		return rtnDto;
	}
	
	
	/**
	 * 注文済みの発送先を表示
	 * @param nendo 年度
	 * @param juhattyuCd 受発注番号
	 * @return
	 */
	public AddressInfoDto getThumonzumiHassosaki(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd) {
		AddressInfoDto rtnDto = aJuhattyuMeisaiMapper.getThumonzumiHassosaki(nendo, juhattyuCd);
		LocalDate juhattyubi = aJuhattyuMapper.getJuhattyubi(nendo, juhattyuCd);
		String nyuryokushaName = null;
		if (rtnDto != null) {
			if (StringUtils.isEmpty(rtnDto.getNyuryokushaName())) {
				//入力者名が取得できない場合
				nyuryokushaName = mTorihikisakiMapper.getNyuryokushaName(loginUserDto.getUserId(), loginUserDto.getTorihikisakiCd(), juhattyubi);
				rtnDto.setNyuryokushaName(nyuryokushaName);
				rtnDto.setNyuryokushaCd(Integer.parseInt(loginUserDto.getUserId()));
			} else {
				nyuryokushaName = rtnDto.getNyuryokushaName();
			}
		} else {
			nyuryokushaName = StringUtils.EMPTY;
		}
		return rtnDto;
	}
	/**
	 * 当日注文のコピーメソッド
	 * @param nendo
	 * @param juhattyuCd
	 * @param nyuryokushaName
	 * @param juhattyubi
	 * @return
	 */
	public void copyToujitsuHassosakiWork(LoginUserDto loginUserDto, Short nendo, int juhattyuCd) {
		final int torihikisakiCd = loginUserDto.getTorihikisakiCd();
		//一時テーブル削除
		aToujitsuHassosakiMapper.deleteByPrimaryKey(torihikisakiCd);
		//注文済み発送先を取得
		AddressInfoDto aDto = aJuhattyuMeisaiMapper.getThumonzumiHassosaki(nendo, juhattyuCd);
		AToujitsuHassosaki ains = copyAddressWork(aDto);
		ains.setTorihikisakiCd(torihikisakiCd);
		int inscnt = aToujitsuHassosakiMapper.insert(ains);
	}

	
	/**
	 * 注文済みの発送先を表示
	 * @param nendo 年度
	 * @param juhattyuCd 受発注番号
	 * @param isToujitsuHenshu 当日注文編集画面の場合のみtrue、それ以外はFalseをセット
	 * @return
	 */
	@Deprecated
	public AddressInfoDto getThumonzumiHassosaki(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd, boolean isToujitsuHenshu) {
		AddressInfoDto rtnDto = aJuhattyuMeisaiMapper.getThumonzumiHassosaki(nendo, juhattyuCd);
		LocalDate juhattyubi = aJuhattyuMapper.getJuhattyubi(nendo, juhattyuCd);
		String nyuryokushaName = null;
		if (rtnDto != null) {
			if (StringUtils.isEmpty(rtnDto.getNyuryokushaName())) {
				//入力者名が取得できない場合
				nyuryokushaName = mTorihikisakiMapper.getNyuryokushaName(loginUserDto.getUserId(), loginUserDto.getTorihikisakiCd(), juhattyubi);
				rtnDto.setNyuryokushaName(nyuryokushaName);
				rtnDto.setNyuryokushaCd(Integer.parseInt(loginUserDto.getUserId()));
			} else {
				nyuryokushaName = rtnDto.getNyuryokushaName();
			}
		} else {
			nyuryokushaName = StringUtils.EMPTY;
		}
		if (isToujitsuHenshu) {
			//TODO 当日編集の際は取得したデータを当日コピー用テーブルにセット
			aToujitsuHassosakiMapper.deleteByPrimaryKey(loginUserDto.getTorihikisakiCd());
			//当日データの登録
			copyToujitsuHassosakiWork(loginUserDto, nendo, juhattyuCd);
		}
		return rtnDto;
	}
	/**
	 * 注文データの削除
	 * @param loginUserDto
	 * @param nendo
	 * @param juhattyuCd
	 * @param juhattyuMeisaiCd
	 * @param version
	 * @return 削除件数
 	 */
	public int deleteToujitsuThumon(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd, Short juhattyuMeisaiCd, Integer version) {
		return aToujitsuAssenhinMapper.deleteTojitsuThumon(loginUserDto.getTorihikisakiCd(), nendo, juhattyuCd, juhattyuMeisaiCd, version);
	}
	
	/**
	 * 当日発送先の更新
	 * @param loginUserDto
	 * @param addressInfoDto
	 * @return アップデートしたバージョンを返す。
	 */
	public int updateToujitsuHassosaki(LoginUserDto loginUserDto, AddressInfoDto addressInfoDto) {
		AToujitsuHassosaki aUpd = copyAddressWork(addressInfoDto);
		aUpd.setTorihikisakiCd(loginUserDto.getTorihikisakiCd());
		int upd = aToujitsuHassosakiMapper.updateHassosaki(aUpd);
		int version = aUpd.getVersion();
		if (upd == 1) {
			return version + 1;
		}
		return 0;
	}
	
	/**
	 * 最終的な注文の確定
	 * @param loginUserDto
	 * @param nendo
	 * @param juhattyuCd
	 * @param version
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	public int updateJuhattyuData(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd, Integer version) {
		//基準日
		final LocalDate juhattyubi = LocalDate.now();
		
		//当日の注文情報を取得
		List<CartListDto> cartList = aToujitsuAssenhinMapper.getToujitsuThumonListAll(loginUserDto.getTorihikisakiCd());
		if (cartList.size() == 0) {
			//TODO エラー処理見直し
			throw new IllegalArgumentException("注文データ取得不正");
		}
		
		//当日の発送先情報
		AToujitsuHassosaki work =   aToujitsuHassosakiMapper.selectByPrimaryKey(loginUserDto.getTorihikisakiCd());
		if (work == null) {
			//TODO エラー処理見直し
			throw new IllegalArgumentException("発送先取得不正");
		}
		//注文者・発送先Null対応
		if (work.getThumonshaCd() == null) {
			work.setThumonshaCd(AllTorihikisakiEnum.SONOTA.getTorihikisakiCd());
		}
		if (work.getHassosakiCd() == null) {
			work.setHassosakiCd(AllTorihikisakiEnum.SONOTA.getTorihikisakiCd());
		}
		
		for (CartListDto cartDto : cartList) {
			//在庫修正
			//受発注明細
			AJuhattyuMeisaiKey ajmkey = new AJuhattyuMeisaiKey();
			ajmkey.setNendo(cartDto.getNendo());
			ajmkey.setJuhattyuCd(cartDto.getJuhattyuCd());
			ajmkey.setJuhattyuMeisaiCd(cartDto.getJuhattyuMeisaiCd());;
			AJuhattyuMeisai ajm = aJuhattyuMeisaiMapper.selectByPrimaryKey(ajmkey);
			AZaiko zaiko = zaikoService.getZaikoData(ajm.getAssenhinCd(), ajm.getHansuu());
			int oldThumonsuu = ajm.getHattyuSuuryo();
			Integer newThumonsuu = cartDto.getThumonSuu();
			if (cartDto.getDeleteFlag() == DeleteFlagEnum.YUUKOU.getDeleteFlag()) {
				//在庫数の編集
				zaiko.setHattyugoZaikosuu(zaiko.getHattyugoZaikosuu() + oldThumonsuu - newThumonsuu);
				zaikoService.updateHattyugoZaikosuu(zaiko);
			} else {
				//削除の場合は在庫数戻し
				zaiko.setHattyugoZaikosuu(zaiko.getHattyugoZaikosuu() + oldThumonsuu);
				zaikoService.updateHattyugoZaikosuu(zaiko);
			}
		}
		//受発注管理情報取得
		AJuhattyuKey key = new AJuhattyuKey();
		key.setNendo(nendo);
		key.setJuhattyuCd(juhattyuCd);
		AJuhattyu juhattyu = aJuhattyuMapper.selectByPrimaryKey(key);		
		//受発注削除
		aJuhattyuMeisaiMapper.deleteJuhattyuAllData(nendo, juhattyuCd);
		//受発注明細
		short juhattyuMeisaiCd = 0;
		for (CartListDto cartDto : cartList) {
			//削除データを除く再登録
			if (cartDto.getDeleteFlag() == DeleteFlagEnum.YUUKOU.getDeleteFlag()) {
				juhattyuMeisaiCd++;
				AJuhattyuMeisai meisai =  juhattyuLogic.createToujitsuHenshuJuhattyuMeisaiData(nendo, juhattyuCd, juhattyuMeisaiCd, juhattyubi, cartDto, work, loginUserDto);
				aJuhattyuMeisaiMapper.insert(meisai);
			}
		}

		//受発注データの更新
		createUpdJuhattyuData(juhattyu, juhattyubi, work, loginUserDto);
		int upd =  aJuhattyuMapper.updateJuhattyuData(juhattyu);
		if (upd == 1) {
			//不要データ削除
			aToujitsuAssenhinMapper.deleteToujitsuThumonAll(loginUserDto.getTorihikisakiCd());
			aToujitsuHassosakiMapper.deleteByPrimaryKey(loginUserDto.getTorihikisakiCd());
			return juhattyuCd;
		}
		throw new IllegalArgumentException("当日編集更新エラー");
		//return 0;
	}
	

	/**
	 * 当日注文数の更新
	 * @param loginUserDto ログイン情報
	 * @param thumonshaCd 注文者番号
	 * @param nendo 年度
	 * @param juhattyuCd 受発注番号
	 * @param juhattyuMeisaiCd 受発注明細番号
	 * @param thumonSuu 注文数（変更後）
	 * @param version バージョン
	 * @return
	 */
	public int updateToujitsuThumonSuu(LoginUserDto loginUserDto, Integer thumonshaCd, Short nendo, Integer juhattyuCd, Short juhattyuMeisaiCd, Short thumonSuu, Integer version) {
		//価格データの取得
		TokubetsuKakakuSplitDto tDto = juhattyuLogic.getTokubetuKakakuDto(loginUserDto, nendo, juhattyuCd, juhattyuMeisaiCd, thumonshaCd, thumonSuu);
		//更新データセット
		UpdateToujitsuThumonSuuDto uDto = new UpdateToujitsuThumonSuuDto();
		uDto.setTorihikisakiCd(loginUserDto.getTorihikisakiCd());;
		uDto.setNendo(nendo);
		uDto.setJuhattyuCd(juhattyuCd);
		uDto.setJuhattyuMeisaiCd(juhattyuMeisaiCd);
		uDto.setThumonSuu(thumonSuu);
		uDto.setVersion(version);
		if (tDto.isKakakuFound()) {
			uDto.setKakakuCls(tDto.getKakakuCls());
			uDto.setTanka(tDto.getTanka());
		} else {
			//ないはずなのでエラーとする
			throw new IllegalArgumentException("価格取得エラー");
		}
		int upd = aToujitsuAssenhinMapper.updateToujistuThumonSuu(uDto);
		if (upd == 1) {
			return (version + 1);
		} else {
			return 0;
		}

	}
	
	/**
	 * EntityからDtoへの変換（Null想定のため特定のSetterを使う。）
	 * @param work
	 * @return
	 */
	private AddressInfoDto copyAddressDto(AToujitsuHassosaki work) {
		AddressInfoDto aDto = new AddressInfoDto();
		if (work == null) {
			work = new AToujitsuHassosaki(); //Null対策
		}
		copyAddressDto(work, aDto);
		return aDto;
	}
	/**
	 * EntityからDtoへの変換
	 * @param work 変換元
	 * @param aDto 変換先
	 */
	private void copyAddressDto(AToujitsuHassosaki work, AddressInfoDto aDto) {
		aDto.setNyuryokushaCd(work.getNyuryokushaCd());
		aDto.setNyuryokushaName(work.getNyuryokushaName());
		aDto.setTantoBushoName(work.getTantoBusho());
		aDto.setTantoshaName(work.getTantosha());;
		aDto.setThumonshaCd(StringUtility.toString(work.getThumonshaCd()));;
		aDto.setThumonshaName(work.getThumonshaName());
		aDto.setHassosakiCd(StringUtility.toString(work.getHassosakiCd()));
		aDto.setHassosakiName(work.getHassosakiName());
		aDto.setHassosakiBusho(work.getHassosakiBusho());
		aDto.setYubinNum(work.getYubinNum());
		aDto.setAddress(work.getAddress());
		aDto.setTelNum(work.getTelNum());
		aDto.setVersion(work.getVersion());
	}
	private AToujitsuHassosaki copyAddressWork(AddressInfoDto aDto) {
		AToujitsuHassosaki work = new AToujitsuHassosaki();
		work.setNyuryokushaCd(aDto.getNyuryokushaCd());
		work.setNyuryokushaName(aDto.getNyuryokushaName());
		work.setTantoBusho(aDto.getTantoBushoName());
		work.setTantosha(aDto.getTantoshaName());;
		work.setThumonshaCd(StringUtility.toInt(aDto.getThumonshaCd()));;
		work.setThumonshaName(aDto.getThumonshaName());
		work.setHassosakiCd(StringUtility.toInt(aDto.getHassosakiCd()));
		work.setHassosakiName(aDto.getHassosakiName());
		work.setHassosakiBusho(aDto.getHassosakiBusho());
		work.setYubinNum(aDto.getYubinNum());
		work.setAddress(aDto.getAddress());
		work.setTelNum(aDto.getTelNum());
		work.setVersion(aDto.getVersion());		
		return work;
	}
	
	/**
	 * 新規登録用受発注データ作成
	 * @param juhattyuCd
	 * @param juhattyubi
	 * @param work
	 * @param loginUserDto
	 * @return
	 */
	private void createUpdJuhattyuData(
			AJuhattyu juhattyu, LocalDate juhattyubi,
			 AToujitsuHassosaki work, LoginUserDto loginUserDto) {
		juhattyu.setHattyumotoCd(loginUserDto.getTorihikisakiCd());
		juhattyu.setTantoBusho(work.getTantoBusho());
		juhattyu.setTantosha(work.getTantosha());
		juhattyu.setUkeireKyokyuCls(UkeireKyokyuClsEnum.HATTYU.getUkeireCls());
		juhattyu.setJuhattyubi(juhattyubi);;
		juhattyu.setNyuryokushaCd(work.getNyuryokushaCd());
		juhattyu.setKihyoCls(KihyoClsEnum.HATTYU.getKihyoCls());
		juhattyu.setSyukkoFlag(ShukkoFlagEnum.MISHUKKO.getShukkoFlag());
		juhattyu.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
		juhattyu.setSouryou(loginUserDto.getSouryou());
	}
}
