package ja.zenchu.assenhin.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * String関連の共通
 * @author take
 *
 */
public class StringUtility {
	
	/**
	 * Integer→String変換（Null対応）
	 * @param i
	 * @return
	 */
	public static String toString(Integer i) {
		if (i == null) {
			return StringUtils.EMPTY;
		}
		return Integer.toString(i);
	}
	
	/**
	 * String→Integer変換(Null対応）
	 * @param str
	 * @return
	 */
	public static Integer toInt(String str) {
		if (StringUtils.isEmpty(str) ) {
			return null;
		}
		return Integer.parseInt(str);
	}

}
