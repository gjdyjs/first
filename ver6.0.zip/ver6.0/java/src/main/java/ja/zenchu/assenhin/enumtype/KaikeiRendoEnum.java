package ja.zenchu.assenhin.enumtype;

/**
 * 会計連動のフラグ
 * @author take
 *
 */
public enum KaikeiRendoEnum {
	
	/** 連動待 */
	RENDOMACHI(0);
	
	private int rendoFlag;
	
	private KaikeiRendoEnum(int i) {
		this.rendoFlag = i;
	}
	
	public short getRendoFlag() {
		return (short) this.rendoFlag;
	}

}
