package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.time.LocalDate;

import ja.zenchu.assenhin.utils.DateUtility;
import lombok.Getter;
import lombok.Setter;

/**
 * 注文履歴詳細用
 * @author take
 *
 */
@Getter
@Setter
public class HistoryDetailDto implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8696111368335788777L;

	/** 年度 */
	private int nendo;
	/** 注文ID(受発注#) */
	private int juhattyuCd;
	/** 注文日(受発注日)*/
	private LocalDate juhattyubi;

	/** 入力者# */
	private  int nyuryokushaCd;
	/** 入力者名 */
	private String nyuryokushaName;

	/** 担当部署 */
	private String tantoBusho;
	/** 担当者名 */
	private String tantoshaName;
	/** 注文者ID */
	private int thumonshaCd;
	/** 注文者名 */
	private String thumonshaName;
	/** 発送先ID */
	private int hassosakiCd;
	/** 発送先名 */
	private String hassosakiName;
	/** 発送先部署 */
	private String hassosakiBusho;
	/** 郵便番号 */
	private String yubinNum;
	/** 発送先住所 */
	private String address;
	/** 電話番号 */
	private String telNum;
	
	/**
	 * 受発注日表示用
	 * LocalDateをそのまま表示する分けにもいかないのでyyyy/MM/dd形式の文字列を使う。
	 * @return
	 */
	public String getJuhattyubiStr() {
		return DateUtility.getFormatDateSlash(juhattyubi);
	}
}
