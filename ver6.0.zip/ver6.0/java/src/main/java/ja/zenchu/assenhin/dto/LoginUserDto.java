package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class LoginUserDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3199632218580794565L;
	/** ユーザー情報 */
	private String userId;
	/** 取引先# */
	private Integer torihikisakiCd;
	/** システムID */
	private Integer systemId;
	/** パスワード */
	private String password;
	/** 利用区分 */
	private Short riyoCls;
	/** 県番号(使わないかも) */
	private Short kenCd;
	/** 価格設定区分 */
	private short kakakuSetteiCls;
	/** 取引先名 */
	private String torihikisakiName;
	/** 会員区分 */
	private List<Short> kaiinClsList;
	/** 送料 */
	private int souryou;
	/** 処理年度 */
	private Short targetNendo;
	/** CSRFのキー */
	private String csrfKey;

}
