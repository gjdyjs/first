package ja.zenchu.assenhin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.AssenhinDetailDto;
import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.AssenhinDetailService;
import ja.zenchu.assenhin.service.CartService;
import ja.zenchu.assenhin.service.ZaikoService;

/**
 * 斡旋品詳細画面
 *
 */
@RestController
public class AssenhinDetailController {
	@Autowired
	AssenhinDetailService assenhinDetailService;
	@Autowired
	ZaikoService zaikoService;
	@Autowired
	CartService cartService;
	/**
	 * 斡旋品詳細情報を取得
	 *
	 */
  @RequestMapping(value = "/detailList/{key}",method= RequestMethod.GET)
	public List<AssenhinDetailDto> GetAssenhinDetail(@PathVariable("key") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
		LoginUserDto loginUserDto = loginUserDetails.getUserDto();
	    int index = params.indexOf("=");
	    int assenhinCd = Integer.valueOf(params.substring(index+1,params.indexOf("&"))).intValue();
	    index=params.indexOf("=", index+1);
	    short hansuu =  Short.parseShort(params.substring(index+1,params.length()));
  		AssenhinDetailDto assenhinDetailDto = assenhinDetailService.getAssenhinDetail(assenhinCd,hansuu,loginUserDto);
		List<AssenhinDetailDto> rtnList = new ArrayList<>();
		rtnList.add(assenhinDetailDto);
		return rtnList;
	}
	/**
	 * リアルタイム在庫数を取得
	 *
	 */
    @RequestMapping(value = "/getRealStorage/{dataParams}",method= RequestMethod.GET)
	public int GetRealStorage(@PathVariable("dataParams") String params) {
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	short hansuu=Short.parseShort( (String) map.get("hansuu"));
    	int assenhinCd = Integer.valueOf((String) map.get("assenhinCd")).intValue();
    	return zaikoService.getZaikoSuu(assenhinCd, hansuu);
	}
	/**
	 * カートにインサート
	 *
	 */
    @RequestMapping(value = "/insertCart",method= RequestMethod.POST)
	public int InsertCart(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	short hansuu=Short.parseShort( (String) map.get("hansuu"));
    	int assenhinCd = Integer.valueOf((String) map.get("assenhinCd")).intValue();
    	short thumonSuu=Short.parseShort( (String) map.get("thumonSuu"));
    	return assenhinDetailService.insertCart(assenhinCd, hansuu, thumonSuu, loginUserDto);
	}
	/**
	 * カートリストの商品の在庫数を取得
	 *
	 */
    @RequestMapping(value = "/getCartListRealStorage",method= RequestMethod.GET)
	public boolean GetCartListRealStorage(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	short hansuu;
    	int assenhinCd;
    	int thumonSuu;
    	int zaikoSuu;
    	boolean isSaishuCheck = true;
    	boolean result = true;
    	List list = new ArrayList();
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	List<CartListDto> cartList = cartService.getCartList(loginUserDto,isSaishuCheck);
    	for(int i=0;i<cartList.size();i++) {
    		hansuu= Short.parseShort(gson.toJson(cartList.get(i).getHansuu()));
    		assenhinCd = Integer.valueOf(gson.toJson(cartList.get(i).getAssenhinCd())).intValue();
    		thumonSuu = Integer.valueOf(gson.toJson(cartList.get(i).getThumonSuu())).intValue();
    		zaikoSuu = zaikoService.getZaikoSuu(assenhinCd, hansuu);
    		if(zaikoSuu-thumonSuu>=0) {
    			list.add("true");
    		}else {
    			list.add("false");
    		}
    	}
    	for(int i = 0;i<list.size();i++) {
    		if(list.get(i)=="false") {
    			result = false;
    		}
    	}
    	return result;
	}
	/**
	 * 特別価格リストを取得
	 *
	 */
    @RequestMapping(value = "/getTokubetsuKakakuList/{dataParams}",method= RequestMethod.GET)
	public List<TokubetsuKakakuDto> GetTokubetsuKakakuList(@PathVariable("dataParams") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	short hansuu=Short.parseShort( (String) map.get("hansuu"));
    	int assenhinCd = Integer.valueOf((String) map.get("assenhinCd")).intValue();
    	List<TokubetsuKakakuDto> tokubetsuKakakuDto =  assenhinDetailService.getTokubetsuKakakuList(assenhinCd, hansuu,loginUserDto);
    	return tokubetsuKakakuDto;
	}
}
