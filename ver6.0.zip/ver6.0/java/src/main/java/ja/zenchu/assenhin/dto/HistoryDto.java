package ja.zenchu.assenhin.dto;

import java.time.LocalDate;
import java.util.List;

import ja.zenchu.assenhin.utils.DateUtility;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HistoryDto {
	
	/** 注文年度 */
	private short nendo;

	/** 注文ID（受発注#) */
	private int juhattyuCd;
	/** 受発注日 */
	private LocalDate juhattyubi;
	/**
	 * 受発注明細のリスト
	 */
	private List<HistoryListDto> historyList;
	
	/**
	 * 当日注文日表示用（yyyy/MM/dd)
	 * @return
	 */
	public String getJuhattyubiStr() {
		return DateUtility.getFormatDateSlash(juhattyubi);
	}
	

}
