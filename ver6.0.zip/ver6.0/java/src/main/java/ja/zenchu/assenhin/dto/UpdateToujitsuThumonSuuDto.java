package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 当日注文の変更用
 * パラメータが多いので追加
 * @author take
 *
 */
@Getter
@Setter
public class UpdateToujitsuThumonSuuDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6801353152250471156L;

	private Short nendo;
	
	private Integer juhattyuCd;
	
	private Short juhattyuMeisaiCd;
	
	private Integer torihikisakiCd;
	
	private Short thumonSuu;
	
	private Short kakakuCls;
	
	private Integer tanka;
	
	private Integer version;


}
