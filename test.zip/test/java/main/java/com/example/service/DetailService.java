package com.example.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Detail;
import com.example.mapper.DetailMapper;

@Service
public class DetailService {

    @Autowired
    DetailMapper detailMapper;
    public List<Detail> SelectForDetail(String id){
        return detailMapper.SelectForDetail(id);
    }

}