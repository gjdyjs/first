package com.example.mapper; 

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import com.example.entity.IndexLists;

@Repository
@Mapper
public interface IndexListMapper {
    List<IndexLists> SelectForList(String key);
}