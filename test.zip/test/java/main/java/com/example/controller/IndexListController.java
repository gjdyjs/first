package com.example.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.service.IndexlistService;

@RestController

public class IndexListController {
    @Autowired
    private IndexlistService indexlistService;
    @RequestMapping(value = "/list/{key}",method= RequestMethod.GET)
    public String GetList(@PathVariable("key") String key){
    	System.out.println(key);
    	System.out.println(indexlistService.SelectForList(key).toString());
    	return indexlistService.SelectForList(key).toString();
    }

}
