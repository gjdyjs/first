package com.example.controller;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Sub;
import com.example.service.SubService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class SubController {
    @Autowired
    private SubService subService;
    @RequestMapping("/Sub")
    
    
    public String GetSub() throws JsonProcessingException{
    	Map<String, List<String>> map = new HashMap<String, List<String>>();

    	for (Sub sub : subService.SelectForSub()) {
    		ObjectMapper objectMapper = new ObjectMapper();
    		String key = sub.getMaincata();
    		String val = objectMapper.writeValueAsString(sub);
    		if (map.containsKey(key)) {
    			List<String> tmp = map.get(key);
    			tmp.add(val);
    		} else {
    			List<String> tmp = new ArrayList<String>();
    			tmp.add(val);
    			map.put(key, tmp);
    			
    		}
    	}   	
 	System.out.println(map.get("sales"));
    	return subService.SelectForSub().toString();
    }
//    public String GetSub(){
//    	return subService.SelectForSub().toString();
//    }

}
