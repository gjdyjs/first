package com.example.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.service.DetailService;


@RestController

public class DetailController {
    @Autowired
    private DetailService detailService;
    @RequestMapping(value = "/detail/{id}",method= RequestMethod.GET)
    public String GetDetail(@PathVariable("id") String id){
    	
    	System.out.println(id);
    	System.out.println(detailService.SelectForDetail(id).toString());
    	return detailService.SelectForDetail(id).toString();
    }

}
