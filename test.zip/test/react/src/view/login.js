import React, { Component } from 'react';
import { Form, Input, Button } from 'antd';
import axios from 'axios';
// import {Link} from 'react-router-dom';
import '../css/login.css';
export default class Login extends Component{
    constructor(props){
        super(props)
        this.state={
            userName:'',
            password:''
        }
    }
    handleUser=(e)=>{
        this.setState({
          userName:e.target.value
        })
    }
    handlePassword=(e)=>{
      this.setState({
          password:e.target.value
      })
    }
    handleSubmit=()=>{
        axios.get('./login.json')
        .then((response)=>{
          if(response.data.data.userName==this.state.userName&&response.data.data.password==this.state.password){
            this.props.history.push("/home")
          }else{
            alert("ユーザー名またはパスワードが正しくではありません")
          }
        })
        .catch(function(error){
            console.error();
        })

        

    }
    render(){
        return(
          <Form name="normal_login" className="login-form">
            <Form.Item className = "userInput" name="username" rules={[{ required: true, message: 'Please input your Username!' }]}>
              <Input  placeholder="ユーザー名"  onChange = {this.handleUser}/>
            </Form.Item>
            <Form.Item className = "passInput" name="password" rules={[{ required: true, message: 'Please input your Password!' }]}>
              <Input  type="password" placeholder="パスワード" onChange = {this.handlePassword}/>
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" className="login-form-button" onClick = {this.handleSubmit}>
                登録
              </Button>
            </Form.Item>
          </Form>
        )
    }
}
 
