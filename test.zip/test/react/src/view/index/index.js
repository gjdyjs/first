import React, { Component } from 'react';
import { Layout } from 'antd';
import Sub from "./sub";
const {  Content } = Layout;
export default class Index extends Component{
    constructor(props){
        super(props)
        this.state = {
            info:"あいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システムあいうえおかきくけこさしすせそたちつてとまみむめも発注システム"
        }
    }
    render(){
        return(
            <div>
                <Content style={{ padding: '0 50px' }}>
                    <Layout className="site-layout-background" style={{ padding: '24px 0' }}> 
                        <Sub/>
                        <Content style={{ padding: '0 24px', minHeight: 840 }}>
                            <form style={{border:"1px solid",width:"100%",textAlign:"center"}}>
                                <h1>お知らせ</h1>
                                <hr/>
                                {this.state.info}
                            </form>
                            <br/><br/><br/>
                            <form style={{border:"1px solid",width:"100%",textAlign:"center"}}>
                                <h1>システムのお知らせ</h1>
                                <hr/>
                                {this.state.info}
                            </form>                       
                        </Content>
                    </Layout>
                </Content>
                
            </div>
        )
    }
}