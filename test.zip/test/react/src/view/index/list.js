import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import {connect} from "react-redux";
import { Layout,List } from 'antd';
const {  Content } = Layout;
class IndexList extends Component{
    constructor(arg){
        super(arg);
        
        this.state = {
            page: 1,
            sorts:[
                '並び順','商品名','新着順','登録日','価額降順','価額昇順'
            ]            
        };
        this.getData(this.props.id,this.state.page);
       
    } 
    shouldComponentUpdate(nextProps,nextState){
        
        if(this.state.page !== nextState.page){
            this.getData(nextProps.id,nextState.page);
            return false;
        }
        if(this.props.id !== nextProps.id){
            this.state.page = 1;
            this.getData(nextProps.id,1);
            return false;
        }
        return true;
    }
    getData(id,page){
        this.props.dispatch((dispatch)=>{
            dispatch({
                type:"LIST_UPDATA"
            });
            //  axios.get(`https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/list?itemName=${id}&page=${page}&limit=100`)
             axios.get(`/list/${id}`)
                .then((res)=>{
                    dispatch({
                        type:"LIST_UPDATA_SUCC",
                        data: res.data
                    });
                })
                .catch((error)=>{
                    dispatch({
                        type:"LIST_UPDATA_REEOR",
                        data: error
                    });
                })
        });
    }
    handleSorts = (e) =>{
        this.setState({
            jungle:e.target.value
        })
    }
    render(){
        let {data,loading} = this.props;
        return(
             <Content style={{ padding: '0 50px' }}>
                <Layout className="site-layout-background" style={{ padding: '24px 0' }}> 
                            <Content style={{ padding: '0 24px', minHeight: 840 }}>
                                <div className = "list" style = {{textAlign:"center"}}>
                                    <br/>
                                    <Link to = '/'>ホーム</Link>
                                    <span style = {{marginLeft:"50px",marginRight:"50px"}}>検索結果</span>
                                    <select value = {this.state.sort} onChange = {this.handleSorts} style = {{width:"20%"}}>
                                        {
                                                this.state.sorts.map(function(value,key){
                                                return<option key = {key}>{value}</option>
                                            })
                                        }
                                    </select>
                                    <br/>                           
                                    <List 
                                        loading = {loading}
                                        itemLayout="vertical" 
                                        size="large" 
                                        pagination={{onChange: page => {console.log(page);},pageSize: 10}} 
                                        dataSource={data} 
                                        renderItem={item => (
                                                    <List.Item>
                                                        <Link to = {`/detail/${item.id}`}><img width={280} src={item.pic} style = {{float:"left"}}/></Link> 
                                                        <br/><br/><br/>
                                                        <div style = {{textAlign:"left"}}>  
                                                        <Link to = {`/detail/${item.id}`} style = {{fontSize:"30px"}}>{item.itemName}</Link>
                                                            <br/>
                                                            価額：{item.price}円<br/>
                                                            在庫数：{item.storage}<br/>
                                                            担当部署：{item.szk}
                                                        </div>
                                                    </List.Item>
                                                )
                                            }
                                    />
                                    <br/>
                                </div>
                            </Content>
                </Layout>
            </Content>
        )
    }
}
export default connect(state=>(state.list))(IndexList);