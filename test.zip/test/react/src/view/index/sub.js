import React, { Component } from "react";
import axios from "axios";
import {connect} from "react-redux";
import {Link,withRouter} from "react-router-dom";
import { Layout, Menu,  } from 'antd';
// const { SubMenu } = Menu;
const { Sider } = Layout;
class Sub extends Component{
    constructor(arg){
        super(arg)
        this.getData()
    }
    getData(){
        this.props.dispatch((dispatch)=>{
            dispatch({
                type:"SUB_UPDATA"
            });
            axios.get("https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/menu")
                .then((res)=>{
                    dispatch({
                        type:"SUB_UPDATA_SUCC",
                        data: res.data
                    });
                    
                })
                .catch((error)=>{
                    dispatch({
                        type:"SUB_UPDATA_REEOR",
                        data: error
                    });
                })
        });
    }
    render(){
        let {data} = this.props;
        return(           
            <Sider className="site-layout-background"  style = {{borderRight:"1px solid #ddd"}}>
            {
                data.map((value,key)=>{                             
                    return  <div key = {key}>
                                <h4 style = {{textAlign:"center"}}>{value.cata}</h4>
                                <div>
                                    {
                                        value.subCata.map((v,k)=>{
                                            return <div key = {k} >
                                                <Link to ={"/index/"+v.szk}>{v.szk}</Link>
                                                    </div>                                                        
                                        })
                                    }
                                </div>
                            </div> 
                })
            }
            </Sider>                      
        )
    }
}
export default connect(state=>(state.sub))(withRouter(Sub));