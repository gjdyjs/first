import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { Layout,Row,Col,Form, Input, Button} from 'antd';
const {  Content } = Layout;
export default class AddConfirm extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            total:''
        };
    } 
    doSerach=(e)=>{
        this.props.history.push("/");
    }
    doSubmit=(e)=>{
        e.preventDefault();
        // axios({
        //     method: 'post',
        //     url: '',
        //     data: {}
        //   });
        this.props.history.push("/cartConfirm");
    }
    render(){
        let {data,loading} = this.props;
        return(
             <Content style={{ padding: '0 50px' }}>
                <Layout className="site-layout-background" style={{ padding: '24px 0' }}> 
                            <Content style={{ padding: '0 24px', minHeight: 740 }}>
                                <div className = "cartList" style = {{textAlign:"left"}}>
                                    <br/>
                                    <Link to = '/'>ホーム</Link>
                                    <span style = {{marginLeft:"50px",marginRight:"50px"}}>発送先入力</span>
                                    <br/>
                                </div>                    
                                <Row>
                                    <Col span={18}>
                                    <div style = {{width:"800px",height:"250px"}}>
                                        <h1>入力者</h1>
                                        <h3>11111  サンプル注文者</h3>
                                        <div>
                                            担当部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>
                                        <br/>
                                        <div>担当者<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　<input required="required" style = {{borderRadius:"10%"}}/></div>
                                        <h1>注文者 <Button style = {{borderRadius:"10%",backgroundColor:"#0099FF",color:"black"}} onClick={this.doSerach}>検索</Button></h1>
                                        <div>
                                            注文者#<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>
                                        <h1>
                                            発送先 <Button style = {{borderRadius:"10%",backgroundColor:"#0099FF",color:"black"}} onClick={this.doSerach}>検索</Button>
                                            <Button style = {{borderRadius:"10%",backgroundColor:"green",color:"black"}} onClick={this.doSerach}>注文者コピー</Button>
                                            <Button style = {{borderRadius:"10%",backgroundColor:"yellow",color:"black"}} onClick={this.doSerach}>クリア</Button>
                                        </h1>
                                        <div>
                                            発送先#<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>
                                        <br/>
                                        <div>
                                            発送先部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>
                                        <br/>                                          
                                        <div>
                                            郵便番号<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>
                                        <br/>                                          
                                        <div>
                                            住所<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>             
                                        </div>
                                        <br/>                                          
                                        <div>
                                            電話番号<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                                            <input required="required" style = {{borderRadius:"10%"}}/>
                                        </div>                                         
                                    </div>                                  
                                    </Col>
                                    <Col span={6}>
                                    <div style = {{float:"right",position:"absolute",left:"50px",top:"5px"}}>
                                    <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"250px"}}>
                                        <br/>
                                        <h2 style={{textAlign:"left"}}>カート</h2>
                                        <div style={{textAlign:"center"}}> 
                                        <br/>
                                        <h3>小計:{this.state.total} 円</h3>
                                        <br/>
                                        <br/>
                                        <input type = "submit" value = "注文内容確認" onClick = {this.doSubmit} /><br/><br/>
                                        </div>
                                    </form>
                                    </div>
                                    </Col>
                                </Row>                              
                            </Content>
                </Layout>
            </Content>
        )
    }
}
