import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import {connect} from "react-redux";
import { Row,Col} from 'antd';
class Detail extends Component{
    constructor(props){
        super(props)
        this.state = {
            list:[],
            count:'',
            userId:'test',
            id:this.props.match.params.id
        }
        this.getData(this.state.id);   
    }
    getData(id){
        this.props.dispatch((dispatch)=>{
            dispatch({
                type:"DETAIL_UPDATA"
            });
            //  axios.get(`https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/list?id=${id}`)
            axios.get(`/detail/${id}`)
                .then((res)=>{
                    dispatch({
                        type:"DETAIL_UPDATA_SUCC",
                        data: res.data
                    });
                    
                })
                .catch((error)=>{
                    dispatch({
                        type:"DETAIL_UPDATA_REEOR",
                        data: error
                    });
                })
        });
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    doSubmit=(e)=>{
        e.preventDefault();
        //axios.post('http://localhost:8080/addCart',`userId=${this.state.userId}&count=${this.state.count}&id=${this.state.id}`);
        axios.post('https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/cartList',`userId=${this.state.userId}&count=${this.state.count}&id=${this.state.id}&itemName=juzi&pic=http://localhost:3000/img/xiangjiao.jpg&szk=sales1&price=3000&storage=1500&flag=100001`);
        this.props.history.push("/cartList/");
    }
    render(){
        let {data} = this.props;
        return(
               <div>
					<Row>
					<Col span={18}>
								<div style = {{marginLeft:"30px",marginTop:"20px"}}>  
								    <Link to = "/">ホーム</Link>
								    <span style = {{marginLeft:"50px",marginRight:"50px"}}>商品名</span>
								    {
								        data.map((value,key)=>{                                     
								                    return  <div key = {key} style = {{marginTop:"120px",marginLeft:"80px"}}>
								<div style = {{float:"left",height:"700px"}}>                                                                                                                         
								    <img src = {value.pic} style={{height:"300px"}}/>
								    <h2>詳細:</h2><h3>{value.detail}</h3>
								</div>
								<div style = {{position:"absolute",left:"800px"}}>
								    <h1>{value.itemName}</h1>
								    <u><h3>斡旋品＃：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;100001</h3></u>
								    <u><h3>価額：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{value.price}円</h3></u>                                        
								    <u><h3>在庫が&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{value.storage}</h3></u>
								    <u><h3>担当部署：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{value.szk}</h3></u>
								</div>
					            </div>    
					        })
					    }
					</div>
					</Col>
					<Col span={6}>
					<div style = {{float:"right",position:"absolute",left:"50px",top:"150px"}}>
					<form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"250px"}}>
					    <br/>
					    <h2 style={{textAlign:"left"}}>カート</h2>
					    <div style={{textAlign:"center"}}> 
					    <br/>
					    <h3>注文数: <input type = "text" value = {this.state.count} onChange = {this.handleCount} style = {{width:"100px"}}/></h3>
					    <br/>
					    <br/>
					    <input type = "submit" value = "カートに入れる" onClick = {this.doSubmit} /><br/><br/>
					    </div>
					</form>
					</div>
					</Col>
                  </Row>                      
                </div>
        )
    }
}
export default connect(state=>(state.detail))(Detail);