import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import {connect} from "react-redux";
import { Layout,List,Row,Col,Button} from 'antd';
const {  Content } = Layout;
class CartList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:null,
            total:'',
            list:[]
        };
        this.getData();
    }
    shouldComponentUpdate(nextState){
        if(this.state.list===nextState.list){
            return false
        }
        return true
    }
    getData(){
        this.props.dispatch((dispatch)=>{
            dispatch({
                type:"CARTLIST_UPDATA"
            });
            //axios.get("https://5f3b67bbfff8550016ae5344.mockapi.io/api/v1/cartList")
            axios.get("http://localhost:8080/workTable/")
                .then((res)=>{
                    this.state.list = res.data
                    this.allPrice()
                    dispatch({
                        type:"CARTLIST_SUCC",
                        data: res.data
                    });
                    console.log(res.data);
                })
                .catch((error)=>{
                    dispatch({
                        type:"CARTLIST_REEOR",
                        data: error
                    });
                })
        });
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.price)*Number(item.count)
        }
        this.setState({
            total:allPrice
        })
        console.log(this.state.total)
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })

    }
    doChange=(id,count,storage)=>{
    this.setState({
        count:null
    })
    const result = /^\d+$/.test(count)
    console.log(id,count,storage)
            if(count!=null){
                if(result){
                    if(eval(storage)>=eval(count)){
                        axios.put("http://localhost:8080/change",`id=${id}&count=${count}`)
                        .then((res)=>{
                            this.getData()
                            this.forceUpdate()
                        })
                        .catch((error)=>{
                            console.log(error)
                        })
                        
                        
                    }else{
                        alert("在庫エラー")
                    }
                }else{
                    alert("数字で入力してください")
                }
            }else{
                console.log("新たな注文数を入力してください")
            }
    }
    doDelete=(id)=>{
        console.log(id)
        axios.delete("http://localhost:8080/delete",{
            params:{
                id:id
            }
        }).then(res=>{
            this.getData()
            this.forceUpdate()
        })
        
        
    }
    doSubmit=(e)=>{
        e.preventDefault();
        axios({
            method: 'post',
            url: "http://localhost:8080/post",
            data: {
                total:this.state.total,
                data:this.state.list
            }
          }).then(res=>{
              console.log(res)
          });
        this.props.history.push("/addressConfirm/");
    }
    render(){
        let {data,loading} = this.props;
        return(
             <Content style={{ padding: '0 50px' }}>
                <Layout className="site-layout-background" style={{ padding: '24px 0' }}> 
                            <Content style={{ padding: '0 24px', minHeight: 840 }}>
                                <div className = "cartList" style = {{textAlign:"left"}}>
                                    <br/>
                                    <Link to = '/'>ホーム</Link>
                                    <span style = {{marginLeft:"50px",marginRight:"50px"}}>カート内容</span>
                                    <br/>
                                </div>                    
                                <Row>
                                    <Col span={18}>
                                    <hr/>
                                    <div>                          
                                    <List 
                                        loading = {loading}
                                        itemLayout="vertical" 
                                        size="large" 
                                        pagination={{onChange: page => {console.log(page);},pageSize: 10}} 
                                        dataSource={data} 
                                        renderItem={item => (
                                                    <List.Item>
                                                        <img width={280} src={item.pic} style = {{float:"left"}}/>
                                                        <div style = {{textAlign:"left"}}>  
                                                        <h1>{item.itemName}</h1> 
                                                            担当部署：{item.szk}<br/>
                                                            在庫数：{item.storage}<br/>
                                                            価額：{item.price}円<br/>
                                                            <br/>
                                                            <div>
                                                            注文数: <input type = "text" defaultValue = {item.count} onChange = {this.handleCount} style = {{width:"50px"}}/>
                                                            &nbsp;&nbsp;&nbsp;<Button  onClick = {()=>this.doChange(item.id,this.state.count,item.storage)} >変更</Button>  &nbsp;&nbsp;&nbsp;
                                                            <Button  onClick = {()=>this.doDelete(item.id)} >削除</Button> 
                                                            </div> 
                                                        </div>
                                                    </List.Item>
                                                )
                                            }
                                    />
                                    <br/>
                                    </div>
                                    </Col>
                                    <Col span={6}>
                                    <div style = {{float:"right",position:"absolute",left:"50px",top:"5px"}}>
                                    <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"250px"}}>
                                        <br/>
                                        <h2 style={{textAlign:"left"}}>カート</h2>
                                        <div style={{textAlign:"center"}}> 
                                        <br/>
                                        <h3>小計:{this.state.total} 円</h3>
                                        <br/>
                                        <br/>
                                        <input type = "submit" value = "購入手続き" onClick = {this.doSubmit} /><br/><br/>
                                        </div>
                                    </form>
                                    </div>
                                    </Col>
                                </Row>                              


                            </Content>
                </Layout>
            </Content>
        )
    }
}
export default connect(state=>(state.cart))(CartList);