import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { Layout,Row,Col,Form, Input, Button} from 'antd';
const {  Content } = Layout;
export default class CartConfirm extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            total:''
        };
    } 
    doSerach=(e)=>{
        this.props.history.push("/");
    }
    doSubmit=(e)=>{
        e.preventDefault();
        // axios({
        //     method: 'post',
        //     url: '',
        //     data: {}
        //   });
        this.props.history.push("/");
    }
    render(){
        let {data,loading} = this.props;
        return(
             <Content style={{ padding: '0 50px' }}>
sdfdsfsdf
            </Content>
        )
    }
}
