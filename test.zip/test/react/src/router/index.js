import React,{Component} from "react";
import {Switch,Route,Redirect} from "react-router-dom";
import Home from "../view/index/home";
import Index from "../view/index/index";
import Detail from "../view/detail/index";
import CartList from "../view/cartList/index";
import AddConfirm from "../view/addressConfirm/index";
import CartConfirm from "../view/cartConfirm/index";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                {/* <Route path = "/" exact render = {()=>(
                    <Redirect to = "/index"/>
                )}/> */}
                <Route exact path = '/' component = {Index}/>
                <Route path = '/index/:id' component = {Home}/>
                <Route path = '/detail/:id' component = {Detail}/>
                <Route path = '/cartList/' component = {CartList}/>
                <Route path = '/addressConfirm/' component = {AddConfirm}/>
                <Route path = '/cartConfirm/' component = {CartConfirm}/>
            </Switch>

        );
    }
}
export default RouterIndex;