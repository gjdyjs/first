function sub(state = {data:[]},action){
    switch(action.type){
        case "SUB_UPDATA":
            return{
                data:state.data
            }
        case "SUB_UPDATA_SUCC":
            return{
                data:action.data
            }
        case "SUB_UPDATA_REEOR":
            return{
                data:[]
            }
        default:
            return state;
    }
}
export default sub;