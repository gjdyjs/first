function detail(state = {data:[]},action){
    switch(action.type){
        case "DETAIL_UPDATA":
            return{
                data:state.data
            }
        case "DETAIL_UPDATA_SUCC":
            return{
                data:action.data
            }
        case "DETAIL_UPDATA_REEOR":
            return{
                data:[]
            }
        default:
            return state;
    }
}
export default detail;