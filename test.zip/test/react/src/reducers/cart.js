function cart(state = {data:[],loading:true},action){
    switch(action.type){
        case "CARTLIST_UPDATA":
            return{
                loading:true,
                data:state.data
            }
        case "CARTLIST_SUCC":
            return{
                loading:false,
                data:action.data
            }
        case "CARTLIST_REEOR":
            return{
                loading:false,
                data:[]
            }
        default:
            return state;
    }
}
export default cart;