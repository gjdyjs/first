import {combineReducers} from "redux";
import list from "../reducers/list";
import cart from "../reducers/cart";
import detail from "../reducers/detail";
import mainHeader from "../reducers/mainHeader";
import sub from "../reducers/sub";
let reducer = combineReducers({
    list,
    detail,
    cart,
    mainHeader,
    sub
});
export default reducer;