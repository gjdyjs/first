import React, { Component } from 'react';
import {AppBar,CssBaseline,Toolbar,Typography,Link,Badge,Button,Popover} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    toolbar: {
        flexWrap: 'wrap',
      },
    toolbarTitle: {
        flexGrow: 1,
      },
    link: {
        margin: theme.spacing(1, 1.5),
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 600,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 800,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
    typography: {
        padding: theme.spacing(1),
      },
  });
class MainHeader extends Component{
    constructor(props){
      super(props)
      this.state={
        open:false,
        userID:'100001',
        userName:'サンプル農業協同組合'
      }
    }
    handleClick=()=>{
      this.setState({
        open:true
      })
    }
    handleClose=()=>{
      this.setState({
        open:false
      })
    }
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar position="fixed" color="default" elevation={0} className={classes.appBar}>
              <Toolbar className={classes.toolbar} style={{borderBottom:"solid 1px"}}>
                <Typography variant="h6" color="inherit" noWrap className={classes.toolbarTitle}>
                  斡旋品発注システム
                </Typography>
                <nav>
                  <Link variant="button" color="textPrimary" href="/" className={classes.link}>
                    ホーム
                  </Link>
                  <Link variant="button" color="textPrimary" href="#" className={classes.link}>
                    <Badge badgeContent={4} color="secondary">
                    <i class="material-icons">shopping_cart</i>
                    </Badge>
                  </Link>
                  <Link variant="button" color="textPrimary" href="#" className={classes.link}>
                    注文履歴
                  </Link>
                  <Link variant="button" color="textPrimary" href="#" className={classes.link}>
                    マニュアル
                  </Link>
                </nav>
                  <Button variant="button" color="textPrimary"  onClick={this.handleClick} className={classes.link}>
                  <i class="material-icons">person</i>
                  </Button>
                  <Popover open={this.state.open} onClose={this.handleClose}   anchorOrigin={{horizontal:'right'}}>
                      <Typography className={classes.typography}>ユーザーID：{this.state.userID}</Typography>
                      <Typography className={classes.typography}>ユーザー名：{this.state.userName}</Typography>
                      <Button variant="button" color="primary" variant="outlined">
                        ログアウト
                      </Button>
                  </Popover>         
              </Toolbar>
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(MainHeader);

