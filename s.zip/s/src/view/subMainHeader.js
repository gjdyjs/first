import React, { Component } from 'react';
import {AppBar,Button,CssBaseline,TextField,Select,MenuItem,FormControl,InputLabel,FormControlLabel,Checkbox} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 600,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 800,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
  });
class SubMainHeader extends Component{
    constructor(arg){
        super(arg)
        this.state = {
            txt:''
        }
    }
    handleInput = (e) =>{
      this.setState({
          txt:e.target.value
      })
    }
    handleSearch=(e)=>{
        let id = this.state.txt
        if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            this.props.history.push("/list/"+id);
        }
    }  
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar position="fixed" color="default" elevation={0} className={classes.appBar}>
              <div style={{backgroundColor:"white",position:"fixed",top:"65px",width:"100%"}}>
                <FormControl variant="outlined" size = "small" className={classes.formControl}>
                    <InputLabel>ジャンル（部署）</InputLabel>
                    <Select style={{textAlign:"left"}}>
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                    </Select>
                </FormControl>
                <TextField id="outlined-basic" label="商品名" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                    検索
                </Button>
                <FormControlLabel className={classes.checkbox} control={<Checkbox color="primary"/>} label="予約斡旋品を含む"/>
              </div> 
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(withRouter(SubMainHeader));

