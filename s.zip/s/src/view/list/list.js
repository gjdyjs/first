import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from "@material-ui/lab/Pagination";
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box';
const styles = theme => ({
    root: {
        flexGrow: 1,
        display: 'flex',
        backgroundColor:"white",
      },  
    paginator: {
        justifyContent: "center",
        padding: "10px"
      }
});
class IndexList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            list:[],
            page:'1',
            pages:'',
            total:'',
            sorts:[
                '並び順','商品名','新着順','登録日','価額降順','価額昇順'
            ]            
        }; 
        this.getData(this.props.id) 
    }
    shouldComponentUpdate(nextProps){
        if(this.props.id !== nextProps.id){
            this.state.page = 1;
            this.getData(nextProps.id);
            return false;
        }
        return true;
    }
    caculate=()=>{
        let pages=Math.ceil(this.state.list.length / 10)
        this.setState({
            pages:pages
        })
    }
    getData(id){
             axios.get(`/list/${id}`)
                .then((res)=>{
                    this.setState({
                        list:res.data
                    })
                    this.caculate()
                })
                .catch((error)=>{
                    console.log(error)
                })
    }
    handleChangePage = () => {

    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <Grid container spacing={5}>
                    <Grid item lg={6}>
                        <Link to="/">ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;{this.props.id}検索結果
                    </Grid>
                    <Grid item lg={6}>
                        <select value = {this.state.sort} onChange = {this.handleSorts} style = {{width:"80px"}}>
                            {
                                this.state.sorts.map(function(value,key){
                                    return<option key = {key}>{value}</option>
                                })
                            }
                        </select>
                    </Grid>
                    <Grid item lg={12}>
                    <div>
                        <List dense compoent="span">
                            {this.state.list
                            .slice((this.state.page - 1) * 10, this.state.page * 10)
                            .map(value => {
                                return (
                                    <div>
                                    <ListItem key={value.id}>
                                        <Link to={`/detail/${value.id}`}><img src={value.pic}/></Link>
                                        <ListItemText>
                                        <Link to={`/detail/${value.id}`}>{value.itemName}</Link>
                                            <div>価額：{value.price}</div>
                                            <div>在庫数：{value.storage}</div>
                                            <div>担当部署：{value.szk}</div>
                                        </ListItemText>
                                    </ListItem>
                                    <Divider />
                                    </div>
                                );
                            })}
                        </List>
                        <Box component="span">
                        {/* <Paginations total={this.state.pages} onChange={(page)=>this.onChange(page)}/> */}
                            <Pagination
                            count={this.state.pages}
                            // page={this.state.page}
                            onChange={()=>this.handleChangePage()}
                            defaultPage={1}
                            color="primary"
                            size="large"
                            // showFirstButton
                            // showLastButton
                            classes={{ ul: classes.paginator }}
                            />
                        </Box>
                    </div>
                    </Grid> 
                </Grid>
            </div>
        )
    }
}
export default withStyles(styles)(IndexList);