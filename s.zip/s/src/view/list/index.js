import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import Sub from '../sub';
import SubMainHeader from '../subMainHeader';
import IndexList from './list';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class Home extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <SubMainHeader/>
                <Sub/>
                <Container maxWidth="lg" style={{backgroundColor:"white"}}>
                    <Toolbar />
                    <Toolbar />
                    <IndexList id = {id}/>
                </Container>
            </div>
        )
    }
}
export default withStyles(styles)(Home);