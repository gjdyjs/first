import React from "react";
import { List, ListItem, makeStyles, Divider, Box } from "@material-ui/core";
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from "@material-ui/lab/Pagination";

const useStyles = makeStyles(theme => ({
  root: {
    width: "100%",
    backgroundColor: theme.palette.background.paper
  },
  item: {
    padding: theme.spacing(1.2)
  },
  avatar: { marginRight: theme.spacing(5) },
  paginator: {
    justifyContent: "center",
    padding: "10px"
  }
}));

const AllProjects = props => {
  const classes = useStyles();
  const itemsPerPage = 10;
  const [page, setPage] = React.useState(1);
  const [noOfPages] = React.useState(
    Math.ceil(projectsList.length / itemsPerPage)
  );

  const handleChange = (event, value) => {
    setPage(value);
  };

  return (
    <div>
      <List dense compoent="span">
        {projectsList
          .slice((page - 1) * itemsPerPage, page * itemsPerPage)
          .map(projectItem => {
            return (
                <div>
                <ListItem key={value.id}>
                    <Link><img src={value.pic}/></Link>
                    <ListItemText>
                    <Link>{value.itemName}</Link>
                        <div>価額：{value.price}</div>
                        <div>在庫数：{value.storage}</div>
                        <div>担当部署：{value.szk}</div>
                    </ListItemText>
                </ListItem>
                <Divider />
                </div>
            );
          })}
      </List>
      <Divider />
      <Box component="span">
        <Pagination
          count={noOfPages}
          page={page}
          onChange={handleChange}
          defaultPage={1}
          color="primary"
          size="large"
          showFirstButton
          showLastButton
          classes={{ ul: classes.paginator }}
        />
      </Box>
    </div>
  );
};

export default AllProjects;


