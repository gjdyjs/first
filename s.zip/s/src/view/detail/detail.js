import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withRouter } from 'react-router';
import {Button,TextField} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 60,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Detail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            list:[]          
        }; 
        this.getData(this.props.id) 
    }
    getData(id){
             axios.get(`/detail/${id}`)
                .then((res)=>{
                    this.setState({
                        list:res.data
                    })
                })
                .catch((error)=>{
                    console.log(error)
                })
    }
    handleCount=(e)=>{
        this.setState({
            count:e.target.value
        })
    }
    doInsert=(storage)=>{
        let id = this.props.match.params.id
        let count = this.state.count
        const result = /^\d+$/.test(count)
        if(!(count.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            if(result){
                if(eval(storage)>=eval(count)){
                    axios.get("/addCart",{
                        params:{
                            id:id,
                            count:count
                        }
                    })
                    .then((res)=>{
                    
                    })
                    .catch((error)=>{
                        console.log(error)
                    })
                    this.props.history.push("/cartList");
                }else{
                    alert("在庫エラー")
                }
            }else{
                alert("数字を入力してください")
            }
        }else{
            alert("注文数はからです")
        } 
    }
    render(){
        const { classes } = this.props;
        return(
        <div>
            {
                this.state.list.map((value,key)=>{
                return <div key={key}>
                        <div>
                            <Link to="/">ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;{value.itemName}
                        </div>
                        <div>
                            <img src={value.pic} style={{height:"250px",width:"300px",position:"absolute",left:"350px",top:"200px"}}/>
                            <div style={{position:"absolute",left:"750px",top:"250px",fontSize:"20px"}}>
                            {value.itemName}<br/>
                            <u>価額：￥{value.price}</u><br/>
                            <u>在庫数：{value.storage}</u><br/>
                            <u>担当部署：{value.szk}</u><br/>
                            </div>
                        </div>
                        <div style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"300px",position:"absolute",left:"1200px",top:"200px"}}>
                            <br/>
                            <h2 style={{textAlign:"left"}}>カート</h2>
                            <div style={{textAlign:"center"}}> 
                            <br/>
                            <div style={{position:"absolute",left:"80px",top:"100px",fontSize:"20px"}}>
                                注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" defaultValue = {this.state.count} onChange = {this.handleCount}/>
                            </div>
                            <br/>
                            <br/>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {()=>this.doInsert(value.storage)}>
                                カートに入れる
                            </Button>
                            </div>
                        </div>
                        <div style={{position:"absolute",left:"350px",top:"700px",fontSize:"20px"}}>
                            詳細{value.detail}
                        </div>
                    </div>
                })
            }
        </div>
        )
    }
}
export default withStyles(styles)(withRouter(Detail));