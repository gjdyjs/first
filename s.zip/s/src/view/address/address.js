import React, { Component } from 'react';
import {Button,TextField} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import {Link} from "react-router-dom";
import axios from 'axios';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        minWidth: 100,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
  });
class Address extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            count:'',
            total:''
        };
    } 
    doSerach=(e)=>{
        this.props.history.push("/");
    }
    doConfirm=(e)=>{
        e.preventDefault();
        // axios({
        //     method: 'post',
        //     url: '',
        //     data: {}
        //   });
        this.props.history.push("/cartConfirm");
    }
    doJump=()=>{
        this.props.history.push("/cartList");
    }
    render(){
        const { classes } = this.props;
        return(
                <div>
                    <div>
                    <Link to = '/'>ホーム</Link>&nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;発送先入力
                    </div>
                    <div style = {{width:"800px",height:"250px"}}>
                        <h1>入力者</h1>
                        <h3>11111  サンプル注文者</h3>
                        <div>
                            担当部署&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>担当者&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>注文者&nbsp;&nbsp;&nbsp;
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                            検索
                            </Button>
                        </h1>
                        <div>
                            注文者#<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <h1>
                            発送先&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                            検索
                            </Button>&nbsp;
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                            注文者コピー
                            </Button>&nbsp;
                            <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                            クリア
                            </Button>
                        </h1>
                        <div>
                            発送先#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>
                        <div>
                            発送先部署<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            郵便番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>
                        <br/>                                          
                        <div>
                            住所&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>             
                        </div>
                        <br/>                                          
                        <div>
                            電話番号&nbsp;&nbsp;&nbsp;&nbsp;<span style = {{borderRadius:"1%",backgroundColor:"red",color:"white"}}>必須</span>　　
                            <TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                        </div>                                         
                    </div>                                  

                    <div style = {{float:"right",position:"absolute",left:"1500px",top:"200px"}}>
                    <form style = {{borderRadius:"10%",border:"1px solid",width:"300px",height:"300px"}}>
                        <br/>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                        <br/>
                        <h3>小計:{this.state.total} 円</h3>
                        <Button color="primary" variant="outlined" className={classes.button} onClick = {this.doConfirm}>
                            注文内容確認
                        </Button>
                        <br/><br/>
                        <Button color="primary" variant="outlined" className={classes.button} onClick = {this.doJump}>
                            カートに戻る
                        </Button>
                        </div>
                    </form>
                    </div>
                </div>
        )
    }
}
export default withStyles(styles)(withRouter(Address));