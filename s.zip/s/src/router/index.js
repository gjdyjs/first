import React,{Component} from "react";
import {Switch,Route} from "react-router-dom";
import Index from "../view/index";
import Home from "../view/list/index";
import DetailIndex from "../view/detail/index";
import CartIndex from "../view/cartList/index";
import AddressIndex from "../view/address/index";
// import CartConfirm from "../view/cartConfirm/index";
class RouterIndex extends Component{
    render(){
        return(
            <Switch>
                <Route exact path = '/' component = {Index}/>
                <Route path = '/list/:id' component = {Home}/>
                <Route path = '/detail/:id' component = {DetailIndex}/>
                <Route path = '/cartList/' component = {CartIndex}/>
                <Route path = '/address/' component = {AddressIndex}/>
                {/* <Route path = '/cartConfirm/' component = {CartConfirm}/> */}
            </Switch>

        );
    }
}
export default RouterIndex;