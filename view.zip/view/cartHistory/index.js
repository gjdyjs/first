import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class CartHistory extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <Container maxWidth="lg">
                    <Toolbar />
                    <Toolbar />
                    注文履歴画面
                </Container>
            </div>
        )
    }
}
export default withStyles(styles)(CartHistory);