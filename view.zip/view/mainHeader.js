import React, { Component } from 'react';
import {AppBar,CssBaseline,Toolbar,Typography,Badge,Button,Popover,Link} from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import axios from 'axios';
const styles = theme => ({
    appBar: {
        borderBottom: `1px solid ${theme.palette.divider}`,
        zIndex: theme.zIndex.drawer + 1,
      },
    toolbar: {
        flexWrap: 'wrap',
      },
    toolbarTitle: {
        flexGrow: 1,
      },
    link: {
        margin: theme.spacing(1, 1.5),
      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 600,
      },
    textField: {
        margin: theme.spacing(0),
        minWidth: 800,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    checkbox: {
        marginLeft: theme.spacing(1),
      },
    typography: {
        padding: theme.spacing(1),
      },
  });
class MainHeader extends Component{
    constructor(props){
      super(props)
      this.state={
        open:false,
        count:'',
        user_id:'100001',
        userName:'サンプル農業協同組合'
      }
      this.getData(this.state.user_id)
    }
    getData(id){
      axios.get(`/workTableCount/${id}`+Date.parse(new Date()))
         .then((res)=>{
             this.setState({
                count:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    handleClick=()=>{
      this.setState({
        open:true
      })
    }
    handleClose=()=>{
      this.setState({
        open:false
      })
    }
    handleDownload=()=>{
      axios.get("/download")
      .then((res)=>{
      })
      .catch((error)=>{
          console.log(error)
      })
    }
    render(){
        const { classes } = this.props;
        return(
            <React.Fragment>
            <CssBaseline />
            <AppBar position="fixed" color="default" elevation={0} className={classes.appBar} >
              <Toolbar className={classes.toolbar} style={{borderBottom:"solid 1px"}}>
                <Typography variant="h6" color="inherit" noWrap className={classes.toolbarTitle} style={{color:"green"}}>
                  斡旋品発注システム
                </Typography>
                <nav>
                  <Link variant="button" color="textPrimary" href="/" className={classes.link}>
                    ホーム
                  </Link>
                  <Link variant="button" color="textPrimary" href={`/cartList/${this.state.user_id}`} className={classes.link}>
                    <Badge badgeContent={this.state.count} color="secondary">
                    <i className="material-icons">shopping_cart</i>
                    </Badge>
                  </Link>
                  <Link variant="button" color="textPrimary" href={`/cartHistory/${this.state.user_id}`} className={classes.link}>
                    注文履歴
                  </Link>
                  <Link variant="button" color="textPrimary" href="#" onClick={this.handleDownload} className={classes.link}>
                    マニュアル
                  </Link>
                </nav>
                  <Button variant="button" color="textPrimary"  onClick={this.handleClick} className={classes.link}>
                  <i className="material-icons">person</i>
                  </Button>
                  <Popover open={this.state.open} onClose={this.handleClose}   anchorOrigin={{horizontal:'right'}}>
                      <Typography className={classes.typography}>ユーザーID：{this.state.user_id}</Typography>
                      <Typography className={classes.typography}>ユーザー名：{this.state.userName}</Typography>
                      <Button variant="button" color="primary" variant="outlined" style={{left:"90px"}}>
                        ログアウト
                      </Button>
                  </Popover>         
              </Toolbar>
            </AppBar>
            </React.Fragment>
        )
    }
}
export default withStyles(styles)(MainHeader);

