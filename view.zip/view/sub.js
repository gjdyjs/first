import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import axios from 'axios';
import { withRouter } from 'react-router';
const drawerWidth = 240;
const styles = theme => ({
      drawer: {
        width: drawerWidth,
        flexShrink: 0,
      },
      drawerPaper: {
        width: drawerWidth,
      },
      drawerContainer: {
        overflow: 'auto',
      },
});
class Sub extends Component{
    constructor(props){
      super(props)
      this.state={
        list:[]
      }
      this.getData()
    }
    getData(){
      axios.get("/Sub")
         .then((res)=>{
             this.setState({
                list:res.data
             })
         })
         .catch((error)=>{
             console.log(error)
         })
    }
    handleSearch=(jungleCd,jungleName)=>{
        if(!(jungleCd.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
          var data = {id:"",jungleCd:jungleCd,flag:2,jungleName:jungleName}
          data = JSON.stringify(data)
          this.props.history.push(`/list/${data}`);
        }
    }
    render(){
        const {classes} = this.props;
        return(
            
            <Drawer
              className={classes.drawer}
              variant="permanent"
              classes={{
                paper: classes.drawerPaper,
              }}
            >
              <Toolbar />
              <Toolbar />
              <div className={classes.drawerContainer}>
                <List>
                  {
                    this.state.list.map((value,key)=>(
                    <ListItem button key={key} >
                      <ListItemIcon></ListItemIcon>
                      <ListItemText primary={value.category_name} onClick = {()=>this.handleSearch(value.category_cd,value.category_name)}/>
                    </ListItem>
                    ))
                  }
                </List>
                <Divider />
              </div>
            </Drawer>
          
        )
    }
}
export default withStyles(styles)(withRouter(Sub));