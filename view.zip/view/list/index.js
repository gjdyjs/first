import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Toolbar from '@material-ui/core/Toolbar';
import Container from '@material-ui/core/Container';
import Sub from '../sub';
import SubMainHeader from '../subMainHeader';
import IndexList from './list';
const styles = theme => ({
    root: {
        display: 'flex',
        backgroundColor:"white",
      },
});
class Home extends Component{
    render(){
        let data = JSON.parse(this.props.match.params.data);
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                <CssBaseline />
                <SubMainHeader/>
                <Sub/>
                <Container maxWidth="lg">
                    <Toolbar />
                    <Toolbar />
                    <IndexList data = {data}/>
                </Container>
            </div>
        )
    }
}
export default withStyles(styles)(Home);