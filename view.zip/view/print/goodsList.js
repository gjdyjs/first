import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button} from '@material-ui/core';
import { withRouter } from 'react-router';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import {Link} from "react-router-dom";
import axios from 'axios';
const styles = theme => ({
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
});
class GoodsList extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            fee:'500',
            list:[]
        };
        console.log(this.props.data)

    }
    doJump=()=>{
        this.props.history.push("/");
    }
    doPrint=(e)=>{
        e.preventDefault();
        //this.props.history.push("/print");
    }
    render(){
        const {classes} = this.props;
        return(
            
            <div className = "cartList" style = {{textAlign:"left",width:"900px"}}>
                <br/>
                &nbsp;&nbsp;<Link to = '/'>ホーム</Link>
                &nbsp;&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;&nbsp;注文完了
                <br/><br/>
                <div style={{color:"red"}}>※注文が完了しました。</div>
                <br/>
                <Table aria-label="caption table" style={{width:"400px"}}>
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            注文情報
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%"}}>発注＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>2000</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)"}}>発注日</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>2020/06/01</TableCell>
                    </TableRow>
                </Table>
                <Table aria-label="caption table">
                    <TableRow>
                        <TableCell></TableCell>
                        <TableCell></TableCell>
                    </TableRow>
                </Table>
                <div>
                    {
                        this.state.list.map((value,key)=>{
                            return<div key={key}>
                                    <Table aria-label="caption table">
                                    <TableRow>
                                        <TableCell align="left">                                        
                                        <img width={280} src={value.pic} style = {{float:"left",height:"180px"}}/>
                                        <div style = {{textAlign:"left"}}>  
                                            <h1>{value.itemName}</h1>
                                            斡旋品#: <br/>
                                            担当部署：{value.szk}<br/>
                                            価額：￥{Number(value.price).toLocaleString('en-US')}<br/>
                                            <div>注文数:{value.count}</div> 
                                        </div></TableCell>
                                    </TableRow>
                                    </Table>
                                </div>
                        })
                    }
                </div>
                
                <div style = {{position:"absolute",left:"1300px",top:"100px"}}>
                    <form style = {{borderRadius:"10%",border:"1px solid rgba(0,0,0,0.2)",width:"250px",height:"350px"}}>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                            <h3>小計:{Number(this.props.data.total).toLocaleString('en-US')} 円</h3>
                            <h3>送料:{this.state.fee} 円</h3>
                            <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                            <h3>合計:{Number(parseInt(this.props.data.total)+parseInt(this.state.fee)).toLocaleString('en-US')} 円</h3>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doPrint}>
                                印刷
                            </Button>
                            <br/><br/>
                            <Button color="primary" variant="outlined" className={classes.button2} onClick = {this.doJump}>
                                ホームに戻る
                            </Button>
                            </div>
                    </form>
                </div>
            </div>
        )
    }
}
export default withStyles(styles)(withRouter(GoodsList));