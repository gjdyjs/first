import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import Pagination from "material-ui-flat-pagination";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
const styles = theme => ({
  textField: {
      margin: theme.spacing(0),
      minWidth: 500,
    },
  button: {
      margin: theme.spacing(0),
      minWidth: 50,
    },
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
    },
});
class DialogThumonsha extends Component{
    constructor(props){
        super(props)
        this.state = {
            open:false,
            txt:'',
            radioValue:'',
            offset: 0,
            perPage: 5,
            list:[],
            arr:[]
        };
    }
    handleClickOpen=()=>{
        this.setState({
            open:true
        }) 
    }
    handleInput=(e)=>{
      this.setState({
        txt:e.target.value
      })
    }
    handleSearch=()=>{
      let id = this.state.txt
      if(!(id.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
        axios.get(`/assen/searchThumonshaList/${id}`,{
          headers:{"token":sessionStorage.getItem("token")}
      })
        .then((res)=>{
            this.setState({
               list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })        
      }
    }
    handleClickPagination = offset => {
      this.setState({ offset })
    }
    handleClose=()=>{
      this.setState({
        list:[],
        open:false,
        offset:0
      })
    }
    handleRadio=(e)=>{
      this.setState({
          radioValue:e.target.value
      })
    }
    handleCheck=(thumonshaCd)=>{
      if(!(thumonshaCd.replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
        this.handleCommit(thumonshaCd)
      }else{
        alert("注文者を選んでください")
      }
    }
    handleCommit=(thumonshaCd)=>{
      this.state.arr=this.state.list.find(item=>item.thumonshaCd==thumonshaCd)
      this.props.getInfo1(this.state.arr.thumonshaCd,this.state.arr.thumonshaName)
      this.setState({
        open:false,
        list:[],
        radioValue:'',
        offset:0
      })
    }
    render(){
      const { classes } = this.props;
        return(
            <div>
            <Button variant="outlined" color="primary" onClick={this.handleClickOpen}>
              検索
            </Button>
            <Dialog open={this.state.open} onClose={this.handleClose}>
              <DialogContent>
                <TextField id="outlined-basic" label="検索条件（注文者＃または注文者名）" variant="outlined" className={classes.textField} onChange = {this.handleInput}/>
              </DialogContent>
              <DialogActions>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {this.handleSearch}>
                    検索
                </Button>
                <Button color="primary" variant="outlined" className={classes.button} onClick = {()=>this.handleCheck(this.state.radioValue)}>
                    注文者選択
                </Button>
              </DialogActions>
                <table style={{width:"100%"}}>
                    {this.state.list
                    .slice(this.state.offset,this.state.offset+this.state.perPage)
                    .map((value,key) => {
                        return (
                            <div key={key} style={{width:"100%",border:"1px solid rgba(0,0,0,0.05)",height:"50px"}}>
                                <td style={{width:"10%",float:"left",textAlign:"center"}}>
                                  <input type="radio" value={value.thumonshaCd} checked={this.state.radioValue==value.thumonshaCd} onChange={this.handleRadio}/>
                                </td>
                                <td style={{width:"30%",float:"left",textAlign:"center"}}>{value.thumonshaCd}</td>
                                <td style={{width:"40%",textAlign:"center"}}>{value.thumonshaName}</td>
                            </div>
                                );
                            })}
                  </table>
                <Pagination
                currentPageColor='default'
                size='medium'
                style={{textAlign:"center"}}
                limit={this.state.perPage}
                offset={this.state.offset}
                total={this.state.list.length}
                onClick={(e, offset) => this.handleClickPagination(offset)}
                />
            </Dialog>
          </div>
        )
    }
}
export default withStyles(styles)(DialogThumonsha);
