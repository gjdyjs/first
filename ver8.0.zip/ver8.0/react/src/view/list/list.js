import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import ListItem from '@material-ui/core/ListItem';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from "@material-ui/core/ListItemText";
import Pagination from "material-ui-flat-pagination";
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '700px',

      },
    formControl: {
        margin: theme.spacing(0),
        minWidth: 130,
      },
});
class IndexList extends Component{
    constructor(arg){
        super(arg);   
        this.state = {
            list:[],
            offset: 0,
            perPage: 10,
            orderCd:''     
        };
        this.getData(this.props.data) 
    }
    shouldComponentUpdate(nextProps){
        if(this.props.data.searchAssenhinName !== nextProps.data.searchAssenhinName||
            this.props.data.searchCategoryId!==nextProps.data.searchCategoryId||
            this.props.data.searchYoyaku!==nextProps.data.searchYoyaku
            ){
            this.state.offset = 0;
            this.getData(nextProps.data);
            return false;
        }
        return true;
    }
    getData(data){
        axios.get(`/assen/listData/searchAssenhinName=${data.searchAssenhinName}&searchCategoryId=${data.searchCategoryId}&searchYoyaku=${data.searchYoyaku}&orderType=${data.orderType}`,
            {
            headers:{"token":sessionStorage.getItem("token")}
            })
        .then((res)=>{
            this.setState({
                list:res.data
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    handleClickPagination = offset => {
        this.setState({ offset })
    }
    handleSort=(e)=>{
        this.setState({
            orderCd:e.target.value
        })
        axios.get(`/assen/listData/searchAssenhinName=${this.props.data.searchAssenhinName}&searchCategoryId=${this.props.data.searchCategoryId}&searchYoyaku=${this.props.data.searchYoyaku}&orderType=${e.target.value.toFixed()}`,
        {
        headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            this.setState({
                list:res.data,
                offset:0
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    render(){
        const {classes} = this.props;
        return(
            <div className={classes.root}>
                    <div style={{fontSize:"15px",position:"absolute",top:"15%",left:"16%"}}>
                    <Breadcrumbs className={classes.spacegaiyo}>
                    <Link to='/assen/top' style={{ textDecoration: 'none', color: 'blue' }}>ホーム</Link>
                    <Typography>{this.props.data.searchAssenhinName!==""?
                    this.props.data.searchAssenhinName:
                    this.props.data.searchCategoryName}検索結果</Typography>
                    </Breadcrumbs>
                    </div>
                    <div style={{position:"absolute",top:"15%",left:"70%"}}>
                        <FormControl variant="outlined" size = "small" className={classes.formControl}>
                            <InputLabel>並び順</InputLabel>
                            <Select style={{textAlign:"left"}} onChange={this.handleSort} value={this.state.orderCd}>
                                <MenuItem value={10}>登録日昇順</MenuItem>
                                <MenuItem value={20}>登録日降順</MenuItem>
                                <MenuItem value={30}>価額昇順</MenuItem>
                                <MenuItem value={40}>価額降順</MenuItem>
                            </Select>
                        </FormControl>
                    </div>
                    <div style={{position:"absolute",width:"100%",top:"20%",backgroundColor:"white",
                    borderLeft:"1px solid rgba(0,0,0,0.1)",borderRight:"1px solid rgba(0,0,0,0.1)"}}>
                        <List dense compoent="span">
                            {this.state.list
                            .slice(this.state.offset,this.state.offset+this.state.perPage)
                            .map((value,key) => {
                                return (
                                    <div key={key} style={{position:"relative",left:"15%"}}>
                                        <ListItem key={value.assenhinCd} >
                                            <Link to={`/assen/detail/assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}>
                                                <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                                                style={{height:"200px",width:"200px"}}
                                                />
                                            </Link>
                                            <ListItemText>
                                            <Link to={`/assen/detail/assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`} 
                                            style={{ textDecoration:'none',color:'blue'}}>{value.assenhinName}</Link>
                                                <div>斡旋品＃:{value.assenhinCd}</div>
                                                <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')}</div>
                                                <div>在庫数：{value.zaikoSuu}</div>
                                                <div>担当部署：{value.bushoName}</div>
                                            </ListItemText>
                                        </ListItem>
                                        <Divider style={{position:"absolute",left:"15%",width:"70%"}}/>
                                    </div>
                                );
                            })}
                        </List>
                            <Pagination
                            currentPageColor='default'
                            size='large'
                            style={{textAlign:"center"}}
                            limit={this.state.perPage}
                            offset={this.state.offset}
                            total={this.state.list.length}
                            onClick={(e, offset) => this.handleClickPagination(offset)}
                            />
                    </div>
            </div>
        )
    }
}
export default withStyles(styles)(IndexList);