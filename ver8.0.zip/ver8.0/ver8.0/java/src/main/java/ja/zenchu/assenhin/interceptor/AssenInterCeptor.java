package ja.zenchu.assenhin.interceptor;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;

import ja.zenchu.assenhin.config.NonAuth;
import ja.zenchu.assenhin.entity.mapper.MSystemInfoMapper;

/**
 * 斡旋品のアクション単位のインターセプター処理
 * @author take
 *
 */
public class AssenInterCeptor implements HandlerInterceptor{

	@Autowired
	private MSystemInfoMapper mSystemInfoMapper;

	/**
	 * 処理前の共通チェック
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		//静的リソースの場合は認証不要
        if (handler instanceof ResourceHttpRequestHandler) {
              return true;
        }
        //指定のインスタンスの場合以外はスルー
        if (!HandlerMethod.class.isInstance(handler)) {
        	System.out.println("エラーのインスタンスクラス;" + handler.getClass().getName());
        	return true;
        }
		
		HandlerMethod hm = (HandlerMethod) handler;
        Method method = hm.getMethod();
        NonAuth annotation = AnnotationUtils.findAnnotation(method, NonAuth.class);
	    // ログイン画面は除く
        if(annotation != null) {
			return true;
		}
        
        
		// 稼働フラグ
		Integer kadouFlg;

		try {
			kadouFlg = mSystemInfoMapper.getKadouFlag();
			if (kadouFlg == 0) {
				response.sendRedirect(request.getContextPath() + "/system-stop");
				return false;
			}
		} catch (Exception e) {
			response.sendRedirect(request.getContextPath() + "/login-error");
			return false;
		}
		return true;
	}
	
	
}
