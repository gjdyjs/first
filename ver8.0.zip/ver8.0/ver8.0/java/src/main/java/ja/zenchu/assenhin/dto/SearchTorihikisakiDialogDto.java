package ja.zenchu.assenhin.dto;

import java.time.LocalDate;

import lombok.Getter;

/**
 * 取引先ダイアログ検索条件用
 * @author take
 *
 */
@Getter
public class SearchTorihikisakiDialogDto {

	/**
	 * コンストラクタ
	 * @param searchKey 検索用キー
	 * @param kijunbi　基準日（現在日で良い）
	 */
	public SearchTorihikisakiDialogDto(String searchKey, LocalDate kijunbi) {
		
		this.searchTorihikisakiCdKey = searchKey + "%";
		this.searchTorihikisakiNameKey = "%" + searchKey + "%";
		this.kijunbi = kijunbi;
	}
	/** 取引先番号検索用（前方一致)  */
	private String searchTorihikisakiCdKey;
	
	/** 取引先名検索用（部分一致)  */
	private String searchTorihikisakiNameKey;
	/** 基準日 */
	private LocalDate kijunbi;
	
}
