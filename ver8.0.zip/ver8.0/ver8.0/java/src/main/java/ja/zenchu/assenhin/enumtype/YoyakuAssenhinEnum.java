package ja.zenchu.assenhin.enumtype;

/***
 * 予約斡旋品かどうか
 * @author take
 *
 */
public enum YoyakuAssenhinEnum {
	
	/** 予約斡旋品 */
	TUJOU(0),
	/** 通常斡旋品 */
	YOYAKU(1);
	
	private int yoyakuCls;
	
	private YoyakuAssenhinEnum(int i) {
		this.yoyakuCls = i;
	}
	
	public short getYoyakuCls() {
		return (short) this.yoyakuCls;
	}

}
