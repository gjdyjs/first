package ja.zenchu.assenhin.enumtype;

/**
 * 請求書出力フラグ
 * 
 * @author take
 *
 */
public enum SeikyushoOutFlagEnum {

	/** 未出力  */
	MISHUTSURYOKU(0);
	int outFlag;
	
	private SeikyushoOutFlagEnum(int i) {
		this.outFlag = i;
	}
	
	public short getSeikyushoOutFlag() {
		return (short) this.outFlag;
	}
}
