package ja.zenchu.assenhin.enumtype;

/**
 * 本来DB管理だが、システムIDは固定なのでEnumにして定数化する。
 * @author take
 *
 */
public enum SystemTypeEnum {
	/** 会計システム（多分斡旋品では未使用） */
	KAIKEI(1),
	/** 斡旋品システム */
	ASSENHIN(2);
	
	private int systemId;
	private SystemTypeEnum(int i) {
		systemId = i;
	}
	/**
	 * システムID
	 * @return
	 */
	public short getSystemId() {
		return (short) this.systemId;
	}

}
