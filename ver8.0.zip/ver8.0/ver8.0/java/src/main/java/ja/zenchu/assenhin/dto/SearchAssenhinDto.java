package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.util.StringUtils;

import ja.zenchu.assenhin.enumtype.AssenhinSortEnum;
import lombok.Getter;
import lombok.Setter;

/**
 * 斡旋品検索用
 * @author take
 *
 */
@Getter
@Setter
public class SearchAssenhinDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6980495474926999035L;
	
	public SearchAssenhinDto() {
		//並び順はデフォルト登録日昇順
		orderType = AssenhinSortEnum.TOUROKUBI_ASC.getSortNo();
	}

	/** 検索用斡旋品名 */
	private String searchAssenhinName;
	/** 予約区分（予約を含む場合True */
	private boolean yoyakuFlag;
	/** 検索するカテゴリID(全検索の場合はNull） */
	private Short searchCategoryId;
	/** 基準日（基本的に現在日入れとけばいい) */
	private LocalDate kijunbi;
	/** 価格設定区分
	 * LoginUserDtoにセットされているものを使う。
	 */
	private short kakakuSetteiCls;
	
	/** 並び順(一応専用のEnumで管理する予定)  */
	private int orderType;
	
	/**
	 * 検索用斡旋品名の取得
	 * @return
	 */
	public String getSearchAssenhinName() {
		//空文字の場合もNullにする。（SQL側でNullの際は検索条件から外す
		if (StringUtils.isEmpty(searchAssenhinName)) {
			return null;
		}
		return "%" + searchAssenhinName + "%";
	}

	
}
