package ja.zenchu.assenhin.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;

import ja.zenchu.assenhin.interceptor.AssenInterCeptor;

@Configuration
public class BeanConfiguration {

	@Bean
	public HandlerInterceptor assenInterceptor() throws Exception {
		return new AssenInterCeptor();
	}
}
