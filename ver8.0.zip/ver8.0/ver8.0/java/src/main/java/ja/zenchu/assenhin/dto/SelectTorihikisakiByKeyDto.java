package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 取引先#をキーに対象となる取引先の必要な情報を格納するためのDTO
 * @author take
 *
 */
@Getter
@Setter
public class SelectTorihikisakiByKeyDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1667097224317067633L;

	/** 取引先# */
	private Integer torihikisakiCd;
	
	/** 取引先 */
	private String torihikisakiName;
	
	/** 住所 */
	private String address;
	
	/** 郵便番号 */
	private String yubinNum;
	
	/** 電話番号 */
	private String telNum;

}
