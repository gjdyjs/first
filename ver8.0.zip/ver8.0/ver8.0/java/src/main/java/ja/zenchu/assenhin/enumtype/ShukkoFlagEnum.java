package ja.zenchu.assenhin.enumtype;

/**
 * 出庫フラグ
 * @author take
 *
 */
public enum ShukkoFlagEnum {

	/** 未出庫 */
	MISHUKKO(0),
	/** 出庫済 */
	SHUKKOZUMI(1);
	private int shukkoFlag;
	
	private ShukkoFlagEnum(int i) {
		this.shukkoFlag = i;
	}
	/**
	 * 出庫フラグ用
	 * @return
	 */
	public short getShukkoFlag() {
		return (short) this.shukkoFlag;
	}
	/***
	 * 出庫済みかどうか
	 * @param shukkoFlag
	 * @return
	 */
	public static boolean isShukkoZumi(short shukkoFlag) {
		if (shukkoFlag == SHUKKOZUMI.getShukkoFlag()) {
			return true;
		}
		return false;
	}

}
