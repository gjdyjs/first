package ja.zenchu.assenhin.dto;

import java.io.Serializable;
import java.time.LocalDate;

import ja.zenchu.assenhin.utils.DateUtility;
import lombok.Getter;
import lombok.Setter;

/**
 * 検索時の斡旋品リスト用
 * @author take
 *
 */
@Getter
@Setter
public class AssenhinListDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4095939164367126323L;
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	/** 斡旋品名 */
	private String assenhinName;
	/** 在庫数 */
	private int zaikoSuu;
	/**  部署名 */
	private String bushoName;
	/** 価格 */
	private int kakaku;
	/** 登録日 */
	private LocalDate tourokubi;
	
	/**
	 * 登録日表示用
	 * LocalDateをそのまま表示する分けにもいかないのでyyyy/MM/dd形式の文字列を使う。
	 * @return
	 */
	public String getTourokubiStr() {
		return DateUtility.getFormatDateSlash(tourokubi);
	}
}
