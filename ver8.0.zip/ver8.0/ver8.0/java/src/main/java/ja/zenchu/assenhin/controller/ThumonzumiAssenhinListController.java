package ja.zenchu.assenhin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.AddressInfoDto;
import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.JuhattyuDataDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.JuhattyuService;
import ja.zenchu.assenhin.service.ThumonzumiDetailService;
import ja.zenchu.assenhin.service.ZaikoService;

/**
 * 注文履歴修正画面
 * 注文履歴詳細画面
 * 注文履歴修正確認画面
 * 注文履歴修正完了画面
 * 注文完了画面
 */
@RestController
public class ThumonzumiAssenhinListController {
	@Autowired
	ThumonzumiDetailService thumonzumiDetailService;
	@Autowired
	JuhattyuService juhattyuService;
	@Autowired
	ZaikoService zaikoService;
	/**
	 * 注文完了画面
	 * 注文履歴修正完了画面
	 * 斡旋品リストを取得
	 */
	@RequestMapping(value = "/getThumonzumiAssenhinList/{key}",method= RequestMethod.GET)
	public List<CartListDto> getThumonzumiAssenhinList(@PathVariable("key") int juhattyuCd,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
		LoginUserDto loginUserDto = loginUserDetails.getUserDto();
		short nendo = loginUserDto.getTargetNendo();
		return thumonzumiDetailService.getThumonzumiAssenhinList(loginUserDto,nendo,juhattyuCd);
	}
	/**
	 * 注文完了画面
	 * 注文履歴修正完了画面
	 * 発送先情報を取得
	 */
	@RequestMapping(value = "/getThumonzumiHassosaki/{key}",method= RequestMethod.GET)
	public AddressInfoDto getThumonzumiHassosaki(@PathVariable("key") int juhattyuCd,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
		LoginUserDto loginUserDto = loginUserDetails.getUserDto();
		short nendo = loginUserDto.getTargetNendo();
		return thumonzumiDetailService.getThumonzumiHassosaki(loginUserDto,nendo,juhattyuCd);
	}
	/**
	 * 注文履歴詳細画面
	 * 発送先情報を取得
	 */
    @RequestMapping(value = "/getThumonHassosaki/{data}",method= RequestMethod.GET)
    public AddressInfoDto getThumonHassosaki(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	short nendo = loginUserDto.getTargetNendo();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
		return thumonzumiDetailService.getThumonzumiHassosaki(loginUserDto,nendo,juhattyuCd);
    }
	/**
	 * 注文履歴詳細画面
	 * 斡旋品リストを取得
	 */
    @RequestMapping(value = "/getThumonAssenhinList/{data}",method= RequestMethod.GET)
    public List<CartListDto> getThumonAssenhinList(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	short nendo = loginUserDto.getTargetNendo();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
		return thumonzumiDetailService.getThumonzumiAssenhinList(loginUserDto,nendo,juhattyuCd);
    }
    
	/**
	 * 注文履歴修正画面
	 * 斡旋品リストを取得
	 */
    @RequestMapping(value = "/getToujitsuHenshuAssenhinList/{data}",method= RequestMethod.GET)
    public List<CartListDto> getToujitsuHenshuAssenhinList(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	short nendo = loginUserDto.getTargetNendo();
    	Map<String, Object> map = new HashMap<String, Object>();
    	params = params.substring(0, params.indexOf("}")+1);
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	thumonzumiDetailService.copyToujitsuThumonWork(loginUserDto, nendo, juhattyuCd);
		return thumonzumiDetailService.getToujitsuHenshuAssenhinList(loginUserDto);
    }
	/**
	 * 注文履歴修正画面
	 * 発送先情報を取得
	 */
    @RequestMapping(value = "/getToujitsuHenshuHassosaki/{data}",method= RequestMethod.GET)
    public AddressInfoDto getToujitsuHenshuHassosaki(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	short nendo = loginUserDto.getTargetNendo();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	thumonzumiDetailService.copyToujitsuHassosakiWork(loginUserDto, nendo, juhattyuCd);
		return thumonzumiDetailService.getToujitsuHenshuHassosaki(loginUserDto);
    }
	/**
	 * 注文履歴修正画面
	 * 当日注文数の更新
	 */
    @RequestMapping(value = "/updateToujitsuThumonSuu",method= RequestMethod.POST)
    public int updateToujitsuThumonSuu(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	short nendo=Short.parseShort( (String) map.get("nendo"));
    	short  juhattyuMeisaiCd = Short.parseShort( (String) map.get("juhattyuMeisaiCd"));
    	int thumonshaCd = Integer.valueOf((String) map.get("thumonshaCd")).intValue();
    	short  thumonSuu = Short.parseShort( (String) map.get("thumonSuu"));
    	int version = Integer.valueOf((String) map.get("version")).intValue();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	return thumonzumiDetailService.updateToujitsuThumonSuu(loginUserDto,thumonshaCd,nendo,juhattyuCd,juhattyuMeisaiCd,thumonSuu, version);
    }
	/**
	 * 注文履歴修正画面
	 * 注文データの削除
	 */
    @RequestMapping(value = "/deleteToujitsuThumon",method= RequestMethod.POST)
    public int deleteToujitsuThumon(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	short nendo=Short.parseShort( (String) map.get("nendo"));
    	short  juhattyuMeisaiCd = Short.parseShort( (String) map.get("juhattyuMeisaiCd"));
    	int version = Integer.valueOf((String) map.get("version")).intValue();
    	int result = thumonzumiDetailService.deleteToujitsuThumon(loginUserDto,nendo,juhattyuCd,juhattyuMeisaiCd,version);
		return result;
    }
	/**
	 * 注文履歴修正画面
	 * 注文履歴詳細画面
	 * 受発注バージョンと送料取得
	 */
    @RequestMapping(value = "/getJuhattyuVersion",method= RequestMethod.GET)
    public JuhattyuDataDto getJuhattyuVersion(@RequestParam short  nendo,@RequestParam int juhattyuCd){
		return juhattyuService.getJuhattyuVersion(nendo,juhattyuCd);
    }
	/**
	 * 注文履歴修正画面
	 * 発注取消
	 */
    @RequestMapping(value = "/cancelCartListHistory",method= RequestMethod.POST)
    public void cancelCartListHistory(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	int version = Integer.valueOf((String) map.get("version")).intValue();
		juhattyuService.deleteAllJuhattyuData(juhattyuCd,version,loginUserDto);
    }
	/**
	 * 注文履歴修正画面
	 * 修正
	 */
    @RequestMapping(value = "/updateToujitsuHassosaki",method= RequestMethod.POST)
    public int updateToujitsuHassosaki(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	AddressInfoDto addressInfoDto = new AddressInfoDto();
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	addressInfoDto.setNyuryokushaCd(Integer.valueOf((String) map.get("nyuryokushaCd")).intValue());
    	addressInfoDto.setNyuryokushaName((String)map.get("nyuryokushaName"));
    	addressInfoDto.setTantoBushoName((String)map.get("tantoBushoName"));
    	addressInfoDto.setTantoshaName((String)map.get("tantoshaName"));
    	if(!map.get("thumonshaCd").toString().isEmpty()) {
    		addressInfoDto.setThumonshaCd((String) map.get("thumonshaCd"));
    	}else {
    		addressInfoDto.setThumonshaCd(null);
    	}
    	if(!map.get("hassosakiCd").toString().isEmpty()) {
    		addressInfoDto.setHassosakiCd((String) map.get("hassosakiCd"));
    	}else {
    		addressInfoDto.setHassosakiCd(null);
    	}
    	addressInfoDto.setThumonshaName((String)map.get("thumonshaName"));
    	addressInfoDto.setHassosakiName((String)map.get("hassosakiName"));
    	addressInfoDto.setHassosakiBusho((String)map.get("hassosakiBusho"));
    	addressInfoDto.setYubinNum((String)map.get("yubinNum"));
    	addressInfoDto.setAddress((String)map.get("address"));
    	addressInfoDto.setTelNum((String)map.get("telNum"));
    	addressInfoDto.setVersion(Integer.valueOf((String) map.get("version")).intValue());
    	return thumonzumiDetailService.updateToujitsuHassosaki(loginUserDto,addressInfoDto);
    }
	/**
	 * 注文履歴修正確認画面
	 * 注文履歴修正確認画面から注文履歴修正画面
	 * 斡旋品リストを取得
	 */
    @RequestMapping(value = "/getToujitsuHenshuAssenhinListUpdate/{data}",method= RequestMethod.GET)
    public List<CartListDto> getToujitsuHenshuAssenhinListUpdate(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
		return thumonzumiDetailService.getToujitsuHenshuAssenhinList(loginUserDto);
    }
	/**
	 * 注文履歴修正確認画面
	 * 注文履歴修正確認画面から注文履歴修正画面
	 * 発送先情報を取得
	 */
    @RequestMapping(value = "/getToujitsuHenshuHassosakiUpdate/{data}",method= RequestMethod.GET)
    public AddressInfoDto getToujitsuHenshuHassosakiUpdate(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
		return thumonzumiDetailService.getToujitsuHenshuHassosaki(loginUserDto);
    }
	/**
	 * カートリストの商品の在庫数を取得
	 *
	 */
    @RequestMapping(value = "/getThumonzumiCartListStorage",method= RequestMethod.GET)
	public boolean GetThumonzumiCartListStorage(@AuthenticationPrincipal  LoginUserDetails loginUserDetails) {
    	short hansuu;
    	int assenhinCd;
    	int thumonSuu;
    	int zaikoSuu;
    	boolean isSaishuCheck = true;
    	boolean result = true;
    	List list = new ArrayList();
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	List<CartListDto> cartList = thumonzumiDetailService.getToujitsuHenshuAssenhinList(loginUserDto);
    	for(int i=0;i<cartList.size();i++) {
    		hansuu= Short.parseShort(gson.toJson(cartList.get(i).getHansuu()));
    		assenhinCd = Integer.valueOf(gson.toJson(cartList.get(i).getAssenhinCd())).intValue();
    		thumonSuu = Integer.valueOf(gson.toJson(cartList.get(i).getThumonSuu())).intValue();
    		zaikoSuu = zaikoService.getZaikoSuu(assenhinCd, hansuu);
    		if(zaikoSuu-thumonSuu>=0) {
    			list.add("true");
    		}else {
    			list.add("false");
    		}
    	}
    	for(int i = 0;i<list.size();i++) {
    		if(list.get(i)=="false") {
    			result = false;
    		}
    	}
    	return result;
	}
	/**
	 * 注文履歴修正確認画面
	 * 最終的な注文の確定
	 */
    @RequestMapping(value = "/updateJuhattyuData",method= RequestMethod.POST)
    public int UpdateJuhattyuData(@RequestBody String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    	short nendo=Short.parseShort( (String) map.get("nendo"));
    	int version = Integer.valueOf((String) map.get("version")).intValue();
		return thumonzumiDetailService.updateJuhattyuData(loginUserDto, nendo, juhattyuCd,version);
    }
}
