package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 注文者のDto
 * @author take
 *
 */
@Getter
@Setter
public class ThumonshaListDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1572071467608307996L;

	/** 注文者ID */
	private Integer thumonshaCd;
	/** 注文者名 */
	private String thumonshaName;
}
