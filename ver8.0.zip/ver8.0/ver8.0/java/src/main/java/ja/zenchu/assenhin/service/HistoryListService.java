package ja.zenchu.assenhin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.HistoryDto;
import ja.zenchu.assenhin.dto.HistoryListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMapper;
import ja.zenchu.assenhin.entity.mapper.AJuhattyuMeisaiMapper;

/**
 * 注文履歴一覧情報の取得用
 * @author take
 *
 */
@Service
public class HistoryListService {

	@Autowired
	AJuhattyuMeisaiMapper aJuhattyuMeisaiMapper;
	
	@Autowired
	AJuhattyuMapper aJuhattyuMapper;
	/**
	 * 年度と取引先から該当ユーザーの注文履歴リストを取得
	 * 
	 * @param nendo　選択された年度
	 * @param loginUserDto ログインユーザー情報
	 * @return
	 */
	public List<HistoryDto> searchHistoryList(short nendo, LoginUserDto loginUserDto) {
		//TODO 全件のリストだが受発注番号単位で複数の明細がありうるので単純なリストで良いかは確認する必要あり
		List<HistoryListDto> rtnList = aJuhattyuMeisaiMapper.searchHistoyList(nendo, loginUserDto.getTorihikisakiCd(), null);
		return replaceHistoryList(rtnList);
	}
	
	
	/**
	 * 発注番号が指定された場合
	 * 年度と取引先と受発注番号から該当ユーザーの注文履歴リストを取得
	 * @param nendo　選択された年度
	 * @param loginUserDto ログインユーザー情報
	 * @param juhattyuCd
	 * @return
	 */
	public List<HistoryDto> searchHistoryList(short nendo, LoginUserDto loginUserDto, Integer juhattyuCd) {
		List<HistoryListDto> rtnList = aJuhattyuMeisaiMapper.searchHistoyList(nendo, loginUserDto.getTorihikisakiCd(), juhattyuCd);
		return replaceHistoryList(rtnList);
	}
	
	private List<HistoryDto> replaceHistoryList(List<HistoryListDto> rtnList) {
		//比較用
		short nendo = 0;
		int juhattyuCd = 0;
		List<HistoryDto> rtnDto = new ArrayList<>();
		HistoryDto hisDto = null;
		ArrayList<HistoryListDto> sublist = null;
		boolean bFirst = false;
		for (HistoryListDto rDto : rtnList) {
			if (rDto.getNendo() != nendo || rDto.getJuhattyuCd() != juhattyuCd) {
				if (bFirst) {
					hisDto.setHistoryList(sublist);
					rtnDto.add(hisDto);
				} else {
					bFirst = true;
				}
				//受発注番号単位にリスト作成。
				hisDto = new HistoryDto();
				hisDto.setNendo(rDto.getNendo());
				hisDto.setJuhattyuCd(rDto.getJuhattyuCd());
				hisDto.setJuhattyubi(rDto.getJuhattyubi());
				sublist = new ArrayList<>();
				nendo = rDto.getNendo();
				juhattyuCd = rDto.getJuhattyuCd();
			}
			//取得したリストを受発注番号リストに紐づけ
			sublist.add(rDto);
		}
		if (sublist != null && sublist.size() > 0) {
			hisDto.setHistoryList(sublist);
			rtnDto.add(hisDto);
		}
		return rtnDto;
	}
	
	/**
	 * ログインユーザーが注文を行った年度のリストを取得する。
	 * @param loginUserDto ログインユーザー情報
	 * @return
	 */
	public List<Short> getNendoList(LoginUserDto loginUserDto) {
		//現在年度の取得に変更
		List<Short> nendoList = new ArrayList<>();
		nendoList.add(loginUserDto.getTargetNendo());
		return nendoList;
	}

}
