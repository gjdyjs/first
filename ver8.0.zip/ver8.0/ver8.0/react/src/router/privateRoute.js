import React, {Component} from 'react';
import { Route, Redirect } from 'react-router-dom';
import cookie from 'react-cookies';
class PrivateRoute extends Component {
    render() {
        let { component: Component, ...rest} = this.props;
        return  cookie.load('token') ? 
        (<Route {...rest} render={(props) => ( <Component {...props} /> 
            )}/> ) :<Redirect to={{
                pathname:"/assen/login"
            }}/>
    }
}
export default PrivateRoute




















