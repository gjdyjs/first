import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Button,TextField,Chip} from '@material-ui/core';
import { withRouter } from 'react-router';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import DialogThumonsha from '../address/dialogThumonsha';
import DialogHassosaki from '../address/dialogHassosaki';
import CancelComfirm from './cancelComfirm';
import '../alert';
import axios from 'axios';
import qs from 'qs';
const styles = theme => ({
    textField: {
        margin: theme.spacing(0),
        maxWidth: 80,
      },
    chip: {
        marginLeft: theme.spacing(1),
        marginTop: theme.spacing(0),
        marginRight: theme.spacing(0),
        padding : theme.spacing(0),
        fontSize : 12
    },
    button2: {
        margin: theme.spacing(0),
        minWidth: 150,
      },
    button: {
        margin: theme.spacing(0.5),
        minWidth: 50,
      },
  });
class ThumonDetail extends Component{
    constructor(arg){
        super(arg);
        this.state = {
            jyuhatyuVersion:'',
            souryou:'',
            list:[],
            total:'',
            juhattyubi:'',
            nyuryokushaCd:'',
            nyuryokushaName:'',
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            addInfoVersion:'',
            addInfo:[],
            userList:[],
            arr:[]
        };
        if(this.props.data.times.indexOf(0)===0){
            this.getListData(this.props.data)
            this.getAddData(this.props.data)
        }else{
            this.getListDataUpdate(this.props.data)
            this.getAddDataUpdate(this.props.data)
        }

    }
    getAddDataUpdate(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuHassosakiUpdate/${dataParams}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    addInfoVersion:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getAddData(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuHassosaki/${dataParams}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    addInfoVersion:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getInfo1(thumonshaCd,thumonshaName){
        this.setState({
            thumonshaCd:thumonshaCd,
            thumonshaName:thumonshaName
        })
    }
    getInfo2(hassosakiCd,hassosakiName,address,hassosakiBusho,yubinNum,telNum){
        this.setState({
            hassosakiCd:hassosakiCd,
            hassosakiName:hassosakiName,
            hassosakiBusho:hassosakiBusho,
            address:address,
            yubinNum:yubinNum,
            telNum:telNum
        })
    }
    handleClear=(e)=>{
        this.setState({
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
          })
    }
    handleInput=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
        if(e.target.name==="thumonshaCd"){
            if(e.target.value.length>=4){
                this.autoSetUser(e.target.value)
            }
        }
        if(e.target.name==="hassosakiCd"){
            if(e.target.value.length>=4){
                this.autoSetAddress(e.target.value)
            }
        }
    }
    autoSetUser=(thumonshaCd)=>{
            axios.get(`/assen/searchThumonshaList/${thumonshaCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setUserOnly(thumonshaCd)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    autoSetAddress=(hassosakiCd)=>{
            axios.get(`/assen/selectHassosaki/${hassosakiCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                this.setState({
                    addInfo:res.data
                })
                this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    setUserOnly=(thumonshaCd)=>{
        this.state.arr=this.state.userList.find(item=>item.thumonshaCd==thumonshaCd)
        this.setState({
            thumonshaName:this.state.arr.thumonshaName,
            userList:[],
            arr:[]
        })
    }
    setAdressOnly=(addInfo)=>{
        this.setState({
            hassosakiName:addInfo[0].hassosakiName,
            hassosakiCd:addInfo[0].hassosakiCd,
            address:addInfo[0].address,
            hassosakiBusho:addInfo[0].hassosakiBusho,
            yubinNum:addInfo[0].yubinNum,
            telNum:addInfo[0].telNum,
            addInfo:[],
            arr:[]
        })
    }
    handleCopy=(e)=>{
        if(!(this.state.thumonshaCd.toString().replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            axios.get(`/assen/selectHassosaki/${this.state.thumonshaCd}`,
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
              this.setState({
                addInfo:res.data
              })
              this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
        }
    }
    getListDataUpdate(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuAssenhinListUpdate/${dataParams}`+Date.parse(new Date()),
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
               this.getJuhattyuVersion(res.data[0].nendo,res.data[0].juhattyuCd)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getListData(data){
        var dataParams = JSON.stringify(data)
        axios.get(`/assen/getToujitsuHenshuAssenhinList/${dataParams}`+Date.parse(new Date()),
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
           .then((res)=>{
               this.setState({
                   list:res.data,
                   juhattyubi:res.data[0].juhattyubiStr
               })
               this.allPrice()
               this.getJuhattyuVersion(res.data[0].nendo,res.data[0].juhattyuCd)
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    getJuhattyuVersion=(nendo,juhattyuCd)=>{
        axios.get("/assen/getJuhattyuVersion",{
            params:{
                nendo:nendo,
                juhattyuCd:juhattyuCd
            },
            headers:{"token":sessionStorage.getItem("token")}
        })
        .then((res)=>{
            this.setState({
                souryou:res.data.souryou,
                jyuhatyuVersion:res.data.version
            })
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    handleCount=(e)=>{
        this.state.list.find(item=>item.assenhinCd==e.target.name).thumonSuu=e.target.value
        this.setState({
            list:this.state.list
        })
    }
    getRealStorage=(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)=>{
        let data = {
            assenhinCd:assenhinCd.toString(),
            hansuu:hansuu.toString()
        }
        let dataParams = JSON.stringify(data)
        axios.get(`/assen/getRealStorage/${dataParams}`,
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        )
        .then((res)=>{
            if((res.data-thumonSuu)>=0){
                axios.post("/assen/updateToujitsuThumonSuu",
                    {
                        thumonshaCd:this.state.thumonshaCd.toString(),
                        version:version.toString(),
                        nendo:nendo.toString(),
                        juhattyuCd:juhattyuCd.toString(),
                        thumonSuu:thumonSuu.toString(),
                        juhattyuMeisaiCd:juhattyuMeisaiCd.toString()
                    },
                    {
                        headers:{"token":sessionStorage.getItem("token")}
                    }
                ).then(res=>{
                    res.data!==0?this.getListDataUpdate(this.props.data):alert("変更が失敗しました")
                })               
            }else{
                alert("在庫エラー")
            }
        })
        .catch((error)=>{
            console.log(error)
        })
    }
    doChange=(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)=>{
    const result1 = /^\d+$/.test(thumonSuu)
    const result2 = /^([1-9]\d*|0)$/.test(thumonSuu)
            if(thumonSuu.length!==0){
                if(result1){
                    if(thumonSuu>0){
                        if(result2){
                            this.getRealStorage(assenhinCd,hansuu,nendo,juhattyuCd,thumonSuu,juhattyuMeisaiCd,version)
                        }else{
                            alert("頭数字を0以外で入力してください")
                        }
                    }else{
                        alert("最小値は1です")
                    }
                }else{
                    alert("数字または整数を入力してください")
                }
            }else{
                alert("注文数を入力してください")
            }
    }
    doDelete=(nendo,juhattyuCd,juhattyuMeisaiCd,version)=>{
        this.state.list.length===1?alert("削除が失敗しました。"):
        axios.post("/assen/deleteToujitsuThumon",
            {
                nendo:nendo.toString(),
                version:version.toString(),
                juhattyuCd:juhattyuCd.toString(),
                juhattyuMeisaiCd:juhattyuMeisaiCd.toString()
            },
            {
                headers:{"token":sessionStorage.getItem("token")}
            }
        ).then(res=>{
            res.data===1?this.getListDataUpdate(this.props.data):alert("削除が失敗しました")
        })
    }
    doUpdate=(e)=>{
        e.preventDefault();
        if(!(this.state.thumonshaName===''||this.state.yubinNum===''||this.state.address===''||
        this.state.telNum===''||this.state.hassosakiName===''||this.state.hassosakiBusho==='')){
            axios.post("/assen/updateToujitsuHassosaki",
                {
                    nyuryokushaCd:this.state.nyuryokushaCd.toString(),
                    nyuryokushaName:this.state.nyuryokushaName.toString(),
                    tantoBushoName:this.state.tantoBushoName.toString(),
                    tantoshaName:this.state.tantoshaName.toString(),
                    thumonshaCd:this.state.thumonshaCd.toString(),
                    thumonshaName:this.state.thumonshaName.toString(),
                    hassosakiCd:this.state.hassosakiCd.toString(),
                    hassosakiName:this.state.hassosakiName.toString(),
                    hassosakiBusho:this.state.hassosakiBusho.toString(),
                    yubinNum:this.state.yubinNum.toString(),
                    address:this.state.address.toString(),
                    telNum:this.state.telNum.toString(),
                    version:this.state.addInfoVersion.toString()
                },
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                if(res.data-this.state.addInfoVersion>0){
                    var data = {juhattyuCd:this.props.data.juhattyuCd,nendo:this.props.data.nendo,torihisakiCd:this.props.data.torihisakiCd}
                    data = qs.stringify(data)
                    var encode = window.btoa(data)
                    this.props.history.push(`/assen/confirmUpdateHistory/${encode}`)
                }else{
                    alert("発送先情報更新が失敗しました") 
                }
            })
            .catch((error)=>{
                console.log(error)
            })
        }else(
            alert("必須項目を入力してください")
        )
    }
    doPrint(){
        var newStr = document.getElementById("print").innerHTML;
        var win = window.open("","newWindow","height=800,width=700,top=100");
        win.document.body.innerHTML = newStr;
        win.print();
    }
    render(){
        const {classes} = this.props;
        return(
            <div className = "cartList" style = {{position:"absolute",width:"100%",height:"100%",top:"15%"}}>
                <Table aria-label="caption table" style={{width:"400px"}}>
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap style={{color:"red"}}>
                            注文情報
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>発注＃</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.props.data.juhattyuCd}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>発注日</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.juhattyubi}</TableCell>
                    </TableRow>
                </Table>
                <br/>
                <div style={{border:"solid 0.5px rgba(0,0,0,0.1)",width:"60%"}}/>
                <div>
                {
                    this.state.list.map((value,key)=>{
                        return<div key={key} style={{backgroundColor:"white"}}>
                        <div style={{backgroundColor:"white",borderBottom:"solid 1px rgba(0,0,0,0.1)",width:"60%"}}>
                        <img src={`/assen/getIcon?assenhinCd=${value.assenhinCd}&hansuu=${value.hansuu}`}
                        style={{float:"left",height:"200px",width:"200px"}}/>
                        <br/>
                        <div style = {{textAlign:"left"}}>  
                        <h3 style={{width:"65%"}}>{value.assenhinName}</h3> 
                        <div>斡旋品＃:{value.assenhinCd}</div>
                        担当部署:{value.bushoName}<br/>
                        在庫数:{value.zaikoSuu}<br/>
                            {
                            value.kaiinTekiyou?
                            <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} <span style={{color:"red"}}>※会員価額適用</span></div>:
                            <div>価額：￥{Number(value.kakaku).toLocaleString('en-US')} </div>
                            }
                        <br/>
                        <div>
                        注文数:<TextField id="outlined-basic" variant="outlined" className={classes.textField} size = "small" 
                            name={value.assenhinCd} value = {this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu} 
                            onChange = {this.handleCount}/>
                            <Button color="primary" variant="outlined" className={classes.button} 
                            onClick = {()=>this.doChange(value.assenhinCd,value.hansuu,value.nendo,value.juhattyuCd,
                            this.state.list.find(item=>item.assenhinCd==value.assenhinCd).thumonSuu,value.juhattyuMeisaiCd,value.version)}>
                                変更
                            </Button>
                            <Button color="primary" variant="outlined" className={classes.button} 
                            onClick = {()=>this.doDelete(value.nendo,value.juhattyuCd,value.juhattyuMeisaiCd,value.version)}>
                                削除
                            </Button>
                        </div>
                        <br/>
                        </div>
                        </div>
                        </div>
                    })
                }
                <div style = {{position:"absolute",width:"100%",height:"100%",backgroundColor:"white"}}>
                    <div style = {{position:"absolute",width:"35%"}}>
                    <Table aria-label="caption table">
                        <TableCell>
                        <Typography variant="h6" color="inherit" noWrap>
                            入力者
                        </Typography>
                        </TableCell>
                        <TableCell></TableCell>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",width:"30%",backgroundColor:"#E0FFFF"}}>担当部署</TableCell>
                    <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoBushoName}</TableCell>
                    </TableRow>
                    <TableRow style={{border:"solid 1px rgba(0,0,0,0.3)"}}>
                        <TableCell style={{border:"solid 1px rgba(0,0,0,0.1)",backgroundColor:"#E0FFFF"}}>担当者</TableCell>
                        <TableCell align="left" style={{border:"solid 1px rgba(0,0,0,0.1)"}}>{this.state.tantoshaName}</TableCell>
                    </TableRow>
                    </Table>
                    </div>
                    <br/>
                    <div style = {{position:"absolute",width:"100%",top:"-100px"}}>
                        <div style = {{position:"absolute",top:"300px",fontSize:"25px"}}>注文者</div>
                            <div style={{position:"absolute",top:"300px",left:"100px"}}>
                            <DialogThumonsha getInfo1={(thumonshaCd,thumonshaName)=>this.getInfo1(thumonshaCd,thumonshaName)}/> 
                            </div>
                            <div style={{position:"absolute",width:"600px",height:"50px",top:"350px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                注文者#<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" variant="outlined" name="thumonshaCd" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"150px"}}
                                value={this.state.thumonshaCd} className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                                <TextField id="outlined-basic" variant="outlined" name="thumonshaName"
                                style = {{position:"absolute",top:"5px",left:"360px",width:"200px"}}
                                value={this.state.thumonshaName} className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                            </div>
                            <div style = {{position:"absolute",top:"420px",fontSize:"25px"}}>発送先</div>
                            <div style={{position:"absolute",top:"420px",left:"100px"}}>
                                <DialogHassosaki getInfo2={(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)=>this.getInfo2(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)}/>
                                <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-37px"}} className={classes.button} onClick = {this.handleCopy} >
                                注文者コピー
                                </Button>
                                <Button color="primary" variant="outlined" style={{position:"relative",left:"100px",top:"-37px"}} className={classes.button} onClick = {this.handleClear}>
                                クリア
                                </Button>
                            </div>    
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"470px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                発送先#<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="hassosakiCd" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"150px"}}
                                value={this.state.hassosakiCd} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>&nbsp;
                                <TextField id="outlined-basic" name="hassosakiName" 
                                style = {{position:"absolute",top:"5px",left:"360px",width:"200px"}}
                                value={this.state.hassosakiName} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                            </div>
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"530px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                発送先部署<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="hassosakiBusho" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.hassosakiBusho} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"590px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                郵便番号<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="yubinNum" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.yubinNum} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"650px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                住所<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" name="address" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"540px"}}
                                value={this.state.address} variant="outlined"  size = "small" onChange = {this.handleInput}/>             
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"710px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                電話番号<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　　
                                <TextField id="outlined-basic" name="telNum" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.telNum} variant="outlined" className={classes.textField2} size = "small" onChange = {this.handleInput}/>
                            </div>
                        </div>
                </div>  
                </div>
                <div style = {{position:"absolute",left:"65%",top:"54px",backgroundColor:"white"}}>
                <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",height:"370px"}}>
                <h2 style={{textAlign:"left"}}>カート</h2>
                <div style={{textAlign:"center"}}> 
                    <h3>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                    <h3>送料:{this.state.souryou} 円</h3>
                    <hr style = {{border:"1px solid rgba(0,0,0,0.2)"}}/>
                    <h3 style={{color:"red"}}>合計:{Number(parseInt(this.state.total)+parseInt(this.state.souryou)).toLocaleString('en-US')} 円</h3>
                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doUpdate}>
                        修正
                    </Button>
                    <br/><br/>
                    <CancelComfirm version={this.state.jyuhatyuVersion.toString()} 
                    juhattyuCd={this.props.data.juhattyuCd.toString()}
                    torihisakiCd={this.props.data.torihisakiCd}
                    />
                    <br/>
                    <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button2} onClick = {this.doPrint}>
                        印刷
                    </Button>
                    </div>
                </form>
                </div>
            </div>       
        )
    }
}
export default withStyles(styles)(withRouter(ThumonDetail));