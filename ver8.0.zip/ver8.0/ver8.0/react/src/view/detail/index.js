import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import SubMainHeader from '../subMainHeader';
import Detail from './detail';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '800px',
      },
});
class DetailIndex extends Component{
    render(){
        let text = this.props.match.params.data;
        let data = {
            assenhinCd:text.substring(text.indexOf("=")+1,text.indexOf("&")),
            hansuu:text.substring(text.indexOf("=",text.indexOf("=")+1)+1,text.length)
        }
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",width:"80%",left:"10%",backgroundColor:"white"}}>
                <TableContainer component={Paper}>
                <SubMainHeader/>
                <Detail data = {data}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(DetailIndex);