window.alert = alert;
function alert(data) {
var bg = document.createElement("div"),
a = document.createElement("div"),
p = document.createElement("p"),
btn = document.createElement("div"),
textNode = document.createTextNode(data ? data : ""),
btnText = document.createTextNode("閉じる");
css(bg,{
"position" : "fixed", 
"width" : "100%",
"height": "100%",
"z-index":"99999",
"background-color" : "rgba(0,0,0,0.3)",
})
css(a, {
"position" : "fixed",
"left" : "0",
"right" : "0",
"top" : "40%",
"width" : "300px",
"height" : "120px",
"margin" : "0 auto",
"padding" : "10px",
"color" : "black",
"background-color" : "white",
"border" : "1px solid rgba(0,0,0,0.1)",
"border-radius" : "4px",
"font-size" : "14px",
"text-align" : "center",
"z-index" : "9999"
});
css(btn, {
"width" : "80px",
"margin" : "0 auto",
"margin-top" : "30px",
"line-height" : "24px",
"color" : "blue",
"border" : "1px solid rgba(0,0,0,0.1)",
"background" : "white",
"border-radius" : "4px",
"cursor" : "pointer"
});
p.appendChild(textNode);
btn.appendChild(btnText);
a.appendChild(p);
a.appendChild(btn);
bg.appendChild(a);
document.getElementsByTagName("body")[0].appendChild(bg);
btn.onclick = function() {
bg.parentNode.removeChild(bg);
};
}
function css(targetObj, cssObj) {
var str = targetObj.getAttribute("style") ? targetObj.getAttribute("style") : "";
for(var i in cssObj) {
str += i + ":" + cssObj[i] + ";";
}
targetObj.style.cssText = str;
}