import React, { Component } from 'react';
import {Button,TextField,Chip} from '@material-ui/core';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';
import {Link} from "react-router-dom";
import axios from 'axios';
import DialogThumonsha from './dialogThumonsha';
import DialogHassosaki from './dialogHassosaki';
import Typography from '@material-ui/core/Typography';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import '../alert';
const styles = theme => ({
    textField: {
        backgroundColor:"white"
      },
    button: {
        margin: theme.spacing(0),
        minWidth: 50,
      },
    chip: {
        marginLeft: theme.spacing(1),
        marginTop: theme.spacing(0),
        marginRight: theme.spacing(0),
        padding : theme.spacing(0),
        fontSize : 12
    }

  });
class Address extends Component{
    constructor(props){
        super(props);
        this.state = {
            total:'',
            tantoBushoName:'',
            tantoshaName:'',
            thumonshaCd:'',
            thumonshaName:'',
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
            version:'',
            addInfo:[],
            userList:[],
            arr:[]
        };
    }
    componentDidMount(){
        this.getData()
    }
    getData(){
            axios.get(`/assen/AssenhinCartList/`+Date.parse(new Date()),{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    list:res.data
                })
                this.allPrice()
            })
            .catch((error)=>{
                console.log(error)
            })
           axios.get("/assen/selectDefaultAddress",{
            headers:{"token":sessionStorage.getItem("token")}
            })
           .then((res)=>{
               this.setState({
                    nyuryokushaCd:res.data.nyuryokushaCd,
                    nyuryokushaName:res.data.nyuryokushaName,
                    tantoBushoName:res.data.tantoBushoName,
                    tantoshaName:res.data.tantoshaName,
                    thumonshaCd:res.data.thumonshaCd,
                    thumonshaName:res.data.thumonshaName,
                    hassosakiCd:res.data.hassosakiCd,
                    hassosakiName:res.data.hassosakiName,
                    hassosakiBusho:res.data.hassosakiBusho,
                    yubinNum:res.data.yubinNum,
                    address:res.data.address,
                    telNum:res.data.telNum,
                    version:res.data.version
               })
           })
           .catch((error)=>{
               console.log(error)
           })
    }
    allPrice(){
        let _data = this.state.list
        let allPrice = 0
        for(let i=0;i<_data.length;i++){
            let item = _data[i]
            allPrice += Number(item.kakaku)*Number(item.thumonSuu)
        }
        this.setState({
            total:allPrice
        })
    }
    getInfo1(thumonshaCd,thumonshaName){
        this.setState({
            thumonshaCd:thumonshaCd,
            thumonshaName:thumonshaName
        })
    }
    getInfo2(hassosakiCd,hassosakiName,address,hassosakiBusho,yubinNum,telNum){
        this.setState({
            hassosakiCd:hassosakiCd,
            hassosakiName:hassosakiName,
            hassosakiBusho:hassosakiBusho,
            address:address,
            yubinNum:yubinNum,
            telNum:telNum
        })
    }
    handleClear=(e)=>{
        this.setState({
            hassosakiCd:'',
            hassosakiName:'',
            hassosakiBusho:'',
            yubinNum:'',
            address:'',
            telNum:'',
          })
    }
    doConfirm=(e)=>{
        e.preventDefault();
        if(!(this.state.tantoBushoName===''||this.state.tantoshaName===''||this.state.thumonshaName===''||
        this.state.yubinNum===''||this.state.address===''||this.state.telNum===''||
        this.state.hassosakiName===''||this.state.hassosakiBusho==='')){
            axios.post("/assen/updateHassosakiAll/",
                {
                    nyuryokushaCd:this.state.nyuryokushaCd.toString(),
                    nyuryokushaName:this.state.nyuryokushaName.toString(),
                    tantoBushoName:this.state.tantoBushoName.toString(),
                    tantoshaName:this.state.tantoshaName.toString(),
                    thumonshaCd:this.state.thumonshaCd.toString(),
                    thumonshaName:this.state.thumonshaName.toString(),
                    hassosakiCd:this.state.hassosakiCd.toString(),
                    hassosakiName:this.state.hassosakiName.toString(),
                    hassosakiBusho:this.state.hassosakiBusho.toString(),
                    yubinNum:this.state.yubinNum.toString(),
                    address:this.state.address.toString(),
                    telNum:this.state.telNum.toString(),
                    version:this.state.version.toString()
                },
                {
                    headers:{"token":sessionStorage.getItem("token")}
                }
            )
            .then((res)=>{
                if(res.data-this.state.version>0){
                    this.props.history.push(`/assen/cartConfirm/${this.props.id}`)
                }else{
                    alert("発送先情報更新が失敗しました") 
                }
            })
            .catch((error)=>{
                console.log(error)
            })
        }else(
            alert("必須項目を入力してください")
        )
    }
    doJump=()=>{
        this.props.history.push(`/assen/cartList/${this.props.id}`);
    }
    handleInput=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
        if(e.target.name==="thumonshaCd"){
            if(e.target.value.length>=4){
                this.autoSetUser(e.target.value)
            }
        }
        if(e.target.name==="hassosakiCd"){
            if(e.target.value.length>=4){
                this.autoSetAddress(e.target.value)
            }
        }
    }
    autoSetUser=(thumonshaCd)=>{
            axios.get(`/assen/searchThumonshaList/${thumonshaCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    userList:res.data
                })
                this.setUserOnly(thumonshaCd)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    autoSetAddress=(hassosakiCd)=>{
            axios.get(`/assen/selectHassosaki/${hassosakiCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
                this.setState({
                    addInfo:res.data
                })
                this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
    }
    setUserOnly=(thumonshaCd)=>{
        this.state.arr=this.state.userList.find(item=>item.thumonshaCd==thumonshaCd)
        this.setState({
            thumonshaName:this.state.arr.thumonshaName,
            userList:[],
            arr:[]
        })
    }
    setAdressOnly=(addInfo)=>{
        this.setState({
            hassosakiName:addInfo[0].hassosakiName,
            hassosakiCd:addInfo[0].hassosakiCd,
            address:addInfo[0].address,
            hassosakiBusho:addInfo[0].hassosakiBusho,
            yubinNum:addInfo[0].yubinNum,
            telNum:addInfo[0].telNum,
            addInfo:[],
            arr:[]
        })
    }
    handleCopy=(e)=>{
        if(!(this.state.thumonshaCd.toString().replace(/(^\s*)|(\s*$)/g, '').replace(/[\r\n]/g, '') === '')){
            axios.get(`/assen/selectHassosaki/${this.state.thumonshaCd}`,{
                headers:{"token":sessionStorage.getItem("token")}
            })
            .then((res)=>{
              this.setState({
                addInfo:res.data
              })
              this.setAdressOnly(this.state.addInfo)
            })
            .catch((error)=>{
                console.log(error)
            })
        }
    }
    render(){
        const { classes } = this.props;
        return(
                <div style={{position:"absolute",width:"100%",height:"100%",top:"10%",backgroundColor:"white"}}>
                    <div>
                    <Breadcrumbs className={classes.spacegaiyo}>
                        <Link to='/assen/top' style={{ textDecoration: 'none', color: 'blue' }}>ホーム</Link>
                        <Typography>発送先入力</Typography>
                    </Breadcrumbs>
                    </div>
                    <div style={{position:"relative",backgroundColor:"white",height:"800px"}}>
                        <div style = {{position:"absolute",width:"100%"}}>
                            <div style={{position:"absolute",top:"15px",fontSize:"25px"}}>入力者</div>
                            <div style={{position:"absolute",top:"50px",width:"600px",height:"50px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>入力者#</div>
                                <TextField id="outlined-basic" variant="outlined" name="nyuryokushaCd" disabled="disabled" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px",backgroundColor:"#C0C0C0"}}
                                value={this.state.nyuryokushaCd} className={classes.textField} size = "small"/>
                            </div>
                            <div style={{position:"absolute",width:"600px",height:"50px",top:"120px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>入力者</div>
                                <TextField id="outlined-basic" variant="outlined" name="nyuryokushaName" disabled="disabled" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px",backgroundColor:"#C0C0C0"}}
                                value={this.state.nyuryokushaName} className={classes.textField} size = "small"/>
                            </div>
                            <div style={{position:"absolute",width:"600px",height:"50px",top:"180px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div id="text" style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                    担当部署<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" variant="outlined" name="tantoBushoName" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.tantoBushoName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>
                            <div style={{position:"absolute",width:"600px",height:"50px",top:"240px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                    担当者<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" variant="outlined" name="tantoshaName" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.tantoshaName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>
                        </div>
                        <div style = {{position:"absolute",width:"100%"}}>
                            <div style = {{position:"absolute",top:"300px",fontSize:"25px"}}>注文者</div>
                            <div style={{position:"absolute",top:"300px",left:"100px"}}>
                            <DialogThumonsha getInfo1={(thumonshaCd,thumonshaName)=>this.getInfo1(thumonshaCd,thumonshaName)}/> 
                            </div>
                            <div style={{position:"absolute",width:"600px",height:"50px",top:"350px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                注文者#<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" variant="outlined" name="thumonshaCd" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"150px"}}
                                value={this.state.thumonshaCd} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                                <TextField id="outlined-basic" variant="outlined" name="thumonshaName"
                                style = {{position:"absolute",top:"5px",left:"360px",width:"200px"}}
                                value={this.state.thumonshaName} className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>
                        </div>
                        <div style = {{position:"absolute",width:"100%"}}>
                            <div style = {{position:"absolute",top:"420px",fontSize:"25px"}}>発送先</div>
                            <div style={{position:"absolute",top:"420px",left:"100px"}}>
                                <DialogHassosaki getInfo2={(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)=>this.getInfo2(hassosakiCd,hassosakiName,hassosakiBusho,address,yubinNum,telNum)}/>
                                <Button color="primary" variant="outlined" style={{position:"relative",left:"80px",top:"-37px"}} className={classes.button} onClick = {this.handleCopy} >
                                注文者コピー
                                </Button>
                                <Button color="primary" variant="outlined" style={{position:"relative",left:"100px",top:"-37px"}} className={classes.button} onClick = {this.handleClear}>
                                クリア
                                </Button>
                            </div>    
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"470px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                発送先#<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="hassosakiCd" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"150px"}}
                                value={this.state.hassosakiCd} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>&nbsp;
                                <TextField id="outlined-basic" name="hassosakiName" 
                                style = {{position:"absolute",top:"5px",left:"360px",width:"200px"}}
                                value={this.state.hassosakiName} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"530px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                発送先部署<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="hassosakiBusho" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.hassosakiBusho} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"590px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                郵便番号<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　
                                <TextField id="outlined-basic" name="yubinNum" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.yubinNum} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"650px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                住所<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>
                                <TextField id="outlined-basic" name="address" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"540px"}}
                                value={this.state.address} variant="outlined"  size = "small" onChange = {this.handleInput}/>           
                            </div>                                       
                            <div style={{position:"absolute",width:"750px",height:"50px",top:"710px",border:"1px solid rgba(0,0,0,0.2)"}}>
                                <div style={{position:"absolute",fontSize:"20px",top:"10px",left:"20px"}}>
                                電話番号<Chip color="secondary" className={classes.chip} size="small" label="必須"/>
                                </div>　　
                                <TextField id="outlined-basic" name="telNum" 
                                style = {{position:"absolute",top:"5px",left:"200px",width:"300px"}}
                                value={this.state.telNum} variant="outlined" className={classes.textField} size = "small" onChange = {this.handleInput}/>
                            </div>
                        </div>             
                    </div>                                
                    <div style = {{float:"right",position:"absolute",left:"65%",top:"100px"}}>
                    <form style = {{borderRadius:"10%",border:"5px solid rgba(0,0,0,0.2)",width:"250px",backgroundColor:"white",height:"350px"}}>
                        <br/>
                        <h2 style={{textAlign:"left"}}>カート</h2>
                        <div style={{textAlign:"center"}}> 
                        <br/>
                        <h3 style={{color:"red"}}>小計:{Number(this.state.total).toLocaleString('en-US')} 円</h3>
                        <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button} onClick = {this.doConfirm}>
                            注文内容確認
                        </Button>
                        <br/><br/>
                        <Button color="primary" variant="outlined" style={{backgroundColor:"orange",color:"black"}} className={classes.button} onClick = {this.doJump}>
                            カートに戻る
                        </Button>
                        </div>
                    </form>
                    </div>
                </div>
        )
    }
}
export default withStyles(styles)(withRouter(Address));