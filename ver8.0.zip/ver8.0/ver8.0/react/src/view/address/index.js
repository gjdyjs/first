import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import Address from './address';
const styles = theme => ({
    root: {
        minWidth: '960px',
        minHeight: '700px',
      },
});
class AddressIndex extends Component{
    render(){
        let id = this.props.match.params.id;
        const {classes} = this.props;
        return(
            <div className={classes.root} style={{position:"absolute",height:"100%",width:"80%",left:"10%",backgroundColor:"white"}}>
                <TableContainer component={Paper}>
                <Address id = {id}/>
                </TableContainer>
            </div>
        )
    }
}
export default withStyles(styles)(AddressIndex);