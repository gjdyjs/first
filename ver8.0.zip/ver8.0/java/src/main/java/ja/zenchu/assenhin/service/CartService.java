package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.CartDto;
import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuSplitDto;
import ja.zenchu.assenhin.entity.ACart;
import ja.zenchu.assenhin.entity.ACartKey;
import ja.zenchu.assenhin.entity.mapper.ACartMapper;
import ja.zenchu.assenhin.entity.mapper.AHassosakiWorkMapper;
import ja.zenchu.assenhin.entity.mapper.TokubetsuKakakuMapper;
import ja.zenchu.assenhin.enumtype.AllTorihikisakiEnum;
import ja.zenchu.assenhin.enumtype.DeleteFlagEnum;

@Service
public class CartService {

	@Autowired
	ACartMapper aCartMapper;
	@Autowired
	TokubetsuKakakuMapper tokubetsuKakakuMapper;
	@Autowired
	AHassosakiWorkMapper aHassosakiWorkMapper;
	
	/**
	 * 該当ユーザーが保持している現カート数を取得する。
	 * @param torihikisakiCd 取引先#
	 * @return
	 */
	public int getCartCount(Integer torihikisakiCd) {
		return aCartMapper.getCartCount(torihikisakiCd);
	}
	

	/**
	 * カートリストの取得
	 * ※作業テーブル用のUUIDとカートの初期リストを返す。
	 * @param loginUserDto ログインユーザーDto
	 * @return
	 */
	@Deprecated
	public CartDto getCartDto(LoginUserDto loginUserDto) {
		final String uuid = java.util.UUID.randomUUID().toString();
		//カートリストを取得
		CartDto cartDto = new CartDto();
		cartDto.setUUID(uuid);
		List<CartListDto> rtnList =  aCartMapper.searchCartList(loginUserDto.getTorihikisakiCd(), loginUserDto.getKakakuSetteiCls(), LocalDate.now());
		cartDto.setCartList(rtnList);
		return cartDto;
	}
	
	/**
	 * カートリストを取得
	 * 最終チェックの場合にだけ会員価格チェックを行うため、そのためのフラグ付きメソッドを作りました。
	 * そちらに変更してください。
	 * @param loginUserDto
	 * @return カートのリスト
	 */
	@Deprecated
	public List<CartListDto> getCartList(LoginUserDto loginUserDto) {
		List<CartListDto> rtnList =  aCartMapper.searchCartList(loginUserDto.getTorihikisakiCd(), loginUserDto.getKakakuSetteiCls(), LocalDate.now());
		return rtnList;
	}
	
	/**
	 * カートリストの取得
	 * @param loginUserDto　ログイン情報
	 * @param isSaishuKakunin 注文最終確認画面の時だけTrue
	 * @return
	 */
	public List<CartListDto> getCartList(LoginUserDto loginUserDto, final boolean isSaishuCheck) {
		
		List<CartListDto> rtnList =  aCartMapper.searchCartList(loginUserDto.getTorihikisakiCd(), loginUserDto.getKakakuSetteiCls(), LocalDate.now());
		if (isSaishuCheck) {
			replaceKaiinKakakuCheck(rtnList, loginUserDto);
		}
		return rtnList;
	}
	/**
	 * 最終確認画面のみ最終会員価格適用のチェックを行う。
	 * @param rtnList 変更対象の注文者リスト
	 * @param loginUserDto
	 */
	private void replaceKaiinKakakuCheck(List<CartListDto> rtnList, LoginUserDto loginUserDto) {
		//注文者取得して会員価格適用の最終チェックを行う
		Integer thumonshaCd = aHassosakiWorkMapper.getThumonshaCd(loginUserDto.getTorihikisakiCd());
		Iterator<CartListDto> ite = rtnList.iterator();
		while(ite.hasNext()) {
			CartListDto dto = ite.next();
			//特別価格セット
			Integer searchThumonshaCd = thumonshaCd;
			if (searchThumonshaCd == null) {
				searchThumonshaCd = AllTorihikisakiEnum.SONOTA.getTorihikisakiCd();
			}
			final String tokubetsuStr = tokubetsuKakakuMapper.getTokubetsuKakaku(dto.getAssenhinCd(), dto.getHansuu(), loginUserDto.getTorihikisakiCd(), searchThumonshaCd, (short) dto.getThumonSuu());
			TokubetsuKakakuSplitDto checkDto = new TokubetsuKakakuSplitDto(tokubetsuStr);
			//会員価格の時のみ表示変更
			if (checkDto.isKaiinKakaku()) {
				dto.setKakaku(checkDto.getTanka());
				dto.setKakakuCls(checkDto.getKaiinCls());
				if (checkDto.getKaiinCls() > 0) {
					dto.setKaiinTekiyou(true); //会員摘要
				}
			}
		}
	}
	
	/**
	 * カート情報の登録
	 * @param assenhinCd 斡旋品#
	 * @param hansuu 版数
	 * @param thumonSuu 注文数
	 * @param loginDto ログイン情報
	 * @return
	 */
	public int insertCart(Integer assenhinCd, Short hansuu, Short thumonSuu, LoginUserDto loginDto) {
		//カートデータ作成
		ACart newData = new ACart();
		newData.setTorihikisakiCd(loginDto.getTorihikisakiCd());
		newData.setAssenhinCd(assenhinCd);
		newData.setHansuu(hansuu);
		newData.setCartSuuryo(thumonSuu);
		newData.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
		newData.setKoushinNichiji(LocalDateTime.now());
		newData.setKoushinshaCd(loginDto.getTorihikisakiCd());
		newData.setVersion(1);
		//斡旋品登録
		int rtn = aCartMapper.insert(newData);
		return rtn;
	}
	
	/**
	 * 注文数更新
	 * @param assenhinCd 斡旋品番号
	 * @param hansuu　版数
	 * @param thumonSuu 注文数
	 * @param version バージョン （CartListDto）で返した
	 * @param loginDto ログイン情報
	 * @return 更新後のバージョン（これだけはバージョン管理をしたい都合上バージョンを返す点に注意
	 */
	public int updateThumonsuu(Integer assenhinCd, Short hansuu, Short thumonSuu, Integer version, LoginUserDto loginDto) {
		int upd = aCartMapper.updateThumonSuu(loginDto.getTorihikisakiCd(), assenhinCd, hansuu, thumonSuu, version);
		//更新された場合バージョンを返す
		if (upd == 1) {
			return (version + 1);
		} else {
			return 0; //更新無しの場合0
		}
	}
	
	/**
	 * カート削除
	 * @param assenhinCd 斡旋品番号
	 * @param hansuu　版数
	 * @param version バージョン （CartListDto）で返した
	 * @param loginDto ログイン情報
	 * @return
	 */
	public int deleteCart(Integer assenhinCd, Short hansuu, Integer version, LoginUserDto loginDto) { 
		ACartKey key = new ACartKey();
		key.setTorihikisakiCd(loginDto.getTorihikisakiCd());
		key.setAssenhinCd(assenhinCd);
		key.setHansuu(hansuu);
		return aCartMapper.deleteByPrimaryKey(key);
	
	}

}
