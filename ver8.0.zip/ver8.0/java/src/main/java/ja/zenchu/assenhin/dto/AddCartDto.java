package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * カート追加用
 * @author take
 *
 */
@Getter
@Setter
public class AddCartDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3861130563926894664L;
	
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	/** 斡旋品名 */
	private String assenhinName;
	/** 在庫数(カートで必要か確認) */
	private int zaikoSuu;
	/**  部署名 */
	private String bushoName;
	/** 価格 */
	private int kakaku;
	/** 注文数 */
	private int thumonSuu;

}
