package ja.zenchu.assenhin.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import ja.zenchu.assenhin.dto.HistoryDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.security.LoginUserDetails;
import ja.zenchu.assenhin.service.HistoryListService;

/**
 * 注文済みのカート一覧画面
 *
 */
@RestController
public class HistoryListController {
	@Autowired
	HistoryListService historyListService;
	/**
	 * 注文済みのカート一覧情報を取得
	 *
	 */
    @RequestMapping(value = "/historyListByTorihisakiCd/{id}",method= RequestMethod.GET)
    public List<HistoryDto> GetHistoryList(@PathVariable("id") String torihisakiCd,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	String nendoString = gson.toJson(historyListService.getNendoList(loginUserDto)).substring(1,5);
    	short nendo=Short.parseShort(nendoString);
    	return historyListService.searchHistoryList(nendo,loginUserDto);
    }
	/**
	 * 該当ユーザの注文履歴の年度リストを取得
	 *
	 */
    @RequestMapping(value = "/getNendoList",method= RequestMethod.GET)
    public List<Short> GetNendoList(@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	Gson gson = new Gson();
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	return historyListService.getNendoList(loginUserDto);
    }
	/**
	 * サーバの時間を取得
	 *
	 */
    @RequestMapping(value = "/getServerTime",method= RequestMethod.GET)
    public String GetServerTime(){
    	String time=new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());
    	String serverTime = time.substring(0,8);
    	return serverTime;
    }
	/**
	 * 指定条件で注文済みのカート一覧情報を取得
	 *
	 */
    @RequestMapping(value = "/historyListByNendo/{data}",method= RequestMethod.GET)
    public List<HistoryDto> GetHistoryListWithRules(@PathVariable("data") String params,@AuthenticationPrincipal  LoginUserDetails loginUserDetails){
    	LoginUserDto loginUserDto = loginUserDetails.getUserDto();
    	Gson gson = new Gson();
    	Map<String, Object> map = new HashMap<String, Object>();
    	map = gson.fromJson(params, map.getClass());
    	List<HistoryDto> result = null ;
    	if(map.get("juhattyuCd").toString().isEmpty()) {
    		short nendo=Short.parseShort( (String) map.get("nendo"));
        	result = historyListService.searchHistoryList(nendo,loginUserDto);
    	}else {
    		int juhattyuCd = Integer.valueOf((String) map.get("juhattyuCd")).intValue();
    		short nendo=Short.parseShort( (String) map.get("nendo"));
    		result = historyListService.searchHistoryList(nendo,loginUserDto,juhattyuCd);
    	}
    	return result;
    }
    
    
}