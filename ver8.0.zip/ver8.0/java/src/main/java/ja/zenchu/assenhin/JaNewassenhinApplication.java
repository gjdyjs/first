package ja.zenchu.assenhin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaNewassenhinApplication {

	public static void main(String[] args) {
		SpringApplication.run(JaNewassenhinApplication.class, args);
	}

}
