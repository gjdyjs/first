package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.AssenhinDetailDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuDto;
import ja.zenchu.assenhin.entity.ACart;
import ja.zenchu.assenhin.entity.ACartKey;
import ja.zenchu.assenhin.entity.mapper.AAssenhinKakakuMapper;
import ja.zenchu.assenhin.entity.mapper.AAssenhinMapper;
import ja.zenchu.assenhin.entity.mapper.ACartMapper;
import ja.zenchu.assenhin.entity.mapper.AZaikoMapper;
import ja.zenchu.assenhin.enumtype.DeleteFlagEnum;

/**
 * 斡旋品商品詳細用のサービス
 * @author take
 *
 */
@Service
public class AssenhinDetailService {

	@Autowired
	AAssenhinMapper aAssenhinMapper;
	
	@Autowired
	AAssenhinKakakuMapper aAssenhinKakakuMapper;
	
	@Autowired
	AZaikoMapper aZaikoMapper;
	
	@Autowired
	ACartMapper aCartMapper;
	
	/**
	 * 斡旋品詳細情報の取得
	 * @param assenhinCd
	 * @param hansuu
	 * @param loginUserDto
	 * @return
	 */
	public AssenhinDetailDto getAssenhinDetail(Integer assenhinCd, Short hansuu, LoginUserDto loginUserDto) {
		AssenhinDetailDto assenhinDetail = aAssenhinMapper.getAssenhinDetail(assenhinCd, hansuu, loginUserDto.getKakakuSetteiCls(), LocalDate.now());
		return assenhinDetail;
	}
	
	/**
	 * 特別会員価格リスト
	 * @param assenhinCd
	 * @param hansuu
	 * @param loginUserDto
	 * @return
	 */
	public List<TokubetsuKakakuDto> getTokubetsuKakakuList(Integer assenhinCd, Short hansuu, final LoginUserDto loginUserDto) {
		List<Short> kaiinClsSearch = loginUserDto.getKaiinClsList();
		//特別会員リストは会員区分なしも検索対象
		kaiinClsSearch.add((short)0);
		List<TokubetsuKakakuDto> tokubetsuList =  aAssenhinKakakuMapper.getTokubetsuKakakuList(assenhinCd, hansuu, kaiinClsSearch);
		return tokubetsuList;
	}

	/**
	 * カート注文の追加
	 * データは取得時にマスタと紐づけてSQL検索する予定なので
	 * カートには最低限の項目のみセットする予定
	 * @param assenhinCd 斡旋品#
	 * @param hansuu 版数
	 * @param thumonSuu 注文数
	 * @param userDto ログイン情報（取引先番号を使う）
	 * @return
	 */
	public int insertCart(Integer assenhinCd, Short hansuu, short thumonSuu,LoginUserDto userDto) {
		//カート件数チェック
		ACartKey key = new ACartKey();
		key.setTorihikisakiCd(userDto.getTorihikisakiCd());
		key.setAssenhinCd(assenhinCd);
		key.setHansuu(hansuu);;
		ACart cart = aCartMapper.selectByPrimaryKey(key);
		
		//カートがあればアップデート
		//カートがなければINSERT
		if (cart == null) {
			//追加
			cart = new  ACart();
			BeanUtils.copyProperties(key, cart);;
			cart.setCartSuuryo(thumonSuu);
			cart.setKoushinNichiji(LocalDateTime.now());
			cart.setKoushinshaCd(userDto.getTorihikisakiCd());
			cart.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
			cart.setVersion(1);;
			return aCartMapper.insert(cart);
		} else {
			//更新
			cart.setCartSuuryo((short) (cart.getCartSuuryo() + thumonSuu));;
			cart.setKoushinNichiji(LocalDateTime.now());
			cart.setKoushinshaCd(userDto.getTorihikisakiCd());
			cart.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
			cart.setVersion(cart.getVersion() + 1);
			return aCartMapper.updateByPrimaryKey(cart);
		}
	}
	
}
