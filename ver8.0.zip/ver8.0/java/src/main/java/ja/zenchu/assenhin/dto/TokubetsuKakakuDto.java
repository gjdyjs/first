package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 特別価格用のDto
 * ※想定としては斡旋品詳細画面で特別価格が表示される場合に使用する。
 * @author take
 *
 */
@Getter
@Setter
public class TokubetsuKakakuDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4200879021932803493L;
	
	/** 斡旋品#  */
	private int assenhinCd;
	/** 版数  */
	private short hansuu;
	
	/** 価格区分 */
	private short kakakuCls;
	
	/** 会員区分 */
	private short kaiinCls;
	
	/** 特別価格の名称  */
	private String kakakuName;

	/** 特別価格 */
	private int tokubetsuKakaku;
}
