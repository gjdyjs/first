package ja.zenchu.assenhin.logic;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.CartListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.TokubetsuKakakuSplitDto;
import ja.zenchu.assenhin.entity.AAssenhin;
import ja.zenchu.assenhin.entity.AAssenhinKey;
import ja.zenchu.assenhin.entity.AHassosakiWork;
import ja.zenchu.assenhin.entity.AJuhattyuMeisai;
import ja.zenchu.assenhin.entity.AToujitsuHassosaki;
import ja.zenchu.assenhin.entity.mapper.AAssenhinMapper;
import ja.zenchu.assenhin.entity.mapper.TokubetsuKakakuMapper;
import ja.zenchu.assenhin.enumtype.AllTorihikisakiEnum;
import ja.zenchu.assenhin.enumtype.DeleteFlagEnum;
import ja.zenchu.assenhin.enumtype.KaikeiRendoEnum;
import ja.zenchu.assenhin.enumtype.SeikyushoOutFlagEnum;
import ja.zenchu.assenhin.enumtype.ShukkoFlagEnum;
import ja.zenchu.assenhin.enumtype.UkeireKyokyuClsEnum;

/**
 * カート登録と当日注文変更共通のロジックに使用する。
 * @author take
 *
 */
@Service
public class JuhattyuLogic {
	
	@Autowired
	AAssenhinMapper aAssenhinMapper;
	
	@Autowired
	TokubetsuKakakuMapper tokubetsuKakakuMapper;
	
	public AJuhattyuMeisai createNewJuhattyuMeisaiData(
			final int juhattyuCd, final short juhattyuMeisaiCd,LocalDate juhattyubi,
			CartListDto cart, AHassosakiWork work, LoginUserDto loginUserDto) {
		AJuhattyuMeisai meisai = new AJuhattyuMeisai();
		meisai.setNendo(loginUserDto.getTargetNendo());
		meisai.setJuhattyuCd(juhattyuCd);
		meisai.setJuhattyuMeisaiCd(juhattyuMeisaiCd);		
		//受発注日
		meisai.setJuhattyubi(juhattyubi);
		//共通部分
		createJuhattyuMeisaiDataCommon(meisai, cart, loginUserDto);
		//発送先
		copyHassosakiData(meisai, work);
		//特別価格
		copyKakaku(meisai, cart, loginUserDto, work.getThumonshaCd());
		return meisai;
	}
	
	public AJuhattyuMeisai createToujitsuHenshuJuhattyuMeisaiData(Short nendo,
			final int juhattyuCd, final short juhattyuMeisaiCd,LocalDate juhattyubi,
			CartListDto cart, AToujitsuHassosaki work, LoginUserDto loginUserDto) {
		AJuhattyuMeisai meisai = new AJuhattyuMeisai();
		meisai.setNendo(nendo);
		meisai.setJuhattyuCd(juhattyuCd);
		meisai.setJuhattyuMeisaiCd(juhattyuMeisaiCd);		
		//受発注日
		meisai.setJuhattyubi(juhattyubi);
		//共通部分
		createJuhattyuMeisaiDataCommon(meisai, cart, loginUserDto);
		//発送先
		copyHassosakiData(meisai, work);
		//特別価格
		copyKakaku(meisai, cart, loginUserDto, work.getThumonshaCd());
		return meisai;
	}

	
	private void copyHassosakiData(AJuhattyuMeisai meisai, AHassosakiWork work) {
		//発送先
		meisai.setHassosakiCd(work.getHassosakiCd());
		meisai.setHassosakiName(work.getHassosakiName());
		meisai.setYubinNum(work.getYubinNum());
		meisai.setAddress(work.getAddress());
		meisai.setTtelNum(work.getTelNum());
		meisai.setHassosakiBusho(work.getHassosakiBusho());
		//請求先(注文者）
		meisai.setTyumonshaCd(work.getThumonshaCd());
		meisai.setTyumonsha(work.getThumonshaName());
		
	}
	/**
	 * 当日注文用の発送先コピー
	 * @param meisai
	 * @param work
	 */
	private void copyHassosakiData(AJuhattyuMeisai meisai, AToujitsuHassosaki work) {
		//発送先
		meisai.setHassosakiCd(work.getHassosakiCd());
		meisai.setHassosakiName(work.getHassosakiName());
		meisai.setYubinNum(work.getYubinNum());
		meisai.setAddress(work.getAddress());
		meisai.setTtelNum(work.getTelNum());
		meisai.setHassosakiBusho(work.getHassosakiBusho());
		//請求先(注文者）
		meisai.setTyumonshaCd(work.getThumonshaCd());
		meisai.setTyumonsha(work.getThumonshaName());
		
	}
	/**
	 * 特別価格を取得して価格を設定
	 * @param meisai
	 * @param cart
	 * @param loginUserDto
	 * @param thumonshaCd
	 */
	private void copyKakaku(AJuhattyuMeisai meisai, CartListDto cart, LoginUserDto loginUserDto, Integer thumonshaCd) {
		TokubetsuKakakuSplitDto kakakuDto = getTokubetsuKakaku(cart, loginUserDto, thumonshaCd);
		//価格
		if (kakakuDto.isKakakuFound()) {
			//特別価格を取得した
			meisai.setKakakuCls(kakakuDto.getKakakuCls());
			meisai.setKaiinCls(kakakuDto.getKaiinCls());
			meisai.setTanka(kakakuDto.getTanka());
			meisai.setKingaku((long)(kakakuDto.getTanka() * cart.getThumonSuu())); //金額も単価かけ直し。
		} else {
			//取得できなかった
			meisai.setKakakuCls(cart.getKakakuCls());
			meisai.setTanka(cart.getKakaku());
			meisai.setKaiinCls((short)0); 
			meisai.setKingaku((long)(cart.getKakaku() * cart.getThumonSuu())); //金額も単価かけ直し。
		}
		
	}
	/**
	 * 登録・当日注文のデータ取得共通部分
	 * @param meisai
	 * @param cart
	 * @param loginUserDto
	 */
	private void createJuhattyuMeisaiDataCommon(
			AJuhattyuMeisai meisai,	CartListDto cart, LoginUserDto loginUserDto) {
		//受発注明細作成

		meisai.setSeikyusakiCd(loginUserDto.getTorihikisakiCd());
		meisai.setHattyumotoCd(loginUserDto.getTorihikisakiCd());;
		meisai.setUkeireKyokyuCls(UkeireKyokyuClsEnum.HATTYU.getUkeireCls());
		//斡旋品
		meisai.setAssenhinCd(cart.getAssenhinCd());
		meisai.setHansuu(cart.getHansuu());
		//数量
		meisai.setHattyuSuuryo(cart.getThumonSuu());
		meisai.setNyusyukkoSuuryo(cart.getThumonSuu());
		final long kingaku = (long) (meisai.getHattyuSuuryo() * cart.getKakaku());
		meisai.setKingaku(kingaku);
		//出庫フラグ（未出庫固定）
		meisai.setSyukkoFlag(ShukkoFlagEnum.MISHUKKO.getShukkoFlag());
		//連動フラグ
		final short rendoFlag = KaikeiRendoEnum.RENDOMACHI.getRendoFlag();
		meisai.setKaikeiRendoFlag(rendoFlag);
		meisai.setKentyuRendoFlag(rendoFlag);;
		//請求書
		meisai.setSeikyushoOutFlag(SeikyushoOutFlagEnum.MISHUTSURYOKU.getSeikyushoOutFlag());
		//初期数量
		meisai.setShokiSuuryo(cart.getThumonSuu());
		//斡旋品重量
		AAssenhinKey key = new AAssenhinKey();
		key.setAssenhinCd(cart.getAssenhinCd());
		key.setHansuu(cart.getHansuu());;
		AAssenhin assenhin =  aAssenhinMapper.selectByPrimaryKey(key);
		final long soujuuryo = (long)assenhin.getJuuryo() * (long)cart.getThumonSuu();
		meisai.setSoujuuryo(soujuuryo);
		//予約区分
		meisai.setYoyakuFlag(assenhin.getYoyakuCls());
		//全中部署
		meisai.setZentyuBushoCd(assenhin.getZentyuBushoCd());
		meisai.setDeleteFlag(DeleteFlagEnum.YUUKOU.getDeleteFlag());
		meisai.setVersion(1);
		return;
	}
	
	/**
	 * 
	 * @param loginUserDto
	 * @param nendo
	 * @param juhattyuCd
	 * @param juhattyuMeisaiCd
	 * @param thumonshaCd
	 * @param thumonSuu
	 * @return
	 */
	public TokubetsuKakakuSplitDto getTokubetuKakakuDto(LoginUserDto loginUserDto, Short nendo, Integer juhattyuCd, Short juhattyuMeisaiCd, Integer thumonshaCd, Short thumonSuu) {
		//価格データの取得
		String kakakukey = tokubetsuKakakuMapper.getTokubetsuKakakuByJuhattyuCd(loginUserDto.getTorihikisakiCd(),
				nendo, juhattyuCd, juhattyuMeisaiCd, thumonshaCd, thumonSuu);
		TokubetsuKakakuSplitDto tDto = new TokubetsuKakakuSplitDto(kakakukey);
		return tDto;
	}

	/**
	 * 特別価格を取得する
	 * @param rtnList
	 * @param loginUserDto
	 * @param thumonshaCd
	 */
	private TokubetsuKakakuSplitDto getTokubetsuKakaku (CartListDto rtnDto, LoginUserDto loginUserDto, Integer thumonshaCd) {
		Integer searchThumonshaCd = thumonshaCd;
		if (searchThumonshaCd == null) {
			searchThumonshaCd = AllTorihikisakiEnum.SONOTA.getTorihikisakiCd();
		}
		final String tokubetsuStr = tokubetsuKakakuMapper.getTokubetsuKakaku(rtnDto.getAssenhinCd(), rtnDto.getHansuu(), loginUserDto.getTorihikisakiCd(), searchThumonshaCd, (short) rtnDto.getThumonSuu());
		TokubetsuKakakuSplitDto checkDto = new TokubetsuKakakuSplitDto(tokubetsuStr);
		return checkDto;
	}
}
