package ja.zenchu.assenhin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import ja.zenchu.assenhin.security.LoginUserDetailsService;

@Configuration
@EnableWebSecurity
@SuppressWarnings("deprecation")
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private LoginUserDetailsService loginUserDetailsService;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable();
		
		http.authorizeRequests()
		.antMatchers("/**","/login", "/perform_login","/static/*","/css/*").permitAll()
//			.antMatchers("/login").permitAll()
			.anyRequest().authenticated();

		http.formLogin()
			.loginPage("/index")
			.loginProcessingUrl("/perform_login")
			.defaultSuccessUrl("/loginRtn",true)
//			.defaultSuccessUrl("/index.html",true)
			.failureUrl("/loginError")
//			.failureForwardUrl("/loginError")
			.usernameParameter("userId")
			.passwordParameter("password")
			.permitAll();
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(loginUserDetailsService).passwordEncoder(passwordEncoder());
	}
}
