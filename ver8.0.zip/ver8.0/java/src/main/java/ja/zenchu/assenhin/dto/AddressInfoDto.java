package ja.zenchu.assenhin.dto;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;

/**
 * 住所情報
 * @author take
 *
 */
@Getter
public class AddressInfoDto implements Serializable {



	/**
	 * 
	 */
	private static final long serialVersionUID = 6627686841695163783L;
	//以下入力者用
	/** 入力者#	 */
	private int nyuryokushaCd;
	/** 入力者名(入力者とかの名称) */
	private String nyuryokushaName;
	/** 担当部署 */
	private String tantoBushoName;
	/**  担当者 */
	private String tantoshaName;
	
	//以下は注文者
	/** 注文者# */
	private String thumonshaCd;
	/** 注文者名 */
	private String thumonshaName;
	
	//発送先
	/** 発送先# */
	private String hassosakiCd;
	/** 発送先名 */
	private String hassosakiName;
	/** 発送先部署 */
	private String hassosakiBusho;
	/** 郵便番号 */
	private String yubinNum;
	/** 住所 */
	private String address;
	/** 電話番号 */
	private String telNum;
	
	//バージョン管理用
	int version;
	public void setNyuryokushaCd(int nyuryokushaCd) {
		this.nyuryokushaCd = nyuryokushaCd;
	}

	public void setNyuryokushaName(String nyuryokushaName) {
		this.nyuryokushaName = StringUtils.defaultString(nyuryokushaName);
	}

	public void setTantoBushoName(String tantoBushoName) {
		this.tantoBushoName = StringUtils.defaultString(tantoBushoName);
	}

	public void setTantoshaName(String tantoshaName) {
		this.tantoshaName = StringUtils.defaultString(tantoshaName);
	}

	public void setThumonshaCd(String thumonshaCd) {
		this.thumonshaCd = thumonshaCd;
	}

	public void setThumonshaName(String thumonshaName) {
		this.thumonshaName = StringUtils.defaultString(thumonshaName);
	}

	public void setHassosakiCd(String hassosakiCd) {
		this.hassosakiCd = hassosakiCd;
	}

	public void setHassosakiName(String hassosakiName) {
		this.hassosakiName = StringUtils.defaultString(hassosakiName);
	}

	public void setHassosakiBusho(String hassosakiBusho) {
		this.hassosakiBusho = StringUtils.defaultString(hassosakiBusho);
	}

	public void setYubinNum(String yubinNum) {
		this.yubinNum = StringUtils.defaultString(yubinNum);
	}

	public void setAddress(String address) {
		this.address = StringUtils.defaultString(address);
	}

	public void setTelNum(String telNum) {
		this.telNum = StringUtils.defaultString(telNum);
	}

	public void setVersion(int version) {
		this.version = version;
	}
}
