package ja.zenchu.assenhin.service;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ja.zenchu.assenhin.dto.AddressInfoDto;
import ja.zenchu.assenhin.dto.HassosakiListDto;
import ja.zenchu.assenhin.dto.LoginUserDto;
import ja.zenchu.assenhin.dto.SearchTorihikisakiDialogDto;
import ja.zenchu.assenhin.dto.SelectTorihikisakiByKeyDto;
import ja.zenchu.assenhin.dto.ThumonshaListDto;
import ja.zenchu.assenhin.entity.AHassosakiWork;
import ja.zenchu.assenhin.entity.mapper.AHassosakiWorkMapper;
import ja.zenchu.assenhin.entity.mapper.MTorihikisakiMapper;
import ja.zenchu.assenhin.utils.StringUtility;

/**
 * 住所を取得する
 * @author take
 *
 */
@Service
public class AddressService {
	@Autowired
	MTorihikisakiMapper mTorihikisakiMapper;
	@Autowired
	AHassosakiWorkMapper aHassosakiWorkMapper;
	
	/**
	 * 発送先入力や最終確認画面での発送先取得
	 * @param torihikisakiCd
	 * @return
	 */
	public AddressInfoDto selectDefaultAddress(LoginUserDto loginUserDto) {
		final int torihikisakiCd = loginUserDto.getTorihikisakiCd();
		final String userId = loginUserDto.getUserId();
		//ワークテーブルがあるか？
		AHassosakiWork work = aHassosakiWorkMapper.selectByPrimaryKey(torihikisakiCd);
		if (work == null) {
			//新規データ
			aHassosakiWorkMapper.copyHassosaki(userId, torihikisakiCd, LocalDate.now());
			work = aHassosakiWorkMapper.selectByPrimaryKey(torihikisakiCd);
			work.setVersion(1);
		}
	 	AddressInfoDto rtnDto =  copyAddoressDto(work);
		return rtnDto;

	}
	
	/**
	 * 発送先がある場合
	 * @param torihikisakiCd
	 * @param addressDto
	 * @return
	 */
	public int insertHassosakiDefault(Integer torihikisakiCd, AddressInfoDto addressDto) {
		AHassosakiWork work = new AHassosakiWork();
		BeanUtils.copyProperties(addressDto, work);
		work.setTorihikisakiCd(torihikisakiCd);
		work.setVersion(1);
		return aHassosakiWorkMapper.insert(work);
	}
	/**　作業用ワークテーブルを更新 */
	public int updateHassousakiAll(AddressInfoDto addressDto) {
		return updateHassousakiAll(addressDto);
	}

	
	/**
	 * 注文者のリスト
	 * @param searchKey　入力された検索キー
	 * @return
	 */
	public List<ThumonshaListDto> searchThumonshaList(String searchKey){
		SearchTorihikisakiDialogDto searchDto = new SearchTorihikisakiDialogDto(searchKey, LocalDate.now());
		return mTorihikisakiMapper.searchThumonshaList(searchDto);
	}

	/**
	 * 発送先のリスト
	 * @param searchKey　入力された検索キー
	 * @return
	 */
	public List<HassosakiListDto> searchHassosakiList(String searchKey){
		SearchTorihikisakiDialogDto searchDto = new SearchTorihikisakiDialogDto(searchKey, LocalDate.now());
		return mTorihikisakiMapper.searchHassosakiList(searchDto);
	}
	
	/***
	 * 入力者の必要な情報を取得
	 * @param torihikisakiCd
	 * @return
	 */
	public AddressInfoDto selectNyuryokusha(LoginUserDto loginUserDto) {
		SelectTorihikisakiByKeyDto tDto = mTorihikisakiMapper.selectTorihikisakiByKey(loginUserDto.getTorihikisakiCd(), LocalDate.now());
		
		//TODO これでいいか確認
		//入力者関連の2項目だけセット
		AddressInfoDto rtnDto = new AddressInfoDto();
		setNyuryokusha(rtnDto, tDto, loginUserDto.getUserId());
		return rtnDto;
	}
	/**
	 * 注文者の必要な情報を取得
	 * @param torihikisakiCd
	 * @return
	 */
	public AddressInfoDto selectThumonsha(Integer torihikisakiCd) {
		SelectTorihikisakiByKeyDto tDto = mTorihikisakiMapper.selectTorihikisakiByKey(torihikisakiCd, LocalDate.now());
		
		//TODO これでいいか確認
		//注文者関連の2項目だけセット
		AddressInfoDto rtnDto = new AddressInfoDto();
		setThumonsha(rtnDto, tDto);
		return rtnDto;
	}
	/**
	 * 発送先に必要な情報を取得
	 * 発送先部署は初期で空なのでとりあえず空
	 * @param torihikisakiCd
	 * @return
	 */
	public AddressInfoDto selectHassosaki(Integer torihikisakiCd) {
		SelectTorihikisakiByKeyDto tDto = mTorihikisakiMapper.selectTorihikisakiByKey(torihikisakiCd, LocalDate.now());
		
		//TODO これでいいか確認
		//発送先関連の5項目だけセット
		AddressInfoDto rtnDto = new AddressInfoDto();
		setHassosaki(rtnDto, tDto);
		return rtnDto;
	}
	
	/**
	 * 発送先をワークテーブルに更新する
	 * @param torihikisakiCd
	 * @param updDto
	 * @return
	 */
	public int updateHassosakiAll(Integer torihikisakiCd, AddressInfoDto updDto) {
		AHassosakiWork work = replaceHassosakiWork(torihikisakiCd, updDto);
		if (work != null) {
			int upd = aHassosakiWorkMapper.updateByPrimaryKeyAndVersion(work);
			if (upd == 1) {
				return work.getVersion() + 1;
			}
		}
		return 0;//更新無し
	}
	
	
	private AHassosakiWork replaceHassosakiWork(Integer torihikisakiCd, AddressInfoDto updDto) {
		AHassosakiWork updData = copyAddressWork(updDto);
		updData.setTorihikisakiCd(torihikisakiCd);
		return updData;
	}

	/**
	 * 入力者セット
	 * @param rtnDto
	 * @param tDto
	 */
	private void setNyuryokusha(AddressInfoDto rtnDto, SelectTorihikisakiByKeyDto tDto, final String userId) {
		rtnDto.setNyuryokushaCd(Integer.parseInt(userId));
		rtnDto.setNyuryokushaName(tDto.getTorihikisakiName());
		//担当部署と担当者名は初期空文字
		rtnDto.setTantoBushoName(null);
		rtnDto.setTantoshaName(null);
	}

	/**
	 * 注文者セット
	 * @param rtnDto
	 * @param tDto
	 */
	private void setThumonsha(AddressInfoDto rtnDto, SelectTorihikisakiByKeyDto tDto) {
		if (tDto != null) {
			rtnDto.setThumonshaCd(StringUtility.toString(tDto.getTorihikisakiCd()));
			rtnDto.setThumonshaName(tDto.getTorihikisakiName());
		} else {
			rtnDto.setThumonshaName(null);
		}
	}

	/**
	 * 発送先の更新
	 * @param rtnDto
	 * @param tDto
	 */
	private void setHassosaki(AddressInfoDto rtnDto, SelectTorihikisakiByKeyDto tDto) {
		if (tDto != null) {
			rtnDto.setHassosakiCd(StringUtility.toString(tDto.getTorihikisakiCd()));
			rtnDto.setHassosakiName(tDto.getTorihikisakiName());
			rtnDto.setYubinNum(tDto.getYubinNum());
			rtnDto.setAddress(tDto.getAddress());
			rtnDto.setTelNum(tDto.getTelNum());
			rtnDto.setHassosakiBusho(null); //発送先部署は初期値空文字
		} else {
			rtnDto.setHassosakiName(null);
			rtnDto.setYubinNum(null);
			rtnDto.setAddress(null);
			rtnDto.setTelNum(null);
			rtnDto.setHassosakiBusho(null); //発送先部署は初期値空文字
		}
	}
	/**
	 * EntityからDtoへの変換（Null想定のため特定のSetterを使う。）
	 * @param work
	 * @return
	 */
	private AddressInfoDto copyAddoressDto(AHassosakiWork work) {
		AddressInfoDto aDto = new AddressInfoDto();
		if (work == null) {
			work = new AHassosakiWork(); //Null対策
		}
		copyAddressDto(work, aDto);
		return aDto;
	}
	/**
	 * EntityからDtoへの変換
	 * @param work 変換元
	 * @param aDto 変換先
	 */
	private void copyAddressDto(AHassosakiWork work, AddressInfoDto aDto) {
		aDto.setNyuryokushaCd(work.getNyuryokushaCd());
		aDto.setNyuryokushaName(work.getNyuryokushaName());
		aDto.setTantoBushoName(work.getTantoBusho());
		aDto.setTantoshaName(work.getTantosha());;
		aDto.setThumonshaCd(StringUtility.toString(work.getThumonshaCd()));;
		aDto.setThumonshaName(work.getThumonshaName());
		aDto.setHassosakiCd(StringUtility.toString(work.getHassosakiCd()));
		aDto.setHassosakiName(work.getHassosakiName());
		aDto.setHassosakiBusho(work.getHassosakiBusho());
		aDto.setYubinNum(work.getYubinNum());
		aDto.setAddress(work.getAddress());
		aDto.setTelNum(work.getTelNum());
		aDto.setVersion(work.getVersion());
	}
	
	private AHassosakiWork copyAddressWork(AddressInfoDto aDto) {
		 AHassosakiWork work = new AHassosakiWork();
		work.setNyuryokushaCd(aDto.getNyuryokushaCd());
		work.setNyuryokushaName(aDto.getNyuryokushaName());
		work.setTantoBusho(aDto.getTantoBushoName());
		work.setTantosha(aDto.getTantoshaName());;
		work.setThumonshaCd(replaceInt(aDto.getThumonshaCd()));;
		work.setThumonshaName(aDto.getThumonshaName());
		work.setHassosakiCd(replaceInt(aDto.getHassosakiCd()));
		work.setHassosakiName(aDto.getHassosakiName());
		work.setHassosakiBusho(aDto.getHassosakiBusho());
		work.setYubinNum(aDto.getYubinNum());
		work.setAddress(aDto.getAddress());
		work.setTelNum(aDto.getTelNum());
		work.setVersion(aDto.getVersion());
		return work;
	}
	private Integer replaceInt(String str) {
		if (StringUtils.isEmpty(str) && !NumberUtils.isDigits(str)) {
			return null;
		}
		return Integer.parseInt(str);
	}
}
